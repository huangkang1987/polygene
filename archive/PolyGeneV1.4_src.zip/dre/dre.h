/*
	Genotypic frequencies at equilibrium for polysomic inheritance under double-reduction
	Kang Huang, Tongcheng Wang, Derek W. Dunn, Pei Zhang, Rucong Liu, Xiaoxiao Cao, Baoguo Li
	doi: https://doi.org/10.1101/532861
	Feb 27, 2019 
*/

#ifndef DRE_H
#define DRE_H

extern "C" {
#ifdef _WIN32
	#define EXPORT __declspec(dllexport)
#else
	#define EXPORT 
#endif
	
unsigned int EXPORT GetHash(int* x1, int* y1, int p, int* x, int* y);
void EXPORT MatchAllele(long long code, int *gx, int * gy, int *alleles, int offset, int p);
double EXPORT GFZ10_iiiiiiiiii(double a1, double a2, double pi);
double EXPORT GFZ10_iiiiiiiiij(double a1, double a2, double pi, double pj);
double EXPORT GFZ10_iiiiiiiijj(double a1, double a2, double pi, double pj);
double EXPORT GFZ10_iiiiiiiijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiiiijjj(double a1, double a2, double pi, double pj);
double EXPORT GFZ10_iiiiiiijjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiiiijjjj(double a1, double a2, double pi, double pj);
double EXPORT GFZ10_iiiiiijjjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiiijjkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiiiijjjjj(double a1, double a2, double pi, double pj);
double EXPORT GFZ10_iiiiijjjjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiijjjkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiiiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ10_iiiijjjjkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiijjjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiijjjkkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ10_iiiijjjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiijjjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiiijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiiijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiiijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ10_iiiijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT GFZ10_iiijjjkkkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiijjjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ10_iiijjjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiijjjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ10_iiijjkkllm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iiijjkklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ10_iiijjklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT GFZ10_iiijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT GFZ10_iijjkkllmm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ10_iijjkkllmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ10_iijjkklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT GFZ10_iijjklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT GFZ10_iijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
double EXPORT GFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);
double EXPORT PFZ10_i(double a1, double a2, double pi);
double EXPORT PFZ10_ij(double a1, double a2, double pi, double pj);
double EXPORT PFZ10_ijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT PFZ10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT PFZ10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ10_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT PFZ10_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT PFZ10_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT PFZ10_ijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
double EXPORT PFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);
double EXPORT GFG10_iiiii(double a1, double a2, double pi);
double EXPORT GFG10_iiiij(double a1, double a2, double pi, double pj);
double EXPORT GFG10_iiijj(double a1, double a2, double pi, double pj);
double EXPORT GFG10_iiijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFG10_iijjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFG10_iijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT PFG10_i(double a1, double a2, double pi);
double EXPORT PFG10_ij(double a1, double a2, double pi, double pj);
double EXPORT PFG10_ijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT PFG10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT PFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);

double EXPORT GFZ8_iiiiiiii(double a1, double a2, double pi);
double EXPORT GFZ8_iiiiiiij(double a1, double a2, double pi, double pj);
double EXPORT GFZ8_iiiiiijj(double a1, double a2, double pi, double pj);
double EXPORT GFZ8_iiiiiijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ8_iiiiijjj(double a1, double a2, double pi, double pj);
double EXPORT GFZ8_iiiiijjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ8_iiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ8_iiiijjjj(double a1, double a2, double pi, double pj);
double EXPORT GFZ8_iiiijjjk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ8_iiiijjkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ8_iiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ8_iiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ8_iiijjjkk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFZ8_iiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ8_iiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ8_iiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ8_iiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ8_iijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT GFZ8_iijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ8_iijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFZ8_iijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT GFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT PFZ8_i(double a1, double a2, double pi);
double EXPORT PFZ8_ij(double a1, double a2, double pi, double pj);
double EXPORT PFZ8_ijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT PFZ8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT PFZ8_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ8_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT PFZ8_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT PFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT GFG8_iiii(double a1, double a2, double pi);
double EXPORT GFG8_iiij(double a1, double a2, double pi, double pj);
double EXPORT GFG8_iijj(double a1, double a2, double pi, double pj);
double EXPORT GFG8_iijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT GFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
double EXPORT PFG8_i(double a1, double a2, double pi);
double EXPORT PFG8_ij(double a1, double a2, double pi, double pj);
double EXPORT PFG8_ijk(double a1, double a2, double pi, double pj, double pk);
double EXPORT PFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);

double EXPORT GFZ6_iiiiii(double a1, double pi);
double EXPORT GFZ6_iiiiij(double a1, double pi, double pj);
double EXPORT GFZ6_iiiijj(double a1, double pi, double pj);
double EXPORT GFZ6_iiiijk(double a1, double pi, double pj, double pk);
double EXPORT GFZ6_iiijjj(double a1, double pi, double pj);
double EXPORT GFZ6_iiijjk(double a1, double pi, double pj, double pk);
double EXPORT GFZ6_iiijkl(double a1, double pi, double pj, double pk, double pl);
double EXPORT GFZ6_iijjkk(double a1, double pi, double pj, double pk);
double EXPORT GFZ6_iijjkl(double a1, double pi, double pj, double pk, double pl);
double EXPORT GFZ6_iijklm(double a1, double pi, double pj, double pk, double pl, double pm);
double EXPORT GFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT PFZ6_i(double a1, double pi);
double EXPORT PFZ6_ij(double a1, double pi, double pj);
double EXPORT PFZ6_ijk(double a1, double pi, double pj, double pk);
double EXPORT PFZ6_ijkl(double a1, double pi, double pj, double pk, double pl);
double EXPORT PFZ6_ijklm(double a1, double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT GFG6_iii(double a1, double pi);
double EXPORT GFG6_iij(double a1, double pi, double pj);
double EXPORT GFG6_ijk(double a1, double pi, double pj, double pk);
double EXPORT PFG6_i(double a1, double pi);
double EXPORT PFG6_ij(double a1, double pi, double pj);
double EXPORT PFG6_ijk(double a1, double pi, double pj, double pk);

double EXPORT GFZ4_iiii(double a1, double pi);
double EXPORT GFZ4_iiij(double a1, double pi, double pj);
double EXPORT GFZ4_iijj(double a1, double pi, double pj);
double EXPORT GFZ4_iijk(double a1, double pi, double pj, double pk);
double EXPORT GFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);
double EXPORT PFZ4_i(double a1, double pi);
double EXPORT PFZ4_ij(double a1, double pi, double pj);
double EXPORT PFZ4_ijk(double a1, double pi, double pj, double pk);
double EXPORT PFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);
double EXPORT GFG4_ii(double a1, double pi);
double EXPORT GFG4_ij(double a1, double pi, double pj);
double EXPORT PFG4_i(double a1, double pi);
double EXPORT PFG4_ij(double a1, double pi, double pj);

double EXPORT PFZ3_i(double pi);
double EXPORT PFZ3_ij(double pi, double pj);
double EXPORT PFZ3_ijk(double pi, double pj, double pk);
double EXPORT PFZ5_i(double pi);
double EXPORT PFZ5_ij(double pi, double pj);
double EXPORT PFZ5_ijk(double pi, double pj, double pk);
double EXPORT PFZ5_ijkl(double pi, double pj, double pk, double pl);
double EXPORT PFZ5_ijklm(double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ7_i(double pi);
double EXPORT PFZ7_ij(double pi, double pj);
double EXPORT PFZ7_ijk(double pi, double pj, double pk);
double EXPORT PFZ7_ijkl(double pi, double pj, double pk, double pl);
double EXPORT PFZ7_ijklm(double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ7_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT PFZ7_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT PFZ9_i(double pi);
double EXPORT PFZ9_ij(double pi, double pj);
double EXPORT PFZ9_ijk(double pi, double pj, double pk);
double EXPORT PFZ9_ijkl(double pi, double pj, double pk, double pl);
double EXPORT PFZ9_ijklm(double pi, double pj, double pk, double pl, double pm);
double EXPORT PFZ9_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);
double EXPORT PFZ9_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);
double EXPORT PFZ9_ijklmnop(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
double EXPORT PFZ9_ijklmnopq(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
}
#endif
﻿namespace PolyGene
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.MainToolStrip = new System.Windows.Forms.ToolStrip();
            this.CalcButton = new System.Windows.Forms.ToolStripButton();
            this.PauseButton = new System.Windows.Forms.ToolStripButton();
            this.AbortButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.genepopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.structureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polyRelatednessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spagediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.genodiveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vCFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExportButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.ModelTestButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.AboutButton = new System.Windows.Forms.ToolStripButton();
            this.ManualButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.TaskLabel = new System.Windows.Forms.ToolStripLabel();
            this.SimRunButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.InputPage = new System.Windows.Forms.TabPage();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.SimPop_AlleleFrequencyBox = new System.Windows.Forms.TextBox();
            this.SimulationToolStrip = new System.Windows.Forms.ToolStrip();
            this.ReproduceFounderButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.Reproduce1Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce10Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce100Button = new System.Windows.Forms.ToolStripButton();
            this.Reproduce1000Button = new System.Windows.Forms.ToolStripButton();
            this.SimulationuntilFstButton = new System.Windows.Forms.ToolStripButton();
            this.SimPop_FstTerminalBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.GenLabel = new System.Windows.Forms.ToolStripLabel();
            this.FstLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FormatBox = new System.Windows.Forms.ComboBox();
            this.PhenotypeBox = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.SimRandomizeDistanceToCentermereButton = new System.Windows.Forms.Button();
            this.SimPop_DistBox = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.SimPop_OutputGenotypeBox = new System.Windows.Forms.CheckBox();
            this.SimPop_DioeciousBox = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SimPop_NegPCRBox = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.SimPop_SamplingRateBox = new System.Windows.Forms.NumericUpDown();
            this.SimPop_SelfingRateBox = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.SimPop_FemaleRateBox = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.ParametersPage = new System.Windows.Forms.TabPage();
            this.splitContainer20 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.GroupBoxMethods = new System.Windows.Forms.GroupBox();
            this.CalcLinkageBox = new System.Windows.Forms.CheckBox();
            this.CalcInbreedingBox = new System.Windows.Forms.CheckBox();
            this.CalcNeBox = new System.Windows.Forms.CheckBox();
            this.CalcParentageBox = new System.Windows.Forms.CheckBox();
            this.CalcSpatialBox = new System.Windows.Forms.CheckBox();
            this.CalcQstBox = new System.Windows.Forms.CheckBox();
            this.CalcAMOVABox = new System.Windows.Forms.CheckBox();
            this.CalcDistBox = new System.Windows.Forms.CheckBox();
            this.CalcClusteringBox = new System.Windows.Forms.CheckBox();
            this.CalcHeritabilityBox = new System.Windows.Forms.CheckBox();
            this.CalcOrdinationBox = new System.Windows.Forms.CheckBox();
            this.CalcBayesAssBox = new System.Windows.Forms.CheckBox();
            this.CalcStructureBox = new System.Windows.Forms.CheckBox();
            this.CalcRelationshipBox = new System.Windows.Forms.CheckBox();
            this.CalcAssignmentBox = new System.Windows.Forms.CheckBox();
            this.CalcHIndexBox = new System.Windows.Forms.CheckBox();
            this.CalcDistributionBox = new System.Windows.Forms.CheckBox();
            this.CalcDiffBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxAlleleFrequency = new System.Windows.Forms.GroupBox();
            this.FrequencyNrRateBox = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.FrequencySelfingRateEstimatorBox = new System.Windows.Forms.ComboBox();
            this.FrequencySelfingBox = new System.Windows.Forms.CheckBox();
            this.FrequencyNegPCRBox = new System.Windows.Forms.CheckBox();
            this.FrequencyNullAlleleBox = new System.Windows.Forms.CheckBox();
            this.FrequencyInheritanceModeBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.GroupBoxGeneralSettings = new System.Windows.Forms.GroupBox();
            this.GlobalWarningBox = new System.Windows.Forms.CheckBox();
            this.button5 = new System.Windows.Forms.Button();
            this.GlobalRandomizeSeedButton = new System.Windows.Forms.Button();
            this.GlobalFoldControlBox = new System.Windows.Forms.CheckBox();
            this.FrequencyRemoveDupAlleleBox = new System.Windows.Forms.CheckBox();
            this.GlobalSeedBox = new System.Windows.Forms.NumericUpDown();
            this.GlobalThreadBox = new System.Windows.Forms.NumericUpDown();
            this.GlobalRefreshSeedBox = new System.Windows.Forms.CheckBox();
            this.GlobalRegionBox = new System.Windows.Forms.TextBox();
            this.GlobalDecimalPlaceBox = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ParametersPanel = new System.Windows.Forms.Panel();
            this.GroupBoxHeritability = new System.Windows.Forms.GroupBox();
            this.HeritabilityJackknifeBox = new System.Windows.Forms.CheckBox();
            this.HeritabilityHuangMLBox = new System.Windows.Forms.CheckBox();
            this.HeritabilityThomas2000Box = new System.Windows.Forms.CheckBox();
            this.HeritabilityMousseau1998Box = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.HeritabilityHuangMOMBox = new System.Windows.Forms.CheckBox();
            this.HeritabilityRitland1996Box = new System.Windows.Forms.CheckBox();
            this.GroupBoxNe = new System.Windows.Forms.GroupBox();
            this.NeWaplesFBox = new System.Windows.Forms.NumericUpDown();
            this.NeWaplesMSBox = new System.Windows.Forms.ComboBox();
            this.NeWaples2010Box = new System.Windows.Forms.CheckBox();
            this.NePudovkin1996Box = new System.Windows.Forms.CheckBox();
            this.NeNomura2008Box = new System.Windows.Forms.CheckBox();
            this.label111 = new System.Windows.Forms.Label();
            this.Label109 = new System.Windows.Forms.Label();
            this.GroupBoxDistribution = new System.Windows.Forms.GroupBox();
            this.PhenotypeTestTotBox = new System.Windows.Forms.CheckBox();
            this.PhenotypeTestRegBox = new System.Windows.Forms.CheckBox();
            this.PhenotypeTestPopBox = new System.Windows.Forms.CheckBox();
            this.label98 = new System.Windows.Forms.Label();
            this.GroupBoxStructure = new System.Windows.Forms.GroupBox();
            this.label106 = new System.Windows.Forms.Label();
            this.StructureADMBurninBox = new System.Windows.Forms.NumericUpDown();
            this.StructureKmaxBox = new System.Windows.Forms.NumericUpDown();
            this.StructureNThinningBox = new System.Windows.Forms.NumericUpDown();
            this.StructureBurninBox = new System.Windows.Forms.NumericUpDown();
            this.StructureNRepsBox = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.StructureEpsGammaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureEpsEtaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureFPriorStdBox = new System.Windows.Forms.NumericUpDown();
            this.StructureEpsRBox = new System.Windows.Forms.NumericUpDown();
            this.label99 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.StructureFStdFBox = new System.Windows.Forms.NumericUpDown();
            this.StructureFPriorMeanBox = new System.Windows.Forms.NumericUpDown();
            this.StructureMaxRBox = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.StructureUpdateQBox = new System.Windows.Forms.NumericUpDown();
            this.StructureAlphaPrioriABox = new System.Windows.Forms.NumericUpDown();
            this.StructureAlphaPrioriBBox = new System.Windows.Forms.NumericUpDown();
            this.StructureStdAlphaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureMaxAlphaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureAlpha0Box = new System.Windows.Forms.NumericUpDown();
            this.StructureMaxLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureStdLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.StructureLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.StructureNRunsBox = new System.Windows.Forms.NumericUpDown();
            this.StructureKminBox = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.StructureADMBox = new System.Windows.Forms.CheckBox();
            this.StructureFmodelBox = new System.Windows.Forms.CheckBox();
            this.StructureLOCPRIORIBox = new System.Windows.Forms.CheckBox();
            this.StructureDiffAlphaBox = new System.Windows.Forms.CheckBox();
            this.StructureDiffLambdaBox = new System.Windows.Forms.CheckBox();
            this.StructureUniformAlphaBox = new System.Windows.Forms.CheckBox();
            this.StructureInferAlphaBox = new System.Windows.Forms.CheckBox();
            this.StructureInferLambdaBox = new System.Windows.Forms.CheckBox();
            this.StructureFSameBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxLinkage = new System.Windows.Forms.GroupBox();
            this.LinkageTestTotBox = new System.Windows.Forms.CheckBox();
            this.LinkageTestRegBox = new System.Windows.Forms.CheckBox();
            this.LinkageTestPopBox = new System.Windows.Forms.CheckBox();
            this.label104 = new System.Windows.Forms.Label();
            this.LinkageBurrowsTestBox = new System.Windows.Forms.CheckBox();
            this.LinkageFisherTestBox = new System.Windows.Forms.CheckBox();
            this.label101 = new System.Windows.Forms.Label();
            this.LinkageIterationsBox = new System.Windows.Forms.NumericUpDown();
            this.LinkageBurninBox = new System.Windows.Forms.NumericUpDown();
            this.LinkageBatchesBox = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.LinkageRaymondTestBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxOrdination = new System.Windows.Forms.GroupBox();
            this.OrdinationPCABox = new System.Windows.Forms.CheckBox();
            this.label91 = new System.Windows.Forms.Label();
            this.OrdinationDimBox = new System.Windows.Forms.NumericUpDown();
            this.label90 = new System.Windows.Forms.Label();
            this.OrdinationPCoABox = new System.Windows.Forms.CheckBox();
            this.GroupBoxDiff = new System.Windows.Forms.GroupBox();
            this.label87 = new System.Windows.Forms.Label();
            this.DiffRegBox = new System.Windows.Forms.CheckBox();
            this.DiffTotBox = new System.Windows.Forms.CheckBox();
            this.DiffPopBox = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.DiffIterationsBox = new System.Windows.Forms.NumericUpDown();
            this.DiffBurninBox = new System.Windows.Forms.NumericUpDown();
            this.DiffBatchesBox = new System.Windows.Forms.NumericUpDown();
            this.label83 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.DiffHuang2019Box = new System.Windows.Forms.CheckBox();
            this.DiffJost2008Box = new System.Windows.Forms.CheckBox();
            this.DiffHedrick2005Box = new System.Windows.Forms.CheckBox();
            this.DiffHudson1992Box = new System.Windows.Forms.CheckBox();
            this.DiffTestPermBox = new System.Windows.Forms.CheckBox();
            this.DiffTestAlleleBox = new System.Windows.Forms.CheckBox();
            this.DiffNei1973Box = new System.Windows.Forms.CheckBox();
            this.DiffTestPhenoBox = new System.Windows.Forms.CheckBox();
            this.DiffHuang2018SMMBox = new System.Windows.Forms.CheckBox();
            this.DiffSlatkin1995Box = new System.Windows.Forms.CheckBox();
            this.DiffHuang2018IAMBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxAssignment = new System.Windows.Forms.GroupBox();
            this.AssignmentErrorBox = new System.Windows.Forms.NumericUpDown();
            this.AssignmentPloidyBox = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.GroupBoxSpatial = new System.Windows.Forms.GroupBox();
            this.SpatialDistClassBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SpatialDistIntervalBox = new System.Windows.Forms.TextBox();
            this.SpatialJackknifeBox = new System.Windows.Forms.CheckBox();
            this.SpatialHaversineBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxBayesAss = new System.Windows.Forms.GroupBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.BayesAssDeltaMBox = new System.Windows.Forms.NumericUpDown();
            this.BayesAssDeltaFBox = new System.Windows.Forms.NumericUpDown();
            this.BayesAssDeltaABox = new System.Windows.Forms.NumericUpDown();
            this.BayesAssNoLikelihoodBox = new System.Windows.Forms.CheckBox();
            this.BayesAssMethodBox = new System.Windows.Forms.ComboBox();
            this.label88 = new System.Windows.Forms.Label();
            this.BayesAssNThinningBox = new System.Windows.Forms.NumericUpDown();
            this.BayesAssBurninBox = new System.Windows.Forms.NumericUpDown();
            this.BayesAssNRepsBox = new System.Windows.Forms.NumericUpDown();
            this.label69 = new System.Windows.Forms.Label();
            this.BayesAssNRunsBox = new System.Windows.Forms.NumericUpDown();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.GroupBoxClustering = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClusteringWPGMABox = new System.Windows.Forms.CheckBox();
            this.ClusteringWARDBox = new System.Windows.Forms.CheckBox();
            this.ClusteringUPGMABox = new System.Windows.Forms.CheckBox();
            this.ClusteringWPGMCBox = new System.Windows.Forms.CheckBox();
            this.ClusteringFurthestBox = new System.Windows.Forms.CheckBox();
            this.ClusteringUPGMCBox = new System.Windows.Forms.CheckBox();
            this.ClusteringNearestBox = new System.Windows.Forms.CheckBox();
            this.label92 = new System.Windows.Forms.Label();
            this.GroupBoxAMOVA = new System.Windows.Forms.GroupBox();
            this.AMOVAMLBox = new System.Windows.Forms.CheckBox();
            this.AMOVAGenotypeBox = new System.Windows.Forms.CheckBox();
            this.AMOVAAnisoBox = new System.Windows.Forms.CheckBox();
            this.AMOVAHomoCorrBox = new System.Windows.Forms.CheckBox();
            this.AMOVAHomoBox = new System.Windows.Forms.CheckBox();
            this.AMOVASMMBox = new System.Windows.Forms.CheckBox();
            this.AMOVAIAMBox = new System.Windows.Forms.CheckBox();
            this.AMOVAIgnoreIndBox = new System.Windows.Forms.CheckBox();
            this.AMOVAOutputSSBox = new System.Windows.Forms.CheckBox();
            this.AMOVANPermBox = new System.Windows.Forms.NumericUpDown();
            this.label102 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.GroupBoxParentage = new System.Windows.Forms.GroupBox();
            this.ParentageRedoBox = new System.Windows.Forms.CheckBox();
            this.ParentageEstSampleBox = new System.Windows.Forms.CheckBox();
            this.ParentageUnknownBox = new System.Windows.Forms.CheckBox();
            this.ParentageParentPairBox = new System.Windows.Forms.CheckBox();
            this.ParentageSkipSimBox = new System.Windows.Forms.CheckBox();
            this.ParentagePaternityBox = new System.Windows.Forms.CheckBox();
            this.label81 = new System.Windows.Forms.Label();
            this.ParentageEstErrorBox = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.ParentageMethodBox = new System.Windows.Forms.ComboBox();
            this.ParentageOutputBox = new System.Windows.Forms.ComboBox();
            this.ParentageErrorNSimBox = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.ParentageNSimBox = new System.Windows.Forms.NumericUpDown();
            this.ParentageUnknownNCandidateBox = new System.Windows.Forms.NumericUpDown();
            this.label75 = new System.Windows.Forms.Label();
            this.ParentageParentPairNMotherBox = new System.Windows.Forms.NumericUpDown();
            this.ParentageParentPairNFatherBox = new System.Windows.Forms.NumericUpDown();
            this.label76 = new System.Windows.Forms.Label();
            this.ParentagePaternityNFatherBox = new System.Windows.Forms.NumericUpDown();
            this.ParentageSamplingRateBox = new System.Windows.Forms.NumericUpDown();
            this.label77 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.ParentageMistypeRateBox = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.GroupBoxDist = new System.Windows.Forms.GroupBox();
            this.DistNei1972Box = new System.Windows.Forms.CheckBox();
            this.DistRegBox = new System.Windows.Forms.CheckBox();
            this.DistPopBox = new System.Windows.Forms.CheckBox();
            this.DistIndBox = new System.Windows.Forms.CheckBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.DistSlatkinBox = new System.Windows.Forms.CheckBox();
            this.DistRoger1973Box = new System.Windows.Forms.CheckBox();
            this.DistNei1983Box = new System.Windows.Forms.CheckBox();
            this.DistReynolds1983Box = new System.Windows.Forms.CheckBox();
            this.DistNei1973Box = new System.Windows.Forms.CheckBox();
            this.DistReynold1993Box = new System.Windows.Forms.CheckBox();
            this.DistGoldstein1995Box = new System.Windows.Forms.CheckBox();
            this.DistCavalli1967Box = new System.Windows.Forms.CheckBox();
            this.DistEuclideanBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxRelationship = new System.Windows.Forms.GroupBox();
            this.RelationshipRegBox = new System.Windows.Forms.CheckBox();
            this.RelationshipJackknifeBox = new System.Windows.Forms.CheckBox();
            this.RelationshipPopBox = new System.Windows.Forms.CheckBox();
            this.RelationshipLoiselle1995Box = new System.Windows.Forms.CheckBox();
            this.RelationshipRitland1996Box = new System.Windows.Forms.CheckBox();
            this.RelationshipHuang2015Box = new System.Windows.Forms.CheckBox();
            this.RelationshipLoiselle1995mBox = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.RelationshipHuangUnpubBox = new System.Windows.Forms.CheckBox();
            this.RelationshipHuangUnpubmBox = new System.Windows.Forms.CheckBox();
            this.RelationshipHardy1999Box = new System.Windows.Forms.CheckBox();
            this.RelationshipWeir1996Box = new System.Windows.Forms.CheckBox();
            this.RelationshipHuang2014Box = new System.Windows.Forms.CheckBox();
            this.RelationshipRitland1996mBox = new System.Windows.Forms.CheckBox();
            this.RelationshipTotBox = new System.Windows.Forms.CheckBox();
            this.GroupBoxInbreeding = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.InbreedingJackknifeBox = new System.Windows.Forms.CheckBox();
            this.InbreedingLoiselle1995Box = new System.Windows.Forms.CheckBox();
            this.InbreedingRitland1996Box = new System.Windows.Forms.CheckBox();
            this.InbreedingHuangUnpubBox = new System.Windows.Forms.CheckBox();
            this.InbreedingWeir1996Box = new System.Windows.Forms.CheckBox();
            this.DiversityPage = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.DiversityResBox = new System.Windows.Forms.TextBox();
            this.FrequencyPage = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FrequencyResBox = new System.Windows.Forms.TextBox();
            this.DistributionPage = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.DistributionResBox = new System.Windows.Forms.TextBox();
            this.LinkagePage = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.LinkageResBox = new System.Windows.Forms.TextBox();
            this.NePage = new System.Windows.Forms.TabPage();
            this.groupBox56 = new System.Windows.Forms.GroupBox();
            this.NeResBox = new System.Windows.Forms.TextBox();
            this.DiffPage = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DiffResBox = new System.Windows.Forms.TextBox();
            this.DistPage = new System.Windows.Forms.TabPage();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.DistResBox = new System.Windows.Forms.TextBox();
            this.OrdinationPage = new System.Windows.Forms.TabPage();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.PCoAPanel = new System.Windows.Forms.Panel();
            this.OrdinationPicBox = new System.Windows.Forms.PictureBox();
            this.OrdinationToolStrip = new System.Windows.Forms.ToolStrip();
            this.OrdinationComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.OrdinationPreviousButton = new System.Windows.Forms.ToolStripButton();
            this.OrdinationNextButton = new System.Windows.Forms.ToolStripButton();
            this.SaveOrdinationButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.OrdinationFontSizeBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.OrdinationStyleBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.OrdinationMarkerSizeBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.OrdinationMarkerBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.OrdinationAxesBox = new System.Windows.Forms.ToolStripTextBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.OrdinationResBox = new System.Windows.Forms.TextBox();
            this.ClusteringPage = new System.Windows.Forms.TabPage();
            this.splitContainer16 = new System.Windows.Forms.SplitContainer();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.ClusteringPanel = new System.Windows.Forms.Panel();
            this.ClusteringPicBox = new System.Windows.Forms.PictureBox();
            this.ClusteringToolStrip = new System.Windows.Forms.ToolStrip();
            this.ClusteringComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ClusteringPreviousButton = new System.Windows.Forms.ToolStripButton();
            this.ClusteringNextButton = new System.Windows.Forms.ToolStripButton();
            this.SaveClusteringButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel15 = new System.Windows.Forms.ToolStripLabel();
            this.ClusteringFontSizeBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel14 = new System.Windows.Forms.ToolStripLabel();
            this.ClusteringLineSepBox = new System.Windows.Forms.ToolStripTextBox();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.ClusteringResBox = new System.Windows.Forms.TextBox();
            this.InbreedingPage = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.InbreedingResBox = new System.Windows.Forms.TextBox();
            this.HIndexPage = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.HIndexResBox = new System.Windows.Forms.TextBox();
            this.AssignmentPage = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.AssignmentResBox = new System.Windows.Forms.TextBox();
            this.SpatialPage = new System.Windows.Forms.TabPage();
            this.groupBox59 = new System.Windows.Forms.GroupBox();
            this.SpatialResBox = new System.Windows.Forms.TextBox();
            this.RelationshipPage = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.RelationshipResBox = new System.Windows.Forms.TextBox();
            this.HeritabilityPage = new System.Windows.Forms.TabPage();
            this.groupBox60 = new System.Windows.Forms.GroupBox();
            this.HeritabilityResBox = new System.Windows.Forms.TextBox();
            this.QstPage = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.QstResBox = new System.Windows.Forms.TextBox();
            this.ParentagePage = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.DPU_80 = new System.Windows.Forms.NumericUpDown();
            this.DP_80 = new System.Windows.Forms.NumericUpDown();
            this.DPF_80 = new System.Windows.Forms.NumericUpDown();
            this.DPF_95 = new System.Windows.Forms.NumericUpDown();
            this.DP_95 = new System.Windows.Forms.NumericUpDown();
            this.DPU_95 = new System.Windows.Forms.NumericUpDown();
            this.DPF_99 = new System.Windows.Forms.NumericUpDown();
            this.DP_99 = new System.Windows.Forms.NumericUpDown();
            this.DPU_99 = new System.Windows.Forms.NumericUpDown();
            this.DPF_999 = new System.Windows.Forms.NumericUpDown();
            this.DPU_999 = new System.Windows.Forms.NumericUpDown();
            this.DP_999 = new System.Windows.Forms.NumericUpDown();
            this.D2_80 = new System.Windows.Forms.NumericUpDown();
            this.DPM_80 = new System.Windows.Forms.NumericUpDown();
            this.D1_80 = new System.Windows.Forms.NumericUpDown();
            this.D2_95 = new System.Windows.Forms.NumericUpDown();
            this.D1_95 = new System.Windows.Forms.NumericUpDown();
            this.DPM_95 = new System.Windows.Forms.NumericUpDown();
            this.D2_99 = new System.Windows.Forms.NumericUpDown();
            this.D1_99 = new System.Windows.Forms.NumericUpDown();
            this.DPM_99 = new System.Windows.Forms.NumericUpDown();
            this.D2_999 = new System.Windows.Forms.NumericUpDown();
            this.D1_999 = new System.Windows.Forms.NumericUpDown();
            this.DPM_999 = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.ParentageSimResBox = new System.Windows.Forms.TextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.ParentagePaternityOffspringBox = new System.Windows.Forms.TextBox();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.ParentagePaternityResBox = new System.Windows.Forms.TextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairOffspringBox = new System.Windows.Forms.TextBox();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairMotherBox = new System.Windows.Forms.TextBox();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairFatherBox = new System.Windows.Forms.TextBox();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairResBox = new System.Windows.Forms.TextBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownOffspringBox = new System.Windows.Forms.TextBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownParentBox = new System.Windows.Forms.TextBox();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownResBox = new System.Windows.Forms.TextBox();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.ParentageErrorResBox = new System.Windows.Forms.TextBox();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.ParentageSampleResBox = new System.Windows.Forms.TextBox();
            this.AMOVAPage = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.AMOVAResBox = new System.Windows.Forms.TextBox();
            this.StructurePage = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.StructureResultFileBox = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.StructureRunListBox = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.StructurePicBox = new System.Windows.Forms.PictureBox();
            this.StructureToolStrip = new System.Windows.Forms.ToolStrip();
            this.SaveStructureButton = new System.Windows.Forms.ToolStripButton();
            this.ExportStructureButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel13 = new System.Windows.Forms.ToolStripLabel();
            this.StructureIndividualOrderBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.StructureRearrangeColorBox = new System.Windows.Forms.ToolStripComboBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.StructureRunDetailBox = new System.Windows.Forms.TextBox();
            this.BayesAssPage = new System.Windows.Forms.TabPage();
            this.splitContainer17 = new System.Windows.Forms.SplitContainer();
            this.splitContainer18 = new System.Windows.Forms.SplitContainer();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.BayesAssResultFileBox = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.BayesAssRunListBox = new System.Windows.Forms.ListView();
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer19 = new System.Windows.Forms.SplitContainer();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.BayesAssPicBox = new System.Windows.Forms.PictureBox();
            this.BayesAssToolStrip = new System.Windows.Forms.ToolStrip();
            this.SaveBayesAssButton = new System.Windows.Forms.ToolStripButton();
            this.ExportBayesAssButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel16 = new System.Windows.Forms.ToolStripLabel();
            this.BayesAssPlotStyleBox = new System.Windows.Forms.ToolStripComboBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.BayesAssRunDetailBox = new System.Windows.Forms.TextBox();
            this.MantelPage = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.MantelPermuteButton = new System.Windows.Forms.Button();
            this.MantelExampleButton = new System.Windows.Forms.Button();
            this.MantelNPermBox = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.MantelResBox = new System.Windows.Forms.TextBox();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.MantelMatBox = new System.Windows.Forms.TextBox();
            this.ProgressTimer = new System.Windows.Forms.Timer(this.components);
            this.SavePicDialog = new System.Windows.Forms.SaveFileDialog();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImportFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.PreSaveTimer = new System.Windows.Forms.Timer(this.components);
            this.FoldTimer = new System.Windows.Forms.Timer(this.components);
            this.SaveDataDialog = new System.Windows.Forms.SaveFileDialog();
            this.ExportFileDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.MainToolStrip.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.InputPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).BeginInit();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SimulationToolStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_NegPCRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SamplingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SelfingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_FemaleRateBox)).BeginInit();
            this.ParametersPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer20)).BeginInit();
            this.splitContainer20.Panel1.SuspendLayout();
            this.splitContainer20.Panel2.SuspendLayout();
            this.splitContainer20.SuspendLayout();
            this.panel1.SuspendLayout();
            this.GroupBoxMethods.SuspendLayout();
            this.GroupBoxAlleleFrequency.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FrequencyNrRateBox)).BeginInit();
            this.GroupBoxGeneralSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalSeedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalThreadBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalDecimalPlaceBox)).BeginInit();
            this.ParametersPanel.SuspendLayout();
            this.GroupBoxHeritability.SuspendLayout();
            this.GroupBoxNe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NeWaplesFBox)).BeginInit();
            this.GroupBoxDistribution.SuspendLayout();
            this.GroupBoxStructure.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StructureADMBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureKmaxBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNThinningBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNRepsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsGammaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsEtaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFPriorStdBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFStdFBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFPriorMeanBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureUpdateQBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlphaPrioriABox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlphaPrioriBBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureStdAlphaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxAlphaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlpha0Box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureStdLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNRunsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureKminBox)).BeginInit();
            this.GroupBoxLinkage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageIterationsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBatchesBox)).BeginInit();
            this.GroupBoxOrdination.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrdinationDimBox)).BeginInit();
            this.GroupBoxDiff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiffIterationsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBatchesBox)).BeginInit();
            this.GroupBoxAssignment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentErrorBox)).BeginInit();
            this.GroupBoxSpatial.SuspendLayout();
            this.GroupBoxBayesAss.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaMBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaFBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaABox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNThinningBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNRepsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNRunsBox)).BeginInit();
            this.GroupBoxClustering.SuspendLayout();
            this.GroupBoxAMOVA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AMOVANPermBox)).BeginInit();
            this.GroupBoxParentage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageErrorNSimBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageNSimBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNCandidateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNMotherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNFatherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNFatherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageSamplingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageMistypeRateBox)).BeginInit();
            this.GroupBoxDist.SuspendLayout();
            this.GroupBoxRelationship.SuspendLayout();
            this.GroupBoxInbreeding.SuspendLayout();
            this.DiversityPage.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.FrequencyPage.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.DistributionPage.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.LinkagePage.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.NePage.SuspendLayout();
            this.groupBox56.SuspendLayout();
            this.DiffPage.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.DistPage.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.OrdinationPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).BeginInit();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.PCoAPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrdinationPicBox)).BeginInit();
            this.OrdinationToolStrip.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.ClusteringPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).BeginInit();
            this.splitContainer16.Panel1.SuspendLayout();
            this.splitContainer16.Panel2.SuspendLayout();
            this.splitContainer16.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.ClusteringPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringPicBox)).BeginInit();
            this.ClusteringToolStrip.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.InbreedingPage.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.HIndexPage.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.AssignmentPage.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SpatialPage.SuspendLayout();
            this.groupBox59.SuspendLayout();
            this.RelationshipPage.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.HeritabilityPage.SuspendLayout();
            this.groupBox60.SuspendLayout();
            this.QstPage.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.ParentagePage.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            this.groupBox45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_999)).BeginInit();
            this.groupBox46.SuspendLayout();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.groupBox40.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).BeginInit();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.AMOVAPage.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.StructurePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StructurePicBox)).BeginInit();
            this.StructureToolStrip.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.BayesAssPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer17)).BeginInit();
            this.splitContainer17.Panel1.SuspendLayout();
            this.splitContainer17.Panel2.SuspendLayout();
            this.splitContainer17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer18)).BeginInit();
            this.splitContainer18.Panel1.SuspendLayout();
            this.splitContainer18.Panel2.SuspendLayout();
            this.splitContainer18.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer19)).BeginInit();
            this.splitContainer19.Panel1.SuspendLayout();
            this.splitContainer19.Panel2.SuspendLayout();
            this.splitContainer19.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssPicBox)).BeginInit();
            this.BayesAssToolStrip.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.MantelPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.groupBox31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MantelNPermBox)).BeginInit();
            this.groupBox30.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainToolStrip
            // 
            this.MainToolStrip.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MainToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MainToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CalcButton,
            this.PauseButton,
            this.AbortButton,
            this.toolStripSeparator7,
            this.toolStripDropDownButton1,
            this.ExportButton,
            this.toolStripSeparator13,
            this.ModelTestButton,
            this.toolStripSeparator4,
            this.AboutButton,
            this.ManualButton,
            this.toolStripSeparator2,
            this.toolStripProgressBar1,
            this.TaskLabel,
            this.SimRunButton,
            this.toolStripButton2});
            this.MainToolStrip.Location = new System.Drawing.Point(0, 0);
            this.MainToolStrip.Name = "MainToolStrip";
            this.MainToolStrip.Size = new System.Drawing.Size(1427, 31);
            this.MainToolStrip.TabIndex = 0;
            this.MainToolStrip.Text = "toolStrip1";
            // 
            // CalcButton
            // 
            this.CalcButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CalcButton.Image = ((System.Drawing.Image)(resources.GetObject("CalcButton.Image")));
            this.CalcButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CalcButton.Name = "CalcButton";
            this.CalcButton.Size = new System.Drawing.Size(41, 28);
            this.CalcButton.Text = "&Calc";
            this.CalcButton.Click += new System.EventHandler(this.BeginCalculation);
            // 
            // PauseButton
            // 
            this.PauseButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PauseButton.Image = ((System.Drawing.Image)(resources.GetObject("PauseButton.Image")));
            this.PauseButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PauseButton.Name = "PauseButton";
            this.PauseButton.Size = new System.Drawing.Size(50, 28);
            this.PauseButton.Text = "&Pause";
            this.PauseButton.Click += new System.EventHandler(this.Pause);
            // 
            // AbortButton
            // 
            this.AbortButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AbortButton.Image = ((System.Drawing.Image)(resources.GetObject("AbortButton.Image")));
            this.AbortButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AbortButton.Name = "AbortButton";
            this.AbortButton.Size = new System.Drawing.Size(51, 28);
            this.AbortButton.Text = "&Abort";
            this.AbortButton.Click += new System.EventHandler(this.Abort);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.genepopToolStripMenuItem,
            this.structureToolStripMenuItem,
            this.polyRelatednessToolStripMenuItem,
            this.spagediToolStripMenuItem,
            this.genodiveToolStripMenuItem,
            this.vCFToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(68, 28);
            this.toolStripDropDownButton1.Text = "&Import";
            // 
            // genepopToolStripMenuItem
            // 
            this.genepopToolStripMenuItem.Name = "genepopToolStripMenuItem";
            this.genepopToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.genepopToolStripMenuItem.Text = "&Genepop";
            this.genepopToolStripMenuItem.Click += new System.EventHandler(this.ImportGenepop);
            // 
            // structureToolStripMenuItem
            // 
            this.structureToolStripMenuItem.Name = "structureToolStripMenuItem";
            this.structureToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.structureToolStripMenuItem.Text = "&Structure";
            this.structureToolStripMenuItem.Click += new System.EventHandler(this.ImportStructure);
            // 
            // polyRelatednessToolStripMenuItem
            // 
            this.polyRelatednessToolStripMenuItem.Name = "polyRelatednessToolStripMenuItem";
            this.polyRelatednessToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.polyRelatednessToolStripMenuItem.Text = "&PolyRelatedness";
            this.polyRelatednessToolStripMenuItem.Click += new System.EventHandler(this.ImportPolyRelatedness);
            // 
            // spagediToolStripMenuItem
            // 
            this.spagediToolStripMenuItem.Name = "spagediToolStripMenuItem";
            this.spagediToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.spagediToolStripMenuItem.Text = "Sp&agedi";
            this.spagediToolStripMenuItem.Click += new System.EventHandler(this.ImportSpagedi);
            // 
            // genodiveToolStripMenuItem
            // 
            this.genodiveToolStripMenuItem.Name = "genodiveToolStripMenuItem";
            this.genodiveToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.genodiveToolStripMenuItem.Text = "G&enodive";
            this.genodiveToolStripMenuItem.Click += new System.EventHandler(this.ImportGenodive);
            // 
            // vCFToolStripMenuItem
            // 
            this.vCFToolStripMenuItem.Name = "vCFToolStripMenuItem";
            this.vCFToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.vCFToolStripMenuItem.Text = "&VCF";
            this.vCFToolStripMenuItem.Click += new System.EventHandler(this.ImportVCF);
            // 
            // ExportButton
            // 
            this.ExportButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ExportButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExportButton.Image = ((System.Drawing.Image)(resources.GetObject("ExportButton.Image")));
            this.ExportButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ExportButton.Name = "ExportButton";
            this.ExportButton.Size = new System.Drawing.Size(56, 28);
            this.ExportButton.Text = "&Export";
            this.ExportButton.Click += new System.EventHandler(this.toolStripButton11_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 31);
            // 
            // ModelTestButton
            // 
            this.ModelTestButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ModelTestButton.Image = ((System.Drawing.Image)(resources.GetObject("ModelTestButton.Image")));
            this.ModelTestButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ModelTestButton.Name = "ModelTestButton";
            this.ModelTestButton.Size = new System.Drawing.Size(82, 28);
            this.ModelTestButton.Text = "Model&Test";
            this.ModelTestButton.Click += new System.EventHandler(this.ModelTestButton_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // AboutButton
            // 
            this.AboutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AboutButton.Image = ((System.Drawing.Image)(resources.GetObject("AboutButton.Image")));
            this.AboutButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(54, 28);
            this.AboutButton.Text = "A&bout";
            this.AboutButton.Click += new System.EventHandler(this.ShowAbout);
            // 
            // ManualButton
            // 
            this.ManualButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ManualButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ManualButton.Image = ((System.Drawing.Image)(resources.GetObject("ManualButton.Image")));
            this.ManualButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ManualButton.Name = "ManualButton";
            this.ManualButton.Size = new System.Drawing.Size(62, 28);
            this.ManualButton.Text = "&Manual";
            this.ManualButton.Click += new System.EventHandler(this.ShowManual);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(375, 28);
            // 
            // TaskLabel
            // 
            this.TaskLabel.Name = "TaskLabel";
            this.TaskLabel.Size = new System.Drawing.Size(0, 28);
            // 
            // SimRunButton
            // 
            this.SimRunButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SimRunButton.Image = ((System.Drawing.Image)(resources.GetObject("SimRunButton.Image")));
            this.SimRunButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SimRunButton.Name = "SimRunButton";
            this.SimRunButton.Size = new System.Drawing.Size(38, 28);
            this.SimRunButton.Text = "&Run";
            this.SimRunButton.Visible = false;
            this.SimRunButton.Click += new System.EventHandler(this.RunCommand);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(97, 28);
            this.toolStripButton2.Text = "StructureSim";
            this.toolStripButton2.Visible = false;
            this.toolStripButton2.Click += new System.EventHandler(this.StructureSim);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.InputPage);
            this.tabControl1.Controls.Add(this.ParametersPage);
            this.tabControl1.Controls.Add(this.DiversityPage);
            this.tabControl1.Controls.Add(this.FrequencyPage);
            this.tabControl1.Controls.Add(this.DistributionPage);
            this.tabControl1.Controls.Add(this.LinkagePage);
            this.tabControl1.Controls.Add(this.NePage);
            this.tabControl1.Controls.Add(this.DiffPage);
            this.tabControl1.Controls.Add(this.DistPage);
            this.tabControl1.Controls.Add(this.OrdinationPage);
            this.tabControl1.Controls.Add(this.ClusteringPage);
            this.tabControl1.Controls.Add(this.InbreedingPage);
            this.tabControl1.Controls.Add(this.HIndexPage);
            this.tabControl1.Controls.Add(this.AssignmentPage);
            this.tabControl1.Controls.Add(this.SpatialPage);
            this.tabControl1.Controls.Add(this.RelationshipPage);
            this.tabControl1.Controls.Add(this.HeritabilityPage);
            this.tabControl1.Controls.Add(this.QstPage);
            this.tabControl1.Controls.Add(this.ParentagePage);
            this.tabControl1.Controls.Add(this.AMOVAPage);
            this.tabControl1.Controls.Add(this.StructurePage);
            this.tabControl1.Controls.Add(this.BayesAssPage);
            this.tabControl1.Controls.Add(this.MantelPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabControl1.Location = new System.Drawing.Point(0, 31);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1427, 752);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // InputPage
            // 
            this.InputPage.Controls.Add(this.splitContainer14);
            this.InputPage.Location = new System.Drawing.Point(4, 54);
            this.InputPage.Name = "InputPage";
            this.InputPage.Size = new System.Drawing.Size(1419, 694);
            this.InputPage.TabIndex = 0;
            this.InputPage.Text = "Input";
            this.InputPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer14
            // 
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer14.Location = new System.Drawing.Point(0, 0);
            this.splitContainer14.Name = "splitContainer14";
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.splitContainer8);
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.groupBox14);
            this.splitContainer14.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer14.SplitterDistance = 1308;
            this.splitContainer14.SplitterWidth = 5;
            this.splitContainer14.TabIndex = 3;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.groupBox8);
            this.splitContainer8.Panel1.Controls.Add(this.SimulationToolStrip);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer8.Size = new System.Drawing.Size(1308, 694);
            this.splitContainer8.SplitterDistance = 232;
            this.splitContainer8.SplitterWidth = 5;
            this.splitContainer8.TabIndex = 2;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.SimPop_AlleleFrequencyBox);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(0, 28);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1308, 204);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Simulation: Population and allele frequencies";
            // 
            // SimPop_AlleleFrequencyBox
            // 
            this.SimPop_AlleleFrequencyBox.AcceptsReturn = true;
            this.SimPop_AlleleFrequencyBox.AcceptsTab = true;
            this.SimPop_AlleleFrequencyBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SimPop_AlleleFrequencyBox.HideSelection = false;
            this.SimPop_AlleleFrequencyBox.Location = new System.Drawing.Point(3, 23);
            this.SimPop_AlleleFrequencyBox.MaxLength = 32767000;
            this.SimPop_AlleleFrequencyBox.Multiline = true;
            this.SimPop_AlleleFrequencyBox.Name = "SimPop_AlleleFrequencyBox";
            this.SimPop_AlleleFrequencyBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SimPop_AlleleFrequencyBox.Size = new System.Drawing.Size(1302, 178);
            this.SimPop_AlleleFrequencyBox.TabIndex = 2;
            this.SimPop_AlleleFrequencyBox.Text = resources.GetString("SimPop_AlleleFrequencyBox.Text");
            this.SimPop_AlleleFrequencyBox.WordWrap = false;
            this.SimPop_AlleleFrequencyBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimulationToolStrip
            // 
            this.SimulationToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.SimulationToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ReproduceFounderButton,
            this.toolStripSeparator3,
            this.toolStripLabel4,
            this.Reproduce1Button,
            this.Reproduce10Button,
            this.Reproduce100Button,
            this.Reproduce1000Button,
            this.SimulationuntilFstButton,
            this.SimPop_FstTerminalBox,
            this.toolStripSeparator1,
            this.GenLabel,
            this.FstLabel,
            this.toolStripSeparator10});
            this.SimulationToolStrip.Location = new System.Drawing.Point(0, 0);
            this.SimulationToolStrip.Name = "SimulationToolStrip";
            this.SimulationToolStrip.Size = new System.Drawing.Size(1308, 28);
            this.SimulationToolStrip.TabIndex = 0;
            this.SimulationToolStrip.Text = "toolStrip2";
            // 
            // ReproduceFounderButton
            // 
            this.ReproduceFounderButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ReproduceFounderButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ReproduceFounderButton.Image = ((System.Drawing.Image)(resources.GetObject("ReproduceFounderButton.Image")));
            this.ReproduceFounderButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ReproduceFounderButton.Name = "ReproduceFounderButton";
            this.ReproduceFounderButton.Size = new System.Drawing.Size(67, 25);
            this.ReproduceFounderButton.Text = "&Founder";
            this.ReproduceFounderButton.Click += new System.EventHandler(this.GenerageFounderPopulation);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripLabel4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripLabel4.Image")));
            this.toolStripLabel4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(88, 25);
            this.toolStripLabel4.Text = "Reproduce: ";
            // 
            // Reproduce1Button
            // 
            this.Reproduce1Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce1Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce1Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Reproduce1Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce1Button.Image")));
            this.Reproduce1Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce1Button.Name = "Reproduce1Button";
            this.Reproduce1Button.Size = new System.Drawing.Size(29, 25);
            this.Reproduce1Button.Text = "1";
            this.Reproduce1Button.Click += new System.EventHandler(this.Reproduce);
            // 
            // Reproduce10Button
            // 
            this.Reproduce10Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce10Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce10Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Reproduce10Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce10Button.Image")));
            this.Reproduce10Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce10Button.Name = "Reproduce10Button";
            this.Reproduce10Button.Size = new System.Drawing.Size(29, 25);
            this.Reproduce10Button.Text = "10";
            this.Reproduce10Button.Click += new System.EventHandler(this.Reproduce);
            // 
            // Reproduce100Button
            // 
            this.Reproduce100Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce100Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce100Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Reproduce100Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce100Button.Image")));
            this.Reproduce100Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce100Button.Name = "Reproduce100Button";
            this.Reproduce100Button.Size = new System.Drawing.Size(37, 25);
            this.Reproduce100Button.Text = "100";
            this.Reproduce100Button.Click += new System.EventHandler(this.Reproduce);
            // 
            // Reproduce1000Button
            // 
            this.Reproduce1000Button.BackColor = System.Drawing.Color.Cornsilk;
            this.Reproduce1000Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Reproduce1000Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Reproduce1000Button.Image = ((System.Drawing.Image)(resources.GetObject("Reproduce1000Button.Image")));
            this.Reproduce1000Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Reproduce1000Button.Name = "Reproduce1000Button";
            this.Reproduce1000Button.Size = new System.Drawing.Size(45, 25);
            this.Reproduce1000Button.Text = "1000";
            this.Reproduce1000Button.Click += new System.EventHandler(this.Reproduce);
            // 
            // SimulationuntilFstButton
            // 
            this.SimulationuntilFstButton.BackColor = System.Drawing.Color.Cornsilk;
            this.SimulationuntilFstButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SimulationuntilFstButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SimulationuntilFstButton.Image = ((System.Drawing.Image)(resources.GetObject("SimulationuntilFstButton.Image")));
            this.SimulationuntilFstButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SimulationuntilFstButton.Name = "SimulationuntilFstButton";
            this.SimulationuntilFstButton.Size = new System.Drawing.Size(82, 25);
            this.SimulationuntilFstButton.Text = "until Fst = ";
            this.SimulationuntilFstButton.Click += new System.EventHandler(this.ReproduceUntilFst);
            // 
            // SimPop_FstTerminalBox
            // 
            this.SimPop_FstTerminalBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SimPop_FstTerminalBox.Items.AddRange(new object[] {
            "0.01",
            "0.02",
            "0.05",
            "0.07",
            "0.10",
            "0.12",
            "0.15"});
            this.SimPop_FstTerminalBox.Name = "SimPop_FstTerminalBox";
            this.SimPop_FstTerminalBox.Size = new System.Drawing.Size(92, 28);
            this.SimPop_FstTerminalBox.Text = "0.05";
            this.SimPop_FstTerminalBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // GenLabel
            // 
            this.GenLabel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GenLabel.Name = "GenLabel";
            this.GenLabel.Size = new System.Drawing.Size(89, 25);
            this.GenLabel.Text = "Generation: ";
            this.GenLabel.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FstLabel
            // 
            this.FstLabel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FstLabel.Name = "FstLabel";
            this.FstLabel.Size = new System.Drawing.Size(34, 25);
            this.FstLabel.Text = "Fst: ";
            this.FstLabel.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 28);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FormatBox);
            this.groupBox1.Controls.Add(this.PhenotypeBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1308, 457);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input data                                           Format:";
            // 
            // FormatBox
            // 
            this.FormatBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FormatBox.FormattingEnabled = true;
            this.FormatBox.Items.AddRange(new object[] {
            "Phenotype",
            "Genotype",
            "One-digit genotype with deliminator",
            "One-digit genotype without deliminator"});
            this.FormatBox.Location = new System.Drawing.Point(317, -3);
            this.FormatBox.Margin = new System.Windows.Forms.Padding(2);
            this.FormatBox.Name = "FormatBox";
            this.FormatBox.Size = new System.Drawing.Size(307, 28);
            this.FormatBox.TabIndex = 1;
            // 
            // PhenotypeBox
            // 
            this.PhenotypeBox.AcceptsReturn = true;
            this.PhenotypeBox.AcceptsTab = true;
            this.PhenotypeBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PhenotypeBox.HideSelection = false;
            this.PhenotypeBox.Location = new System.Drawing.Point(3, 23);
            this.PhenotypeBox.MaxLength = 134217728;
            this.PhenotypeBox.Multiline = true;
            this.PhenotypeBox.Name = "PhenotypeBox";
            this.PhenotypeBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PhenotypeBox.Size = new System.Drawing.Size(1302, 431);
            this.PhenotypeBox.TabIndex = 0;
            this.PhenotypeBox.WordWrap = false;
            this.PhenotypeBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.SimRandomizeDistanceToCentermereButton);
            this.groupBox14.Controls.Add(this.SimPop_DistBox);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.label42);
            this.groupBox14.Controls.Add(this.SimPop_OutputGenotypeBox);
            this.groupBox14.Controls.Add(this.SimPop_DioeciousBox);
            this.groupBox14.Controls.Add(this.label1);
            this.groupBox14.Controls.Add(this.SimPop_NegPCRBox);
            this.groupBox14.Controls.Add(this.label37);
            this.groupBox14.Controls.Add(this.SimPop_SamplingRateBox);
            this.groupBox14.Controls.Add(this.SimPop_SelfingRateBox);
            this.groupBox14.Controls.Add(this.label36);
            this.groupBox14.Controls.Add(this.SimPop_FemaleRateBox);
            this.groupBox14.Controls.Add(this.label39);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(0, 0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(106, 694);
            this.groupBox14.TabIndex = 2;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Simulation parameters";
            // 
            // SimRandomizeDistanceToCentermereButton
            // 
            this.SimRandomizeDistanceToCentermereButton.Location = new System.Drawing.Point(38, 352);
            this.SimRandomizeDistanceToCentermereButton.Name = "SimRandomizeDistanceToCentermereButton";
            this.SimRandomizeDistanceToCentermereButton.Size = new System.Drawing.Size(135, 28);
            this.SimRandomizeDistanceToCentermereButton.TabIndex = 404;
            this.SimRandomizeDistanceToCentermereButton.Text = "Randomize";
            this.SimRandomizeDistanceToCentermereButton.UseVisualStyleBackColor = true;
            this.SimRandomizeDistanceToCentermereButton.Click += new System.EventHandler(this.RandomizeLocusDistance);
            // 
            // SimPop_DistBox
            // 
            this.SimPop_DistBox.AcceptsReturn = true;
            this.SimPop_DistBox.HideSelection = false;
            this.SimPop_DistBox.Location = new System.Drawing.Point(38, 387);
            this.SimPop_DistBox.Multiline = true;
            this.SimPop_DistBox.Name = "SimPop_DistBox";
            this.SimPop_DistBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SimPop_DistBox.Size = new System.Drawing.Size(134, 182);
            this.SimPop_DistBox.TabIndex = 403;
            this.SimPop_DistBox.Text = "25\r\n25\r\n25\r\n25\r\n25\r\n25";
            this.SimPop_DistBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(35, 572);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(150, 40);
            this.label46.TabIndex = 402;
            this.label46.Text = "Extra locus would be \r\nequal to the first";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 308);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(144, 40);
            this.label42.TabIndex = 402;
            this.label42.Text = "Distance from locus \r\nto centromere (cM)";
            // 
            // SimPop_OutputGenotypeBox
            // 
            this.SimPop_OutputGenotypeBox.AutoSize = true;
            this.SimPop_OutputGenotypeBox.Location = new System.Drawing.Point(15, 52);
            this.SimPop_OutputGenotypeBox.Name = "SimPop_OutputGenotypeBox";
            this.SimPop_OutputGenotypeBox.Size = new System.Drawing.Size(144, 24);
            this.SimPop_OutputGenotypeBox.TabIndex = 203;
            this.SimPop_OutputGenotypeBox.Text = "Output genotype";
            this.SimPop_OutputGenotypeBox.UseVisualStyleBackColor = true;
            this.SimPop_OutputGenotypeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimPop_DioeciousBox
            // 
            this.SimPop_DioeciousBox.AutoSize = true;
            this.SimPop_DioeciousBox.Location = new System.Drawing.Point(15, 27);
            this.SimPop_DioeciousBox.Name = "SimPop_DioeciousBox";
            this.SimPop_DioeciousBox.Size = new System.Drawing.Size(97, 24);
            this.SimPop_DioeciousBox.TabIndex = 200;
            this.SimPop_DioeciousBox.Text = "Dioecious";
            this.SimPop_DioeciousBox.UseVisualStyleBackColor = true;
            this.SimPop_DioeciousBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 248);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Negative PCR rate";
            // 
            // SimPop_NegPCRBox
            // 
            this.SimPop_NegPCRBox.DecimalPlaces = 4;
            this.SimPop_NegPCRBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_NegPCRBox.Location = new System.Drawing.Point(38, 272);
            this.SimPop_NegPCRBox.Name = "SimPop_NegPCRBox";
            this.SimPop_NegPCRBox.Size = new System.Drawing.Size(122, 27);
            this.SimPop_NegPCRBox.TabIndex = 205;
            this.SimPop_NegPCRBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimPop_NegPCRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(12, 192);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(102, 20);
            this.label37.TabIndex = 0;
            this.label37.Text = "Sampling rate\r\n";
            // 
            // SimPop_SamplingRateBox
            // 
            this.SimPop_SamplingRateBox.DecimalPlaces = 4;
            this.SimPop_SamplingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SamplingRateBox.Location = new System.Drawing.Point(38, 213);
            this.SimPop_SamplingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimPop_SamplingRateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SamplingRateBox.Name = "SimPop_SamplingRateBox";
            this.SimPop_SamplingRateBox.Size = new System.Drawing.Size(122, 27);
            this.SimPop_SamplingRateBox.TabIndex = 205;
            this.SimPop_SamplingRateBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.SimPop_SamplingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimPop_SelfingRateBox
            // 
            this.SimPop_SelfingRateBox.DecimalPlaces = 4;
            this.SimPop_SelfingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SelfingRateBox.Location = new System.Drawing.Point(38, 158);
            this.SimPop_SelfingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimPop_SelfingRateBox.Name = "SimPop_SelfingRateBox";
            this.SimPop_SelfingRateBox.Size = new System.Drawing.Size(122, 27);
            this.SimPop_SelfingRateBox.TabIndex = 202;
            this.SimPop_SelfingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 132);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 20);
            this.label36.TabIndex = 0;
            this.label36.Text = "Selfing rate";
            // 
            // SimPop_FemaleRateBox
            // 
            this.SimPop_FemaleRateBox.DecimalPlaces = 4;
            this.SimPop_FemaleRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Location = new System.Drawing.Point(38, 102);
            this.SimPop_FemaleRateBox.Maximum = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Name = "SimPop_FemaleRateBox";
            this.SimPop_FemaleRateBox.Size = new System.Drawing.Size(122, 27);
            this.SimPop_FemaleRateBox.TabIndex = 201;
            this.SimPop_FemaleRateBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.SimPop_FemaleRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 78);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(87, 20);
            this.label39.TabIndex = 0;
            this.label39.Text = "Female rate";
            // 
            // ParametersPage
            // 
            this.ParametersPage.Controls.Add(this.splitContainer20);
            this.ParametersPage.Location = new System.Drawing.Point(4, 54);
            this.ParametersPage.Name = "ParametersPage";
            this.ParametersPage.Size = new System.Drawing.Size(1419, 694);
            this.ParametersPage.TabIndex = 1;
            this.ParametersPage.Text = "Parameters";
            this.ParametersPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer20
            // 
            this.splitContainer20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer20.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer20.IsSplitterFixed = true;
            this.splitContainer20.Location = new System.Drawing.Point(0, 0);
            this.splitContainer20.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainer20.Name = "splitContainer20";
            // 
            // splitContainer20.Panel1
            // 
            this.splitContainer20.Panel1.AutoScroll = true;
            this.splitContainer20.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer20.Panel2
            // 
            this.splitContainer20.Panel2.Controls.Add(this.ParametersPanel);
            this.splitContainer20.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer20.SplitterDistance = 330;
            this.splitContainer20.SplitterWidth = 3;
            this.splitContainer20.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.GroupBoxMethods);
            this.panel1.Controls.Add(this.GroupBoxAlleleFrequency);
            this.panel1.Controls.Add(this.GroupBoxGeneralSettings);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(330, 694);
            this.panel1.TabIndex = 0;
            // 
            // GroupBoxMethods
            // 
            this.GroupBoxMethods.Controls.Add(this.CalcLinkageBox);
            this.GroupBoxMethods.Controls.Add(this.CalcInbreedingBox);
            this.GroupBoxMethods.Controls.Add(this.CalcNeBox);
            this.GroupBoxMethods.Controls.Add(this.CalcParentageBox);
            this.GroupBoxMethods.Controls.Add(this.CalcSpatialBox);
            this.GroupBoxMethods.Controls.Add(this.CalcQstBox);
            this.GroupBoxMethods.Controls.Add(this.CalcAMOVABox);
            this.GroupBoxMethods.Controls.Add(this.CalcDistBox);
            this.GroupBoxMethods.Controls.Add(this.CalcClusteringBox);
            this.GroupBoxMethods.Controls.Add(this.CalcHeritabilityBox);
            this.GroupBoxMethods.Controls.Add(this.CalcOrdinationBox);
            this.GroupBoxMethods.Controls.Add(this.CalcBayesAssBox);
            this.GroupBoxMethods.Controls.Add(this.CalcStructureBox);
            this.GroupBoxMethods.Controls.Add(this.CalcRelationshipBox);
            this.GroupBoxMethods.Controls.Add(this.CalcAssignmentBox);
            this.GroupBoxMethods.Controls.Add(this.CalcHIndexBox);
            this.GroupBoxMethods.Controls.Add(this.CalcDistributionBox);
            this.GroupBoxMethods.Controls.Add(this.CalcDiffBox);
            this.GroupBoxMethods.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxMethods.Location = new System.Drawing.Point(2, 2);
            this.GroupBoxMethods.Name = "GroupBoxMethods";
            this.GroupBoxMethods.Size = new System.Drawing.Size(370, 255);
            this.GroupBoxMethods.TabIndex = 6;
            this.GroupBoxMethods.TabStop = false;
            this.GroupBoxMethods.Text = "Methods";
            // 
            // CalcLinkageBox
            // 
            this.CalcLinkageBox.AutoSize = true;
            this.CalcLinkageBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CalcLinkageBox.Location = new System.Drawing.Point(192, 25);
            this.CalcLinkageBox.Name = "CalcLinkageBox";
            this.CalcLinkageBox.Size = new System.Drawing.Size(77, 24);
            this.CalcLinkageBox.TabIndex = 0;
            this.CalcLinkageBox.Text = "LD test";
            this.CalcLinkageBox.UseVisualStyleBackColor = true;
            this.CalcLinkageBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcInbreedingBox
            // 
            this.CalcInbreedingBox.AutoSize = true;
            this.CalcInbreedingBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcInbreedingBox.Location = new System.Drawing.Point(192, 100);
            this.CalcInbreedingBox.Name = "CalcInbreedingBox";
            this.CalcInbreedingBox.Size = new System.Drawing.Size(172, 24);
            this.CalcInbreedingBox.TabIndex = 0;
            this.CalcInbreedingBox.Text = "Individual inbreeding";
            this.CalcInbreedingBox.UseVisualStyleBackColor = true;
            this.CalcInbreedingBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcNeBox
            // 
            this.CalcNeBox.AutoSize = true;
            this.CalcNeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CalcNeBox.Location = new System.Drawing.Point(15, 48);
            this.CalcNeBox.Name = "CalcNeBox";
            this.CalcNeBox.Size = new System.Drawing.Size(50, 24);
            this.CalcNeBox.TabIndex = 2;
            this.CalcNeBox.Text = "Ne";
            this.CalcNeBox.UseVisualStyleBackColor = true;
            this.CalcNeBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcParentageBox
            // 
            this.CalcParentageBox.AutoSize = true;
            this.CalcParentageBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcParentageBox.Location = new System.Drawing.Point(15, 200);
            this.CalcParentageBox.Name = "CalcParentageBox";
            this.CalcParentageBox.Size = new System.Drawing.Size(152, 24);
            this.CalcParentageBox.TabIndex = 1;
            this.CalcParentageBox.Text = "Parentage analysis";
            this.CalcParentageBox.UseVisualStyleBackColor = true;
            this.CalcParentageBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcSpatialBox
            // 
            this.CalcSpatialBox.AutoSize = true;
            this.CalcSpatialBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcSpatialBox.Location = new System.Drawing.Point(15, 150);
            this.CalcSpatialBox.Name = "CalcSpatialBox";
            this.CalcSpatialBox.Size = new System.Drawing.Size(129, 24);
            this.CalcSpatialBox.TabIndex = 0;
            this.CalcSpatialBox.Text = "Spatial pattern";
            this.CalcSpatialBox.UseVisualStyleBackColor = true;
            this.CalcSpatialBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcQstBox
            // 
            this.CalcQstBox.AutoSize = true;
            this.CalcQstBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcQstBox.Location = new System.Drawing.Point(192, 175);
            this.CalcQstBox.Name = "CalcQstBox";
            this.CalcQstBox.Size = new System.Drawing.Size(53, 24);
            this.CalcQstBox.TabIndex = 0;
            this.CalcQstBox.Text = "Qst";
            this.CalcQstBox.UseVisualStyleBackColor = true;
            this.CalcQstBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcAMOVABox
            // 
            this.CalcAMOVABox.AutoSize = true;
            this.CalcAMOVABox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcAMOVABox.Location = new System.Drawing.Point(192, 200);
            this.CalcAMOVABox.Name = "CalcAMOVABox";
            this.CalcAMOVABox.Size = new System.Drawing.Size(83, 24);
            this.CalcAMOVABox.TabIndex = 0;
            this.CalcAMOVABox.Text = "AMOVA";
            this.CalcAMOVABox.UseVisualStyleBackColor = true;
            this.CalcAMOVABox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcDistBox
            // 
            this.CalcDistBox.AutoSize = true;
            this.CalcDistBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcDistBox.Location = new System.Drawing.Point(15, 75);
            this.CalcDistBox.Name = "CalcDistBox";
            this.CalcDistBox.Size = new System.Drawing.Size(140, 24);
            this.CalcDistBox.TabIndex = 0;
            this.CalcDistBox.Text = "Genetic distance";
            this.CalcDistBox.UseVisualStyleBackColor = true;
            this.CalcDistBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcClusteringBox
            // 
            this.CalcClusteringBox.AutoSize = true;
            this.CalcClusteringBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcClusteringBox.Location = new System.Drawing.Point(15, 100);
            this.CalcClusteringBox.Name = "CalcClusteringBox";
            this.CalcClusteringBox.Size = new System.Drawing.Size(178, 24);
            this.CalcClusteringBox.TabIndex = 0;
            this.CalcClusteringBox.Text = "Hierarchical clustering";
            this.CalcClusteringBox.UseVisualStyleBackColor = true;
            this.CalcClusteringBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcHeritabilityBox
            // 
            this.CalcHeritabilityBox.AutoSize = true;
            this.CalcHeritabilityBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcHeritabilityBox.Location = new System.Drawing.Point(15, 175);
            this.CalcHeritabilityBox.Name = "CalcHeritabilityBox";
            this.CalcHeritabilityBox.Size = new System.Drawing.Size(105, 24);
            this.CalcHeritabilityBox.TabIndex = 0;
            this.CalcHeritabilityBox.Text = "Heritability";
            this.CalcHeritabilityBox.UseVisualStyleBackColor = true;
            this.CalcHeritabilityBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcOrdinationBox
            // 
            this.CalcOrdinationBox.AutoSize = true;
            this.CalcOrdinationBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcOrdinationBox.Location = new System.Drawing.Point(192, 75);
            this.CalcOrdinationBox.Name = "CalcOrdinationBox";
            this.CalcOrdinationBox.Size = new System.Drawing.Size(102, 24);
            this.CalcOrdinationBox.TabIndex = 0;
            this.CalcOrdinationBox.Text = "Ordination";
            this.CalcOrdinationBox.UseVisualStyleBackColor = true;
            this.CalcOrdinationBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcBayesAssBox
            // 
            this.CalcBayesAssBox.AutoSize = true;
            this.CalcBayesAssBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcBayesAssBox.Location = new System.Drawing.Point(192, 225);
            this.CalcBayesAssBox.Name = "CalcBayesAssBox";
            this.CalcBayesAssBox.Size = new System.Drawing.Size(91, 24);
            this.CalcBayesAssBox.TabIndex = 0;
            this.CalcBayesAssBox.Text = "BayesAss";
            this.CalcBayesAssBox.UseVisualStyleBackColor = true;
            this.CalcBayesAssBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcStructureBox
            // 
            this.CalcStructureBox.AutoSize = true;
            this.CalcStructureBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcStructureBox.Location = new System.Drawing.Point(15, 225);
            this.CalcStructureBox.Name = "CalcStructureBox";
            this.CalcStructureBox.Size = new System.Drawing.Size(90, 24);
            this.CalcStructureBox.TabIndex = 0;
            this.CalcStructureBox.Text = "Structure";
            this.CalcStructureBox.UseVisualStyleBackColor = true;
            this.CalcStructureBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcRelationshipBox
            // 
            this.CalcRelationshipBox.AutoSize = true;
            this.CalcRelationshipBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcRelationshipBox.Location = new System.Drawing.Point(192, 150);
            this.CalcRelationshipBox.Name = "CalcRelationshipBox";
            this.CalcRelationshipBox.Size = new System.Drawing.Size(149, 24);
            this.CalcRelationshipBox.TabIndex = 0;
            this.CalcRelationshipBox.Text = "Relationship coef.";
            this.CalcRelationshipBox.UseVisualStyleBackColor = true;
            this.CalcRelationshipBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcAssignmentBox
            // 
            this.CalcAssignmentBox.AutoSize = true;
            this.CalcAssignmentBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcAssignmentBox.Location = new System.Drawing.Point(192, 125);
            this.CalcAssignmentBox.Name = "CalcAssignmentBox";
            this.CalcAssignmentBox.Size = new System.Drawing.Size(181, 24);
            this.CalcAssignmentBox.TabIndex = 0;
            this.CalcAssignmentBox.Text = "Population assignment";
            this.CalcAssignmentBox.UseVisualStyleBackColor = true;
            this.CalcAssignmentBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcHIndexBox
            // 
            this.CalcHIndexBox.AutoSize = true;
            this.CalcHIndexBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcHIndexBox.Location = new System.Drawing.Point(15, 125);
            this.CalcHIndexBox.Name = "CalcHIndexBox";
            this.CalcHIndexBox.Size = new System.Drawing.Size(153, 24);
            this.CalcHIndexBox.TabIndex = 0;
            this.CalcHIndexBox.Text = "Individual H-index";
            this.CalcHIndexBox.UseVisualStyleBackColor = true;
            this.CalcHIndexBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcDistributionBox
            // 
            this.CalcDistributionBox.AutoSize = true;
            this.CalcDistributionBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CalcDistributionBox.Location = new System.Drawing.Point(15, 25);
            this.CalcDistributionBox.Name = "CalcDistributionBox";
            this.CalcDistributionBox.Size = new System.Drawing.Size(180, 24);
            this.CalcDistributionBox.TabIndex = 0;
            this.CalcDistributionBox.Text = "Pheno distribution test";
            this.CalcDistributionBox.UseVisualStyleBackColor = true;
            this.CalcDistributionBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // CalcDiffBox
            // 
            this.CalcDiffBox.AutoSize = true;
            this.CalcDiffBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcDiffBox.Location = new System.Drawing.Point(192, 50);
            this.CalcDiffBox.Name = "CalcDiffBox";
            this.CalcDiffBox.Size = new System.Drawing.Size(176, 24);
            this.CalcDiffBox.TabIndex = 0;
            this.CalcDiffBox.Text = "Genetic differentation";
            this.CalcDiffBox.UseVisualStyleBackColor = true;
            this.CalcDiffBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // GroupBoxAlleleFrequency
            // 
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencyNrRateBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.label35);
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencySelfingRateEstimatorBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencySelfingBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencyNegPCRBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencyNullAlleleBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.FrequencyInheritanceModeBox);
            this.GroupBoxAlleleFrequency.Controls.Add(this.label17);
            this.GroupBoxAlleleFrequency.Controls.Add(this.label43);
            this.GroupBoxAlleleFrequency.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxAlleleFrequency.Location = new System.Drawing.Point(2, 548);
            this.GroupBoxAlleleFrequency.Name = "GroupBoxAlleleFrequency";
            this.GroupBoxAlleleFrequency.Size = new System.Drawing.Size(370, 145);
            this.GroupBoxAlleleFrequency.TabIndex = 3;
            this.GroupBoxAlleleFrequency.TabStop = false;
            this.GroupBoxAlleleFrequency.Text = "Allele frequency estimator";
            // 
            // FrequencyNrRateBox
            // 
            this.FrequencyNrRateBox.DecimalPlaces = 4;
            this.FrequencyNrRateBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencyNrRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.FrequencyNrRateBox.Location = new System.Drawing.Point(267, 110);
            this.FrequencyNrRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.FrequencyNrRateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.FrequencyNrRateBox.Name = "FrequencyNrRateBox";
            this.FrequencyNrRateBox.Size = new System.Drawing.Size(93, 27);
            this.FrequencyNrRateBox.TabIndex = 518;
            this.FrequencyNrRateBox.Value = new decimal(new int[] {
            75,
            0,
            0,
            131072});
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label35.Location = new System.Drawing.Point(8, 112);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(185, 20);
            this.label35.TabIndex = 517;
            this.label35.Text = "Prop. putative nonrelatives";
            // 
            // FrequencySelfingRateEstimatorBox
            // 
            this.FrequencySelfingRateEstimatorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FrequencySelfingRateEstimatorBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencySelfingRateEstimatorBox.FormattingEnabled = true;
            this.FrequencySelfingRateEstimatorBox.Items.AddRange(new object[] {
            "Maximum-likelihood",
            "Hardy 2016 Fz-based ",
            "Hardy 2016 g2z-based "});
            this.FrequencySelfingRateEstimatorBox.Location = new System.Drawing.Point(160, 52);
            this.FrequencySelfingRateEstimatorBox.Name = "FrequencySelfingRateEstimatorBox";
            this.FrequencySelfingRateEstimatorBox.Size = new System.Drawing.Size(201, 28);
            this.FrequencySelfingRateEstimatorBox.TabIndex = 516;
            this.FrequencySelfingRateEstimatorBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencySelfingBox
            // 
            this.FrequencySelfingBox.AutoSize = true;
            this.FrequencySelfingBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencySelfingBox.Location = new System.Drawing.Point(275, 25);
            this.FrequencySelfingBox.Name = "FrequencySelfingBox";
            this.FrequencySelfingBox.Size = new System.Drawing.Size(77, 24);
            this.FrequencySelfingBox.TabIndex = 300;
            this.FrequencySelfingBox.Text = "Selfing";
            this.FrequencySelfingBox.UseVisualStyleBackColor = true;
            this.FrequencySelfingBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyNegPCRBox
            // 
            this.FrequencyNegPCRBox.AutoSize = true;
            this.FrequencyNegPCRBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencyNegPCRBox.Location = new System.Drawing.Point(132, 25);
            this.FrequencyNegPCRBox.Name = "FrequencyNegPCRBox";
            this.FrequencyNegPCRBox.Size = new System.Drawing.Size(121, 24);
            this.FrequencyNegPCRBox.TabIndex = 300;
            this.FrequencyNegPCRBox.Text = "Negative PCR";
            this.FrequencyNegPCRBox.UseVisualStyleBackColor = true;
            this.FrequencyNegPCRBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyNullAlleleBox
            // 
            this.FrequencyNullAlleleBox.AutoSize = true;
            this.FrequencyNullAlleleBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencyNullAlleleBox.Location = new System.Drawing.Point(8, 25);
            this.FrequencyNullAlleleBox.Name = "FrequencyNullAlleleBox";
            this.FrequencyNullAlleleBox.Size = new System.Drawing.Size(104, 24);
            this.FrequencyNullAlleleBox.TabIndex = 300;
            this.FrequencyNullAlleleBox.Text = "Null alleles";
            this.FrequencyNullAlleleBox.UseVisualStyleBackColor = true;
            this.FrequencyNullAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyInheritanceModeBox
            // 
            this.FrequencyInheritanceModeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FrequencyInheritanceModeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencyInheritanceModeBox.FormattingEnabled = true;
            this.FrequencyInheritanceModeBox.Items.AddRange(new object[] {
            "Disomic/Polysomic (RCS)",
            "Polysomic (PRCS)",
            "Polysomic (CES)",
            "Polysomic (PES rs = 0.25)",
            "Polysomic (PES rs = 0.5)",
            "Polysomic (PES estimate rs)"});
            this.FrequencyInheritanceModeBox.Location = new System.Drawing.Point(160, 80);
            this.FrequencyInheritanceModeBox.Name = "FrequencyInheritanceModeBox";
            this.FrequencyInheritanceModeBox.Size = new System.Drawing.Size(201, 28);
            this.FrequencyInheritanceModeBox.TabIndex = 400;
            this.FrequencyInheritanceModeBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label17.Location = new System.Drawing.Point(8, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(152, 20);
            this.label17.TabIndex = 5;
            this.label17.Text = "Selfing rate estimator";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label43.Location = new System.Drawing.Point(8, 83);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(129, 20);
            this.label43.TabIndex = 5;
            this.label43.Text = "Inheritance model";
            // 
            // GroupBoxGeneralSettings
            // 
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalWarningBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.button5);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalRandomizeSeedButton);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalFoldControlBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.FrequencyRemoveDupAlleleBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalSeedBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalThreadBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalRefreshSeedBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalRegionBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.GlobalDecimalPlaceBox);
            this.GroupBoxGeneralSettings.Controls.Add(this.label10);
            this.GroupBoxGeneralSettings.Controls.Add(this.label20);
            this.GroupBoxGeneralSettings.Controls.Add(this.label7);
            this.GroupBoxGeneralSettings.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxGeneralSettings.Location = new System.Drawing.Point(2, 263);
            this.GroupBoxGeneralSettings.Name = "GroupBoxGeneralSettings";
            this.GroupBoxGeneralSettings.Size = new System.Drawing.Size(370, 277);
            this.GroupBoxGeneralSettings.TabIndex = 5;
            this.GroupBoxGeneralSettings.TabStop = false;
            this.GroupBoxGeneralSettings.Text = "General settings";
            // 
            // GlobalWarningBox
            // 
            this.GlobalWarningBox.AutoSize = true;
            this.GlobalWarningBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalWarningBox.Location = new System.Drawing.Point(210, 107);
            this.GlobalWarningBox.Name = "GlobalWarningBox";
            this.GlobalWarningBox.Size = new System.Drawing.Size(156, 24);
            this.GlobalWarningBox.TabIndex = 505;
            this.GlobalWarningBox.Text = "Show warning msg";
            this.GlobalWarningBox.UseVisualStyleBackColor = true;
            this.GlobalWarningBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button5.Location = new System.Drawing.Point(207, 52);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(157, 30);
            this.button5.TabIndex = 507;
            this.button5.Text = "Default settings";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.DefaultSettings);
            // 
            // GlobalRandomizeSeedButton
            // 
            this.GlobalRandomizeSeedButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalRandomizeSeedButton.Location = new System.Drawing.Point(10, 52);
            this.GlobalRandomizeSeedButton.Name = "GlobalRandomizeSeedButton";
            this.GlobalRandomizeSeedButton.Size = new System.Drawing.Size(82, 30);
            this.GlobalRandomizeSeedButton.TabIndex = 507;
            this.GlobalRandomizeSeedButton.Text = "RNG seed";
            this.GlobalRandomizeSeedButton.UseVisualStyleBackColor = true;
            this.GlobalRandomizeSeedButton.Click += new System.EventHandler(this.RandomizeGlobalSeed);
            // 
            // GlobalFoldControlBox
            // 
            this.GlobalFoldControlBox.AutoSize = true;
            this.GlobalFoldControlBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalFoldControlBox.Location = new System.Drawing.Point(12, 82);
            this.GlobalFoldControlBox.Name = "GlobalFoldControlBox";
            this.GlobalFoldControlBox.Size = new System.Drawing.Size(117, 24);
            this.GlobalFoldControlBox.TabIndex = 300;
            this.GlobalFoldControlBox.Text = "Fold controls";
            this.GlobalFoldControlBox.UseVisualStyleBackColor = true;
            this.GlobalFoldControlBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // FrequencyRemoveDupAlleleBox
            // 
            this.FrequencyRemoveDupAlleleBox.AutoSize = true;
            this.FrequencyRemoveDupAlleleBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FrequencyRemoveDupAlleleBox.Location = new System.Drawing.Point(12, 107);
            this.FrequencyRemoveDupAlleleBox.Name = "FrequencyRemoveDupAlleleBox";
            this.FrequencyRemoveDupAlleleBox.Size = new System.Drawing.Size(197, 24);
            this.FrequencyRemoveDupAlleleBox.TabIndex = 300;
            this.FrequencyRemoveDupAlleleBox.Text = "Remove duplicate alleles";
            this.FrequencyRemoveDupAlleleBox.UseVisualStyleBackColor = true;
            this.FrequencyRemoveDupAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalSeedBox
            // 
            this.GlobalSeedBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalSeedBox.Location = new System.Drawing.Point(100, 52);
            this.GlobalSeedBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.GlobalSeedBox.Name = "GlobalSeedBox";
            this.GlobalSeedBox.Size = new System.Drawing.Size(82, 27);
            this.GlobalSeedBox.TabIndex = 506;
            this.GlobalSeedBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalThreadBox
            // 
            this.GlobalThreadBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalThreadBox.Location = new System.Drawing.Point(100, 25);
            this.GlobalThreadBox.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.GlobalThreadBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.GlobalThreadBox.Name = "GlobalThreadBox";
            this.GlobalThreadBox.Size = new System.Drawing.Size(82, 27);
            this.GlobalThreadBox.TabIndex = 506;
            this.GlobalThreadBox.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.GlobalThreadBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalRefreshSeedBox
            // 
            this.GlobalRefreshSeedBox.AutoSize = true;
            this.GlobalRefreshSeedBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalRefreshSeedBox.Location = new System.Drawing.Point(210, 82);
            this.GlobalRefreshSeedBox.Name = "GlobalRefreshSeedBox";
            this.GlobalRefreshSeedBox.Size = new System.Drawing.Size(149, 24);
            this.GlobalRefreshSeedBox.TabIndex = 505;
            this.GlobalRefreshSeedBox.Text = "Auto update seed";
            this.GlobalRefreshSeedBox.UseVisualStyleBackColor = true;
            this.GlobalRefreshSeedBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalRegionBox
            // 
            this.GlobalRegionBox.AcceptsReturn = true;
            this.GlobalRegionBox.AcceptsTab = true;
            this.GlobalRegionBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalRegionBox.HideSelection = false;
            this.GlobalRegionBox.Location = new System.Drawing.Point(27, 157);
            this.GlobalRegionBox.Multiline = true;
            this.GlobalRegionBox.Name = "GlobalRegionBox";
            this.GlobalRegionBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.GlobalRegionBox.Size = new System.Drawing.Size(334, 111);
            this.GlobalRegionBox.TabIndex = 403;
            this.GlobalRegionBox.Text = "A1:pop1,pop2\r\nA2:pop3\r\nNEXTLEVEL\r\nB1:A1,A2";
            this.GlobalRegionBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalDecimalPlaceBox
            // 
            this.GlobalDecimalPlaceBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalDecimalPlaceBox.Location = new System.Drawing.Point(312, 25);
            this.GlobalDecimalPlaceBox.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.Name = "GlobalDecimalPlaceBox";
            this.GlobalDecimalPlaceBox.Size = new System.Drawing.Size(52, 27);
            this.GlobalDecimalPlaceBox.TabIndex = 500;
            this.GlobalDecimalPlaceBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label10.Location = new System.Drawing.Point(22, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 20);
            this.label10.TabIndex = 5;
            this.label10.Text = "#Threads";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label20.Location = new System.Drawing.Point(202, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(110, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Decimal places";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label7.Location = new System.Drawing.Point(10, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 20);
            this.label7.TabIndex = 402;
            this.label7.Text = "Region definition";
            // 
            // ParametersPanel
            // 
            this.ParametersPanel.AutoScroll = true;
            this.ParametersPanel.Controls.Add(this.GroupBoxHeritability);
            this.ParametersPanel.Controls.Add(this.GroupBoxNe);
            this.ParametersPanel.Controls.Add(this.GroupBoxDistribution);
            this.ParametersPanel.Controls.Add(this.GroupBoxStructure);
            this.ParametersPanel.Controls.Add(this.GroupBoxLinkage);
            this.ParametersPanel.Controls.Add(this.GroupBoxOrdination);
            this.ParametersPanel.Controls.Add(this.GroupBoxDiff);
            this.ParametersPanel.Controls.Add(this.GroupBoxAssignment);
            this.ParametersPanel.Controls.Add(this.GroupBoxSpatial);
            this.ParametersPanel.Controls.Add(this.GroupBoxBayesAss);
            this.ParametersPanel.Controls.Add(this.GroupBoxClustering);
            this.ParametersPanel.Controls.Add(this.GroupBoxAMOVA);
            this.ParametersPanel.Controls.Add(this.GroupBoxParentage);
            this.ParametersPanel.Controls.Add(this.GroupBoxDist);
            this.ParametersPanel.Controls.Add(this.GroupBoxRelationship);
            this.ParametersPanel.Controls.Add(this.GroupBoxInbreeding);
            this.ParametersPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParametersPanel.Location = new System.Drawing.Point(0, 0);
            this.ParametersPanel.Margin = new System.Windows.Forms.Padding(0);
            this.ParametersPanel.Name = "ParametersPanel";
            this.ParametersPanel.Size = new System.Drawing.Size(1086, 694);
            this.ParametersPanel.TabIndex = 1;
            // 
            // GroupBoxHeritability
            // 
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityJackknifeBox);
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityHuangMLBox);
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityThomas2000Box);
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityMousseau1998Box);
            this.GroupBoxHeritability.Controls.Add(this.label16);
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityHuangMOMBox);
            this.GroupBoxHeritability.Controls.Add(this.HeritabilityRitland1996Box);
            this.GroupBoxHeritability.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxHeritability.Location = new System.Drawing.Point(378, 518);
            this.GroupBoxHeritability.Name = "GroupBoxHeritability";
            this.GroupBoxHeritability.Size = new System.Drawing.Size(370, 147);
            this.GroupBoxHeritability.TabIndex = 10;
            this.GroupBoxHeritability.TabStop = false;
            this.GroupBoxHeritability.Text = "Heritability";
            // 
            // HeritabilityJackknifeBox
            // 
            this.HeritabilityJackknifeBox.AutoSize = true;
            this.HeritabilityJackknifeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityJackknifeBox.Location = new System.Drawing.Point(13, 117);
            this.HeritabilityJackknifeBox.Name = "HeritabilityJackknifeBox";
            this.HeritabilityJackknifeBox.Size = new System.Drawing.Size(247, 24);
            this.HeritabilityJackknifeBox.TabIndex = 409;
            this.HeritabilityJackknifeBox.Text = "Estimate SE by Jackknife method";
            this.HeritabilityJackknifeBox.UseVisualStyleBackColor = true;
            // 
            // HeritabilityHuangMLBox
            // 
            this.HeritabilityHuangMLBox.AutoSize = true;
            this.HeritabilityHuangMLBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityHuangMLBox.Location = new System.Drawing.Point(187, 67);
            this.HeritabilityHuangMLBox.Name = "HeritabilityHuangMLBox";
            this.HeritabilityHuangMLBox.Size = new System.Drawing.Size(145, 24);
            this.HeritabilityHuangMLBox.TabIndex = 403;
            this.HeritabilityHuangMLBox.Text = "Huang unpub ML";
            this.HeritabilityHuangMLBox.UseVisualStyleBackColor = true;
            this.HeritabilityHuangMLBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // HeritabilityThomas2000Box
            // 
            this.HeritabilityThomas2000Box.AutoSize = true;
            this.HeritabilityThomas2000Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityThomas2000Box.Location = new System.Drawing.Point(25, 67);
            this.HeritabilityThomas2000Box.Name = "HeritabilityThomas2000Box";
            this.HeritabilityThomas2000Box.Size = new System.Drawing.Size(143, 24);
            this.HeritabilityThomas2000Box.TabIndex = 403;
            this.HeritabilityThomas2000Box.Text = "Thomas 2000 ML";
            this.HeritabilityThomas2000Box.UseVisualStyleBackColor = true;
            this.HeritabilityThomas2000Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // HeritabilityMousseau1998Box
            // 
            this.HeritabilityMousseau1998Box.AutoSize = true;
            this.HeritabilityMousseau1998Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityMousseau1998Box.Location = new System.Drawing.Point(187, 42);
            this.HeritabilityMousseau1998Box.Name = "HeritabilityMousseau1998Box";
            this.HeritabilityMousseau1998Box.Size = new System.Drawing.Size(157, 24);
            this.HeritabilityMousseau1998Box.TabIndex = 403;
            this.HeritabilityMousseau1998Box.Text = "Mousseau 1998 ML";
            this.HeritabilityMousseau1998Box.UseVisualStyleBackColor = true;
            this.HeritabilityMousseau1998Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label16.Location = new System.Drawing.Point(10, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 20);
            this.label16.TabIndex = 407;
            this.label16.Text = "Estimators";
            // 
            // HeritabilityHuangMOMBox
            // 
            this.HeritabilityHuangMOMBox.AutoSize = true;
            this.HeritabilityHuangMOMBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityHuangMOMBox.Location = new System.Drawing.Point(25, 92);
            this.HeritabilityHuangMOMBox.Name = "HeritabilityHuangMOMBox";
            this.HeritabilityHuangMOMBox.Size = new System.Drawing.Size(162, 24);
            this.HeritabilityHuangMOMBox.TabIndex = 405;
            this.HeritabilityHuangMOMBox.Text = "Huang unpub MOM";
            this.HeritabilityHuangMOMBox.UseVisualStyleBackColor = true;
            this.HeritabilityHuangMOMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // HeritabilityRitland1996Box
            // 
            this.HeritabilityRitland1996Box.AutoSize = true;
            this.HeritabilityRitland1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.HeritabilityRitland1996Box.Location = new System.Drawing.Point(25, 42);
            this.HeritabilityRitland1996Box.Name = "HeritabilityRitland1996Box";
            this.HeritabilityRitland1996Box.Size = new System.Drawing.Size(155, 24);
            this.HeritabilityRitland1996Box.TabIndex = 405;
            this.HeritabilityRitland1996Box.Text = "Ritland 1996 MOM";
            this.HeritabilityRitland1996Box.UseVisualStyleBackColor = true;
            this.HeritabilityRitland1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxNe
            // 
            this.GroupBoxNe.Controls.Add(this.NeWaplesFBox);
            this.GroupBoxNe.Controls.Add(this.NeWaplesMSBox);
            this.GroupBoxNe.Controls.Add(this.NeWaples2010Box);
            this.GroupBoxNe.Controls.Add(this.NePudovkin1996Box);
            this.GroupBoxNe.Controls.Add(this.NeNomura2008Box);
            this.GroupBoxNe.Controls.Add(this.label111);
            this.GroupBoxNe.Controls.Add(this.Label109);
            this.GroupBoxNe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxNe.Location = new System.Drawing.Point(757, 2);
            this.GroupBoxNe.Name = "GroupBoxNe";
            this.GroupBoxNe.Size = new System.Drawing.Size(370, 133);
            this.GroupBoxNe.TabIndex = 11;
            this.GroupBoxNe.TabStop = false;
            this.GroupBoxNe.Text = "Effective population size";
            // 
            // NeWaplesFBox
            // 
            this.NeWaplesFBox.DecimalPlaces = 4;
            this.NeWaplesFBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NeWaplesFBox.Location = new System.Drawing.Point(267, 95);
            this.NeWaplesFBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.NeWaplesFBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.NeWaplesFBox.Name = "NeWaplesFBox";
            this.NeWaplesFBox.Size = new System.Drawing.Size(80, 27);
            this.NeWaplesFBox.TabIndex = 202;
            this.NeWaplesFBox.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.NeWaplesFBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // NeWaplesMSBox
            // 
            this.NeWaplesMSBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.NeWaplesMSBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NeWaplesMSBox.FormattingEnabled = true;
            this.NeWaplesMSBox.Items.AddRange(new object[] {
            "HS: haplotype sampling",
            "MS: monoecious with selfing",
            "ME: monoecious excludes selfing ",
            "DR: dioecious with random pairing",
            "DH: dioecious with lifetime pairing"});
            this.NeWaplesMSBox.Location = new System.Drawing.Point(42, 95);
            this.NeWaplesMSBox.Name = "NeWaplesMSBox";
            this.NeWaplesMSBox.Size = new System.Drawing.Size(196, 28);
            this.NeWaplesMSBox.TabIndex = 204;
            this.NeWaplesMSBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // NeWaples2010Box
            // 
            this.NeWaples2010Box.AutoSize = true;
            this.NeWaples2010Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NeWaples2010Box.Location = new System.Drawing.Point(15, 48);
            this.NeWaples2010Box.Name = "NeWaples2010Box";
            this.NeWaples2010Box.Size = new System.Drawing.Size(155, 24);
            this.NeWaples2010Box.TabIndex = 203;
            this.NeWaples2010Box.Text = "Waples && Do 2010";
            this.NeWaples2010Box.UseVisualStyleBackColor = true;
            this.NeWaples2010Box.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // NePudovkin1996Box
            // 
            this.NePudovkin1996Box.AutoSize = true;
            this.NePudovkin1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NePudovkin1996Box.Location = new System.Drawing.Point(15, 25);
            this.NePudovkin1996Box.Name = "NePudovkin1996Box";
            this.NePudovkin1996Box.Size = new System.Drawing.Size(127, 24);
            this.NePudovkin1996Box.TabIndex = 203;
            this.NePudovkin1996Box.Text = "Pudovkin 1996";
            this.NePudovkin1996Box.UseVisualStyleBackColor = true;
            this.NePudovkin1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // NeNomura2008Box
            // 
            this.NeNomura2008Box.AutoSize = true;
            this.NeNomura2008Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NeNomura2008Box.Location = new System.Drawing.Point(218, 22);
            this.NeNomura2008Box.Name = "NeNomura2008Box";
            this.NeNomura2008Box.Size = new System.Drawing.Size(121, 24);
            this.NeNomura2008Box.TabIndex = 203;
            this.NeNomura2008Box.Text = "Nomura 2008";
            this.NeNomura2008Box.UseVisualStyleBackColor = true;
            this.NeNomura2008Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label111.Location = new System.Drawing.Point(260, 73);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(104, 20);
            this.label111.TabIndex = 0;
            this.label111.Text = "Sex ratio (M:F)";
            // 
            // Label109
            // 
            this.Label109.AutoSize = true;
            this.Label109.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label109.Location = new System.Drawing.Point(30, 73);
            this.Label109.Name = "Label109";
            this.Label109.Size = new System.Drawing.Size(105, 20);
            this.Label109.TabIndex = 0;
            this.Label109.Text = "Mating system";
            // 
            // GroupBoxDistribution
            // 
            this.GroupBoxDistribution.Controls.Add(this.PhenotypeTestTotBox);
            this.GroupBoxDistribution.Controls.Add(this.PhenotypeTestRegBox);
            this.GroupBoxDistribution.Controls.Add(this.PhenotypeTestPopBox);
            this.GroupBoxDistribution.Controls.Add(this.label98);
            this.GroupBoxDistribution.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxDistribution.Location = new System.Drawing.Point(2, 2);
            this.GroupBoxDistribution.Name = "GroupBoxDistribution";
            this.GroupBoxDistribution.Size = new System.Drawing.Size(370, 58);
            this.GroupBoxDistribution.TabIndex = 10;
            this.GroupBoxDistribution.TabStop = false;
            this.GroupBoxDistribution.Text = "Pheno/geno distribution test";
            // 
            // PhenotypeTestTotBox
            // 
            this.PhenotypeTestTotBox.AutoSize = true;
            this.PhenotypeTestTotBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PhenotypeTestTotBox.Location = new System.Drawing.Point(262, 25);
            this.PhenotypeTestTotBox.Name = "PhenotypeTestTotBox";
            this.PhenotypeTestTotBox.Size = new System.Drawing.Size(98, 24);
            this.PhenotypeTestTotBox.TabIndex = 3;
            this.PhenotypeTestTotBox.Text = "Total pop.";
            this.PhenotypeTestTotBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // PhenotypeTestRegBox
            // 
            this.PhenotypeTestRegBox.AutoSize = true;
            this.PhenotypeTestRegBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PhenotypeTestRegBox.Location = new System.Drawing.Point(178, 25);
            this.PhenotypeTestRegBox.Name = "PhenotypeTestRegBox";
            this.PhenotypeTestRegBox.Size = new System.Drawing.Size(78, 24);
            this.PhenotypeTestRegBox.TabIndex = 2;
            this.PhenotypeTestRegBox.Text = "Region";
            this.PhenotypeTestRegBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // PhenotypeTestPopBox
            // 
            this.PhenotypeTestPopBox.AutoSize = true;
            this.PhenotypeTestPopBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PhenotypeTestPopBox.Location = new System.Drawing.Point(65, 25);
            this.PhenotypeTestPopBox.Name = "PhenotypeTestPopBox";
            this.PhenotypeTestPopBox.Size = new System.Drawing.Size(102, 24);
            this.PhenotypeTestPopBox.TabIndex = 1;
            this.PhenotypeTestPopBox.Text = "Population";
            this.PhenotypeTestPopBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label98.Location = new System.Drawing.Point(10, 25);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(51, 20);
            this.label98.TabIndex = 514;
            this.label98.Text = "Range";
            // 
            // GroupBoxStructure
            // 
            this.GroupBoxStructure.Controls.Add(this.label106);
            this.GroupBoxStructure.Controls.Add(this.StructureADMBurninBox);
            this.GroupBoxStructure.Controls.Add(this.StructureKmaxBox);
            this.GroupBoxStructure.Controls.Add(this.StructureNThinningBox);
            this.GroupBoxStructure.Controls.Add(this.StructureBurninBox);
            this.GroupBoxStructure.Controls.Add(this.StructureNRepsBox);
            this.GroupBoxStructure.Controls.Add(this.label26);
            this.GroupBoxStructure.Controls.Add(this.label25);
            this.GroupBoxStructure.Controls.Add(this.label34);
            this.GroupBoxStructure.Controls.Add(this.label24);
            this.GroupBoxStructure.Controls.Add(this.label41);
            this.GroupBoxStructure.Controls.Add(this.label33);
            this.GroupBoxStructure.Controls.Add(this.label23);
            this.GroupBoxStructure.Controls.Add(this.label49);
            this.GroupBoxStructure.Controls.Add(this.label100);
            this.GroupBoxStructure.Controls.Add(this.label22);
            this.GroupBoxStructure.Controls.Add(this.StructureEpsGammaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureEpsEtaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureFPriorStdBox);
            this.GroupBoxStructure.Controls.Add(this.StructureEpsRBox);
            this.GroupBoxStructure.Controls.Add(this.label99);
            this.GroupBoxStructure.Controls.Add(this.label48);
            this.GroupBoxStructure.Controls.Add(this.label21);
            this.GroupBoxStructure.Controls.Add(this.StructureFStdFBox);
            this.GroupBoxStructure.Controls.Add(this.StructureFPriorMeanBox);
            this.GroupBoxStructure.Controls.Add(this.StructureMaxRBox);
            this.GroupBoxStructure.Controls.Add(this.label47);
            this.GroupBoxStructure.Controls.Add(this.label97);
            this.GroupBoxStructure.Controls.Add(this.label96);
            this.GroupBoxStructure.Controls.Add(this.label19);
            this.GroupBoxStructure.Controls.Add(this.StructureUpdateQBox);
            this.GroupBoxStructure.Controls.Add(this.StructureAlphaPrioriABox);
            this.GroupBoxStructure.Controls.Add(this.StructureAlphaPrioriBBox);
            this.GroupBoxStructure.Controls.Add(this.StructureStdAlphaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureMaxAlphaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureAlpha0Box);
            this.GroupBoxStructure.Controls.Add(this.StructureMaxLambdaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureStdLambdaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureLambdaBox);
            this.GroupBoxStructure.Controls.Add(this.label15);
            this.GroupBoxStructure.Controls.Add(this.StructureNRunsBox);
            this.GroupBoxStructure.Controls.Add(this.StructureKminBox);
            this.GroupBoxStructure.Controls.Add(this.label27);
            this.GroupBoxStructure.Controls.Add(this.label32);
            this.GroupBoxStructure.Controls.Add(this.label31);
            this.GroupBoxStructure.Controls.Add(this.label30);
            this.GroupBoxStructure.Controls.Add(this.label29);
            this.GroupBoxStructure.Controls.Add(this.label28);
            this.GroupBoxStructure.Controls.Add(this.label14);
            this.GroupBoxStructure.Controls.Add(this.label12);
            this.GroupBoxStructure.Controls.Add(this.label13);
            this.GroupBoxStructure.Controls.Add(this.label11);
            this.GroupBoxStructure.Controls.Add(this.StructureADMBox);
            this.GroupBoxStructure.Controls.Add(this.StructureFmodelBox);
            this.GroupBoxStructure.Controls.Add(this.StructureLOCPRIORIBox);
            this.GroupBoxStructure.Controls.Add(this.StructureDiffAlphaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureDiffLambdaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureUniformAlphaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureInferAlphaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureInferLambdaBox);
            this.GroupBoxStructure.Controls.Add(this.StructureFSameBox);
            this.GroupBoxStructure.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxStructure.Location = new System.Drawing.Point(757, 678);
            this.GroupBoxStructure.Name = "GroupBoxStructure";
            this.GroupBoxStructure.Size = new System.Drawing.Size(370, 672);
            this.GroupBoxStructure.TabIndex = 6;
            this.GroupBoxStructure.TabStop = false;
            this.GroupBoxStructure.Text = "Structure";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(10, 22);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(214, 20);
            this.label106.TabIndex = 512;
            this.label106.Text = "Model and number of pops (K)";
            // 
            // StructureADMBurninBox
            // 
            this.StructureADMBurninBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureADMBurninBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureADMBurninBox.Location = new System.Drawing.Point(277, 288);
            this.StructureADMBurninBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureADMBurninBox.Name = "StructureADMBurninBox";
            this.StructureADMBurninBox.Size = new System.Drawing.Size(80, 27);
            this.StructureADMBurninBox.TabIndex = 508;
            this.StructureADMBurninBox.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.StructureADMBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureKmaxBox
            // 
            this.StructureKmaxBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureKmaxBox.Location = new System.Drawing.Point(277, 117);
            this.StructureKmaxBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureKmaxBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureKmaxBox.Name = "StructureKmaxBox";
            this.StructureKmaxBox.Size = new System.Drawing.Size(80, 27);
            this.StructureKmaxBox.TabIndex = 508;
            this.StructureKmaxBox.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.StructureKmaxBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureNThinningBox
            // 
            this.StructureNThinningBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureNThinningBox.Location = new System.Drawing.Point(102, 202);
            this.StructureNThinningBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureNThinningBox.Name = "StructureNThinningBox";
            this.StructureNThinningBox.Size = new System.Drawing.Size(80, 27);
            this.StructureNThinningBox.TabIndex = 508;
            this.StructureNThinningBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureNThinningBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureBurninBox
            // 
            this.StructureBurninBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureBurninBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureBurninBox.Location = new System.Drawing.Point(102, 175);
            this.StructureBurninBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.StructureBurninBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureBurninBox.Name = "StructureBurninBox";
            this.StructureBurninBox.Size = new System.Drawing.Size(80, 27);
            this.StructureBurninBox.TabIndex = 508;
            this.StructureBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.StructureBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureNRepsBox
            // 
            this.StructureNRepsBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureNRepsBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureNRepsBox.Location = new System.Drawing.Point(277, 175);
            this.StructureNRepsBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.StructureNRepsBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureNRepsBox.Name = "StructureNRepsBox";
            this.StructureNRepsBox.Size = new System.Drawing.Size(80, 27);
            this.StructureNRepsBox.TabIndex = 508;
            this.StructureNRepsBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.StructureNRepsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(200, 552);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(50, 20);
            this.label26.TabIndex = 507;
            this.label26.Text = "eps(γ)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(20, 552);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 20);
            this.label25.TabIndex = 507;
            this.label25.Text = "eps(η)";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(192, 612);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 20);
            this.label34.TabIndex = 507;
            this.label34.Text = "prior std";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(203, 525);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 20);
            this.label24.TabIndex = 507;
            this.label24.Text = "std(r)";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(30, 638);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(46, 20);
            this.label41.TabIndex = 507;
            this.label41.Text = "std(F)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(8, 612);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(82, 20);
            this.label33.TabIndex = 507;
            this.label33.Text = "prior mean";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(20, 525);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 20);
            this.label23.TabIndex = 507;
            this.label23.Text = "max(r)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(187, 408);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(78, 20);
            this.label49.TabIndex = 507;
            this.label49.Text = "MetroFreq";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(22, 437);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(68, 20);
            this.label100.TabIndex = 507;
            this.label100.Text = "α prior A";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(198, 382);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 20);
            this.label22.TabIndex = 507;
            this.label22.Text = "std(α)";
            // 
            // StructureEpsGammaBox
            // 
            this.StructureEpsGammaBox.DecimalPlaces = 4;
            this.StructureEpsGammaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureEpsGammaBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureEpsGammaBox.Location = new System.Drawing.Point(277, 548);
            this.StructureEpsGammaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureEpsGammaBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.StructureEpsGammaBox.Name = "StructureEpsGammaBox";
            this.StructureEpsGammaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureEpsGammaBox.TabIndex = 508;
            this.StructureEpsGammaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.StructureEpsGammaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureEpsEtaBox
            // 
            this.StructureEpsEtaBox.DecimalPlaces = 4;
            this.StructureEpsEtaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureEpsEtaBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureEpsEtaBox.Location = new System.Drawing.Point(102, 548);
            this.StructureEpsEtaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureEpsEtaBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.StructureEpsEtaBox.Name = "StructureEpsEtaBox";
            this.StructureEpsEtaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureEpsEtaBox.TabIndex = 508;
            this.StructureEpsEtaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.StructureEpsEtaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureFPriorStdBox
            // 
            this.StructureFPriorStdBox.DecimalPlaces = 4;
            this.StructureFPriorStdBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureFPriorStdBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureFPriorStdBox.Location = new System.Drawing.Point(277, 607);
            this.StructureFPriorStdBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureFPriorStdBox.Name = "StructureFPriorStdBox";
            this.StructureFPriorStdBox.Size = new System.Drawing.Size(80, 27);
            this.StructureFPriorStdBox.TabIndex = 508;
            this.StructureFPriorStdBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureFPriorStdBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureEpsRBox
            // 
            this.StructureEpsRBox.DecimalPlaces = 4;
            this.StructureEpsRBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureEpsRBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureEpsRBox.Location = new System.Drawing.Point(277, 522);
            this.StructureEpsRBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureEpsRBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.StructureEpsRBox.Name = "StructureEpsRBox";
            this.StructureEpsRBox.Size = new System.Drawing.Size(80, 27);
            this.StructureEpsRBox.TabIndex = 508;
            this.StructureEpsRBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureEpsRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(187, 437);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(67, 20);
            this.label99.TabIndex = 507;
            this.label99.Text = "α prior B";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(22, 408);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(56, 20);
            this.label48.TabIndex = 507;
            this.label48.Text = "max(α)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(22, 382);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 20);
            this.label21.TabIndex = 507;
            this.label21.Text = "α0";
            // 
            // StructureFStdFBox
            // 
            this.StructureFStdFBox.DecimalPlaces = 4;
            this.StructureFStdFBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureFStdFBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureFStdFBox.Location = new System.Drawing.Point(102, 635);
            this.StructureFStdFBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureFStdFBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.StructureFStdFBox.Name = "StructureFStdFBox";
            this.StructureFStdFBox.Size = new System.Drawing.Size(80, 27);
            this.StructureFStdFBox.TabIndex = 508;
            this.StructureFStdFBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureFStdFBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureFPriorMeanBox
            // 
            this.StructureFPriorMeanBox.DecimalPlaces = 4;
            this.StructureFPriorMeanBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureFPriorMeanBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureFPriorMeanBox.Location = new System.Drawing.Point(102, 607);
            this.StructureFPriorMeanBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureFPriorMeanBox.Name = "StructureFPriorMeanBox";
            this.StructureFPriorMeanBox.Size = new System.Drawing.Size(80, 27);
            this.StructureFPriorMeanBox.TabIndex = 508;
            this.StructureFPriorMeanBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.StructureFPriorMeanBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureMaxRBox
            // 
            this.StructureMaxRBox.DecimalPlaces = 4;
            this.StructureMaxRBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureMaxRBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureMaxRBox.Location = new System.Drawing.Point(102, 522);
            this.StructureMaxRBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureMaxRBox.Name = "StructureMaxRBox";
            this.StructureMaxRBox.Size = new System.Drawing.Size(80, 27);
            this.StructureMaxRBox.TabIndex = 508;
            this.StructureMaxRBox.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.StructureMaxRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(188, 292);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(83, 20);
            this.label47.TabIndex = 507;
            this.label47.Text = "AdmBurnin";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(22, 292);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(54, 20);
            this.label97.TabIndex = 507;
            this.label97.Text = "max(λ)";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(197, 265);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(46, 20);
            this.label96.TabIndex = 507;
            this.label96.Text = "std(λ)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(22, 265);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 20);
            this.label19.TabIndex = 507;
            this.label19.Text = "λ";
            // 
            // StructureUpdateQBox
            // 
            this.StructureUpdateQBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureUpdateQBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureUpdateQBox.Location = new System.Drawing.Point(277, 405);
            this.StructureUpdateQBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureUpdateQBox.Name = "StructureUpdateQBox";
            this.StructureUpdateQBox.Size = new System.Drawing.Size(80, 27);
            this.StructureUpdateQBox.TabIndex = 508;
            this.StructureUpdateQBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.StructureUpdateQBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureAlphaPrioriABox
            // 
            this.StructureAlphaPrioriABox.DecimalPlaces = 4;
            this.StructureAlphaPrioriABox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureAlphaPrioriABox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureAlphaPrioriABox.Location = new System.Drawing.Point(102, 432);
            this.StructureAlphaPrioriABox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureAlphaPrioriABox.Name = "StructureAlphaPrioriABox";
            this.StructureAlphaPrioriABox.Size = new System.Drawing.Size(80, 27);
            this.StructureAlphaPrioriABox.TabIndex = 508;
            this.StructureAlphaPrioriABox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureAlphaPrioriABox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureAlphaPrioriBBox
            // 
            this.StructureAlphaPrioriBBox.DecimalPlaces = 4;
            this.StructureAlphaPrioriBBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureAlphaPrioriBBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureAlphaPrioriBBox.Location = new System.Drawing.Point(277, 432);
            this.StructureAlphaPrioriBBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureAlphaPrioriBBox.Name = "StructureAlphaPrioriBBox";
            this.StructureAlphaPrioriBBox.Size = new System.Drawing.Size(80, 27);
            this.StructureAlphaPrioriBBox.TabIndex = 508;
            this.StructureAlphaPrioriBBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.StructureAlphaPrioriBBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureStdAlphaBox
            // 
            this.StructureStdAlphaBox.DecimalPlaces = 4;
            this.StructureStdAlphaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureStdAlphaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureStdAlphaBox.Location = new System.Drawing.Point(277, 377);
            this.StructureStdAlphaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureStdAlphaBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.StructureStdAlphaBox.Name = "StructureStdAlphaBox";
            this.StructureStdAlphaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureStdAlphaBox.TabIndex = 508;
            this.StructureStdAlphaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.StructureStdAlphaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureMaxAlphaBox
            // 
            this.StructureMaxAlphaBox.DecimalPlaces = 4;
            this.StructureMaxAlphaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureMaxAlphaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureMaxAlphaBox.Location = new System.Drawing.Point(102, 405);
            this.StructureMaxAlphaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureMaxAlphaBox.Name = "StructureMaxAlphaBox";
            this.StructureMaxAlphaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureMaxAlphaBox.TabIndex = 508;
            this.StructureMaxAlphaBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.StructureMaxAlphaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureAlpha0Box
            // 
            this.StructureAlpha0Box.DecimalPlaces = 4;
            this.StructureAlpha0Box.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureAlpha0Box.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureAlpha0Box.Location = new System.Drawing.Point(102, 377);
            this.StructureAlpha0Box.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureAlpha0Box.Name = "StructureAlpha0Box";
            this.StructureAlpha0Box.Size = new System.Drawing.Size(80, 27);
            this.StructureAlpha0Box.TabIndex = 508;
            this.StructureAlpha0Box.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureAlpha0Box.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureMaxLambdaBox
            // 
            this.StructureMaxLambdaBox.DecimalPlaces = 4;
            this.StructureMaxLambdaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureMaxLambdaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureMaxLambdaBox.Location = new System.Drawing.Point(102, 288);
            this.StructureMaxLambdaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureMaxLambdaBox.Name = "StructureMaxLambdaBox";
            this.StructureMaxLambdaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureMaxLambdaBox.TabIndex = 508;
            this.StructureMaxLambdaBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.StructureMaxLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureStdLambdaBox
            // 
            this.StructureStdLambdaBox.DecimalPlaces = 4;
            this.StructureStdLambdaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureStdLambdaBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.StructureStdLambdaBox.Location = new System.Drawing.Point(277, 262);
            this.StructureStdLambdaBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureStdLambdaBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.StructureStdLambdaBox.Name = "StructureStdLambdaBox";
            this.StructureStdLambdaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureStdLambdaBox.TabIndex = 508;
            this.StructureStdLambdaBox.Value = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            this.StructureStdLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureLambdaBox
            // 
            this.StructureLambdaBox.DecimalPlaces = 4;
            this.StructureLambdaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureLambdaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.StructureLambdaBox.Location = new System.Drawing.Point(102, 262);
            this.StructureLambdaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.StructureLambdaBox.Name = "StructureLambdaBox";
            this.StructureLambdaBox.Size = new System.Drawing.Size(80, 27);
            this.StructureLambdaBox.TabIndex = 508;
            this.StructureLambdaBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(197, 207);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 20);
            this.label15.TabIndex = 507;
            this.label15.Text = "#Runs";
            // 
            // StructureNRunsBox
            // 
            this.StructureNRunsBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureNRunsBox.Location = new System.Drawing.Point(277, 202);
            this.StructureNRunsBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.StructureNRunsBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureNRunsBox.Name = "StructureNRunsBox";
            this.StructureNRunsBox.Size = new System.Drawing.Size(80, 27);
            this.StructureNRunsBox.TabIndex = 508;
            this.StructureNRunsBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.StructureNRunsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureKminBox
            // 
            this.StructureKminBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureKminBox.Location = new System.Drawing.Point(137, 117);
            this.StructureKminBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.StructureKminBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StructureKminBox.Name = "StructureKminBox";
            this.StructureKminBox.Size = new System.Drawing.Size(80, 27);
            this.StructureKminBox.TabIndex = 508;
            this.StructureKminBox.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.StructureKminBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(197, 178);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(50, 20);
            this.label27.TabIndex = 507;
            this.label27.Text = "#Reps";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(10, 585);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(142, 20);
            this.label32.TabIndex = 507;
            this.label32.Text = "F model parameters";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(10, 498);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(206, 20);
            this.label31.TabIndex = 507;
            this.label31.Text = "LOCPRIORI model parameters";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(10, 355);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(217, 20);
            this.label30.TabIndex = 507;
            this.label30.Text = "ADMIXTURE model parameters";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(10, 238);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(249, 20);
            this.label29.TabIndex = 507;
            this.label29.Text = "Allele frequency && admixture burnin";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(10, 152);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(132, 20);
            this.label28.TabIndex = 507;
            this.label28.Text = "MCMC parameters";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(22, 178);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 507;
            this.label14.Text = "#Burnin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(228, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 20);
            this.label12.TabIndex = 507;
            this.label12.Text = "to";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(22, 207);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 20);
            this.label13.TabIndex = 507;
            this.label13.Text = "#Thinning";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 20);
            this.label11.TabIndex = 507;
            this.label11.Text = "K runs from";
            // 
            // StructureADMBox
            // 
            this.StructureADMBox.AutoSize = true;
            this.StructureADMBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureADMBox.Location = new System.Drawing.Point(25, 42);
            this.StructureADMBox.Name = "StructureADMBox";
            this.StructureADMBox.Size = new System.Drawing.Size(243, 24);
            this.StructureADMBox.TabIndex = 0;
            this.StructureADMBox.Text = "Admixture model (ADMIXTURE)";
            this.StructureADMBox.UseVisualStyleBackColor = true;
            this.StructureADMBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // StructureFmodelBox
            // 
            this.StructureFmodelBox.AutoSize = true;
            this.StructureFmodelBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureFmodelBox.Location = new System.Drawing.Point(25, 92);
            this.StructureFmodelBox.Name = "StructureFmodelBox";
            this.StructureFmodelBox.Size = new System.Drawing.Size(278, 24);
            this.StructureFmodelBox.TabIndex = 0;
            this.StructureFmodelBox.Text = "Allele frequency correlated (F model)";
            this.StructureFmodelBox.UseVisualStyleBackColor = true;
            this.StructureFmodelBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // StructureLOCPRIORIBox
            // 
            this.StructureLOCPRIORIBox.AutoSize = true;
            this.StructureLOCPRIORIBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureLOCPRIORIBox.Location = new System.Drawing.Point(25, 67);
            this.StructureLOCPRIORIBox.Name = "StructureLOCPRIORIBox";
            this.StructureLOCPRIORIBox.Size = new System.Drawing.Size(250, 24);
            this.StructureLOCPRIORIBox.TabIndex = 0;
            this.StructureLOCPRIORIBox.Text = "Using pop as a priori (LOCPRIOR)";
            this.StructureLOCPRIORIBox.UseVisualStyleBackColor = true;
            this.StructureLOCPRIORIBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // StructureDiffAlphaBox
            // 
            this.StructureDiffAlphaBox.AutoSize = true;
            this.StructureDiffAlphaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureDiffAlphaBox.Location = new System.Drawing.Point(145, 465);
            this.StructureDiffAlphaBox.Name = "StructureDiffAlphaBox";
            this.StructureDiffAlphaBox.Size = new System.Drawing.Size(69, 24);
            this.StructureDiffAlphaBox.TabIndex = 511;
            this.StructureDiffAlphaBox.Text = "Diff α";
            this.StructureDiffAlphaBox.UseVisualStyleBackColor = true;
            this.StructureDiffAlphaBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureDiffLambdaBox
            // 
            this.StructureDiffLambdaBox.AutoSize = true;
            this.StructureDiffLambdaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureDiffLambdaBox.Location = new System.Drawing.Point(147, 322);
            this.StructureDiffLambdaBox.Name = "StructureDiffLambdaBox";
            this.StructureDiffLambdaBox.Size = new System.Drawing.Size(67, 24);
            this.StructureDiffLambdaBox.TabIndex = 511;
            this.StructureDiffLambdaBox.Text = "Diff λ";
            this.StructureDiffLambdaBox.UseVisualStyleBackColor = true;
            this.StructureDiffLambdaBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureUniformAlphaBox
            // 
            this.StructureUniformAlphaBox.AutoSize = true;
            this.StructureUniformAlphaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureUniformAlphaBox.Location = new System.Drawing.Point(252, 465);
            this.StructureUniformAlphaBox.Name = "StructureUniformAlphaBox";
            this.StructureUniformAlphaBox.Size = new System.Drawing.Size(98, 24);
            this.StructureUniformAlphaBox.TabIndex = 511;
            this.StructureUniformAlphaBox.Text = "Uniform α";
            this.StructureUniformAlphaBox.UseVisualStyleBackColor = true;
            this.StructureUniformAlphaBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureInferAlphaBox
            // 
            this.StructureInferAlphaBox.AutoSize = true;
            this.StructureInferAlphaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureInferAlphaBox.Location = new System.Drawing.Point(27, 465);
            this.StructureInferAlphaBox.Name = "StructureInferAlphaBox";
            this.StructureInferAlphaBox.Size = new System.Drawing.Size(74, 24);
            this.StructureInferAlphaBox.TabIndex = 511;
            this.StructureInferAlphaBox.Text = "Infer α";
            this.StructureInferAlphaBox.UseVisualStyleBackColor = true;
            this.StructureInferAlphaBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureInferLambdaBox
            // 
            this.StructureInferLambdaBox.AutoSize = true;
            this.StructureInferLambdaBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureInferLambdaBox.Location = new System.Drawing.Point(27, 322);
            this.StructureInferLambdaBox.Name = "StructureInferLambdaBox";
            this.StructureInferLambdaBox.Size = new System.Drawing.Size(72, 24);
            this.StructureInferLambdaBox.TabIndex = 511;
            this.StructureInferLambdaBox.Text = "Infer λ";
            this.StructureInferLambdaBox.UseVisualStyleBackColor = true;
            this.StructureInferLambdaBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructureFSameBox
            // 
            this.StructureFSameBox.AutoSize = true;
            this.StructureFSameBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StructureFSameBox.Location = new System.Drawing.Point(197, 638);
            this.StructureFSameBox.Name = "StructureFSameBox";
            this.StructureFSameBox.Size = new System.Drawing.Size(175, 24);
            this.StructureFSameBox.TabIndex = 0;
            this.StructureFSameBox.Text = "Same F for all clusters";
            this.StructureFSameBox.UseVisualStyleBackColor = true;
            this.StructureFSameBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxLinkage
            // 
            this.GroupBoxLinkage.Controls.Add(this.LinkageTestTotBox);
            this.GroupBoxLinkage.Controls.Add(this.LinkageTestRegBox);
            this.GroupBoxLinkage.Controls.Add(this.LinkageTestPopBox);
            this.GroupBoxLinkage.Controls.Add(this.label104);
            this.GroupBoxLinkage.Controls.Add(this.LinkageBurrowsTestBox);
            this.GroupBoxLinkage.Controls.Add(this.LinkageFisherTestBox);
            this.GroupBoxLinkage.Controls.Add(this.label101);
            this.GroupBoxLinkage.Controls.Add(this.LinkageIterationsBox);
            this.GroupBoxLinkage.Controls.Add(this.LinkageBurninBox);
            this.GroupBoxLinkage.Controls.Add(this.LinkageBatchesBox);
            this.GroupBoxLinkage.Controls.Add(this.label84);
            this.GroupBoxLinkage.Controls.Add(this.label85);
            this.GroupBoxLinkage.Controls.Add(this.label86);
            this.GroupBoxLinkage.Controls.Add(this.LinkageRaymondTestBox);
            this.GroupBoxLinkage.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxLinkage.Location = new System.Drawing.Point(378, 2);
            this.GroupBoxLinkage.Name = "GroupBoxLinkage";
            this.GroupBoxLinkage.Size = new System.Drawing.Size(370, 180);
            this.GroupBoxLinkage.TabIndex = 6;
            this.GroupBoxLinkage.TabStop = false;
            this.GroupBoxLinkage.Text = "Linkage disequilibrium test";
            // 
            // LinkageTestTotBox
            // 
            this.LinkageTestTotBox.AutoSize = true;
            this.LinkageTestTotBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageTestTotBox.Location = new System.Drawing.Point(265, 25);
            this.LinkageTestTotBox.Name = "LinkageTestTotBox";
            this.LinkageTestTotBox.Size = new System.Drawing.Size(98, 24);
            this.LinkageTestTotBox.TabIndex = 0;
            this.LinkageTestTotBox.Text = "Total pop.";
            this.LinkageTestTotBox.UseVisualStyleBackColor = true;
            this.LinkageTestTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageTestRegBox
            // 
            this.LinkageTestRegBox.AutoSize = true;
            this.LinkageTestRegBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageTestRegBox.Location = new System.Drawing.Point(178, 25);
            this.LinkageTestRegBox.Name = "LinkageTestRegBox";
            this.LinkageTestRegBox.Size = new System.Drawing.Size(78, 24);
            this.LinkageTestRegBox.TabIndex = 0;
            this.LinkageTestRegBox.Text = "Region";
            this.LinkageTestRegBox.UseVisualStyleBackColor = true;
            this.LinkageTestRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageTestPopBox
            // 
            this.LinkageTestPopBox.AutoSize = true;
            this.LinkageTestPopBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageTestPopBox.Location = new System.Drawing.Point(65, 25);
            this.LinkageTestPopBox.Name = "LinkageTestPopBox";
            this.LinkageTestPopBox.Size = new System.Drawing.Size(102, 24);
            this.LinkageTestPopBox.TabIndex = 0;
            this.LinkageTestPopBox.Text = "Population";
            this.LinkageTestPopBox.UseVisualStyleBackColor = true;
            this.LinkageTestPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label104.Location = new System.Drawing.Point(10, 50);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(114, 20);
            this.label104.TabIndex = 523;
            this.label104.Text = "Test parameters";
            // 
            // LinkageBurrowsTestBox
            // 
            this.LinkageBurrowsTestBox.AutoSize = true;
            this.LinkageBurrowsTestBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageBurrowsTestBox.Location = new System.Drawing.Point(178, 72);
            this.LinkageBurrowsTestBox.Name = "LinkageBurrowsTestBox";
            this.LinkageBurrowsTestBox.Size = new System.Drawing.Size(135, 24);
            this.LinkageBurrowsTestBox.TabIndex = 521;
            this.LinkageBurrowsTestBox.Text = "Burrows’s ∆ test";
            this.LinkageBurrowsTestBox.UseVisualStyleBackColor = true;
            this.LinkageBurrowsTestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageFisherTestBox
            // 
            this.LinkageFisherTestBox.AutoSize = true;
            this.LinkageFisherTestBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageFisherTestBox.Location = new System.Drawing.Point(25, 72);
            this.LinkageFisherTestBox.Name = "LinkageFisherTestBox";
            this.LinkageFisherTestBox.Size = new System.Drawing.Size(120, 24);
            this.LinkageFisherTestBox.TabIndex = 522;
            this.LinkageFisherTestBox.Text = "Fisher\'s G test";
            this.LinkageFisherTestBox.UseVisualStyleBackColor = true;
            this.LinkageFisherTestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label101.Location = new System.Drawing.Point(10, 25);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(51, 20);
            this.label101.TabIndex = 519;
            this.label101.Text = "Range";
            // 
            // LinkageIterationsBox
            // 
            this.LinkageIterationsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageIterationsBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageIterationsBox.Location = new System.Drawing.Point(267, 142);
            this.LinkageIterationsBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.LinkageIterationsBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageIterationsBox.Name = "LinkageIterationsBox";
            this.LinkageIterationsBox.Size = new System.Drawing.Size(80, 27);
            this.LinkageIterationsBox.TabIndex = 516;
            this.LinkageIterationsBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.LinkageIterationsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageBurninBox
            // 
            this.LinkageBurninBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageBurninBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageBurninBox.Location = new System.Drawing.Point(40, 142);
            this.LinkageBurninBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.LinkageBurninBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageBurninBox.Name = "LinkageBurninBox";
            this.LinkageBurninBox.Size = new System.Drawing.Size(80, 27);
            this.LinkageBurninBox.TabIndex = 517;
            this.LinkageBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.LinkageBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageBatchesBox
            // 
            this.LinkageBatchesBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageBatchesBox.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LinkageBatchesBox.Location = new System.Drawing.Point(157, 142);
            this.LinkageBatchesBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.LinkageBatchesBox.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.LinkageBatchesBox.Name = "LinkageBatchesBox";
            this.LinkageBatchesBox.Size = new System.Drawing.Size(80, 27);
            this.LinkageBatchesBox.TabIndex = 518;
            this.LinkageBatchesBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.LinkageBatchesBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label84.Location = new System.Drawing.Point(262, 122);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(80, 20);
            this.label84.TabIndex = 514;
            this.label84.Text = "#Iterations";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label85.Location = new System.Drawing.Point(38, 122);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(60, 20);
            this.label85.TabIndex = 513;
            this.label85.Text = "#Burnin";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label86.Location = new System.Drawing.Point(152, 122);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(69, 20);
            this.label86.TabIndex = 515;
            this.label86.Text = "#Batches";
            // 
            // LinkageRaymondTestBox
            // 
            this.LinkageRaymondTestBox.AutoSize = true;
            this.LinkageRaymondTestBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LinkageRaymondTestBox.Location = new System.Drawing.Point(25, 97);
            this.LinkageRaymondTestBox.Name = "LinkageRaymondTestBox";
            this.LinkageRaymondTestBox.Size = new System.Drawing.Size(255, 24);
            this.LinkageRaymondTestBox.TabIndex = 0;
            this.LinkageRaymondTestBox.Text = "Raymond && Rousset 1995 MC test";
            this.LinkageRaymondTestBox.UseVisualStyleBackColor = true;
            this.LinkageRaymondTestBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // GroupBoxOrdination
            // 
            this.GroupBoxOrdination.Controls.Add(this.OrdinationPCABox);
            this.GroupBoxOrdination.Controls.Add(this.label91);
            this.GroupBoxOrdination.Controls.Add(this.OrdinationDimBox);
            this.GroupBoxOrdination.Controls.Add(this.label90);
            this.GroupBoxOrdination.Controls.Add(this.OrdinationPCoABox);
            this.GroupBoxOrdination.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxOrdination.Location = new System.Drawing.Point(378, 188);
            this.GroupBoxOrdination.Name = "GroupBoxOrdination";
            this.GroupBoxOrdination.Size = new System.Drawing.Size(370, 87);
            this.GroupBoxOrdination.TabIndex = 10;
            this.GroupBoxOrdination.TabStop = false;
            this.GroupBoxOrdination.Text = "Ordination";
            // 
            // OrdinationPCABox
            // 
            this.OrdinationPCABox.AutoSize = true;
            this.OrdinationPCABox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.OrdinationPCABox.Location = new System.Drawing.Point(288, 25);
            this.OrdinationPCABox.Name = "OrdinationPCABox";
            this.OrdinationPCABox.Size = new System.Drawing.Size(58, 24);
            this.OrdinationPCABox.TabIndex = 516;
            this.OrdinationPCABox.Text = "PCA";
            this.OrdinationPCABox.UseVisualStyleBackColor = true;
            this.OrdinationPCABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(128, 52);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(0, 20);
            this.label91.TabIndex = 515;
            // 
            // OrdinationDimBox
            // 
            this.OrdinationDimBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.OrdinationDimBox.Location = new System.Drawing.Point(118, 50);
            this.OrdinationDimBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.OrdinationDimBox.Name = "OrdinationDimBox";
            this.OrdinationDimBox.Size = new System.Drawing.Size(82, 27);
            this.OrdinationDimBox.TabIndex = 514;
            this.OrdinationDimBox.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.OrdinationDimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label90.Location = new System.Drawing.Point(10, 53);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(98, 20);
            this.label90.TabIndex = 513;
            this.label90.Text = "#Coordinates";
            // 
            // OrdinationPCoABox
            // 
            this.OrdinationPCoABox.AutoSize = true;
            this.OrdinationPCoABox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.OrdinationPCoABox.Location = new System.Drawing.Point(17, 25);
            this.OrdinationPCoABox.Name = "OrdinationPCoABox";
            this.OrdinationPCoABox.Size = new System.Drawing.Size(232, 24);
            this.OrdinationPCoABox.TabIndex = 516;
            this.OrdinationPCoABox.Text = "PCoA (req. distance estimates)";
            this.OrdinationPCoABox.UseVisualStyleBackColor = true;
            this.OrdinationPCoABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxDiff
            // 
            this.GroupBoxDiff.Controls.Add(this.label87);
            this.GroupBoxDiff.Controls.Add(this.DiffRegBox);
            this.GroupBoxDiff.Controls.Add(this.DiffTotBox);
            this.GroupBoxDiff.Controls.Add(this.DiffPopBox);
            this.GroupBoxDiff.Controls.Add(this.label66);
            this.GroupBoxDiff.Controls.Add(this.label65);
            this.GroupBoxDiff.Controls.Add(this.DiffIterationsBox);
            this.GroupBoxDiff.Controls.Add(this.DiffBurninBox);
            this.GroupBoxDiff.Controls.Add(this.DiffBatchesBox);
            this.GroupBoxDiff.Controls.Add(this.label83);
            this.GroupBoxDiff.Controls.Add(this.label68);
            this.GroupBoxDiff.Controls.Add(this.label67);
            this.GroupBoxDiff.Controls.Add(this.DiffHuang2019Box);
            this.GroupBoxDiff.Controls.Add(this.DiffJost2008Box);
            this.GroupBoxDiff.Controls.Add(this.DiffHedrick2005Box);
            this.GroupBoxDiff.Controls.Add(this.DiffHudson1992Box);
            this.GroupBoxDiff.Controls.Add(this.DiffTestPermBox);
            this.GroupBoxDiff.Controls.Add(this.DiffTestAlleleBox);
            this.GroupBoxDiff.Controls.Add(this.DiffNei1973Box);
            this.GroupBoxDiff.Controls.Add(this.DiffTestPhenoBox);
            this.GroupBoxDiff.Controls.Add(this.DiffHuang2018SMMBox);
            this.GroupBoxDiff.Controls.Add(this.DiffSlatkin1995Box);
            this.GroupBoxDiff.Controls.Add(this.DiffHuang2018IAMBox);
            this.GroupBoxDiff.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxDiff.Location = new System.Drawing.Point(2, 67);
            this.GroupBoxDiff.Name = "GroupBoxDiff";
            this.GroupBoxDiff.Size = new System.Drawing.Size(370, 327);
            this.GroupBoxDiff.TabIndex = 6;
            this.GroupBoxDiff.TabStop = false;
            this.GroupBoxDiff.Text = "Genetic differentiation";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label87.Location = new System.Drawing.Point(10, 172);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(114, 20);
            this.label87.TabIndex = 517;
            this.label87.Text = "Test parameters";
            // 
            // DiffRegBox
            // 
            this.DiffRegBox.AutoSize = true;
            this.DiffRegBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffRegBox.Location = new System.Drawing.Point(178, 25);
            this.DiffRegBox.Name = "DiffRegBox";
            this.DiffRegBox.Size = new System.Drawing.Size(78, 24);
            this.DiffRegBox.TabIndex = 516;
            this.DiffRegBox.Text = "Region";
            this.DiffRegBox.UseVisualStyleBackColor = true;
            this.DiffRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTotBox
            // 
            this.DiffTotBox.AutoSize = true;
            this.DiffTotBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffTotBox.Location = new System.Drawing.Point(265, 25);
            this.DiffTotBox.Name = "DiffTotBox";
            this.DiffTotBox.Size = new System.Drawing.Size(98, 24);
            this.DiffTotBox.TabIndex = 515;
            this.DiffTotBox.Text = "Total pop.";
            this.DiffTotBox.UseVisualStyleBackColor = true;
            this.DiffTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffPopBox
            // 
            this.DiffPopBox.AutoSize = true;
            this.DiffPopBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffPopBox.Location = new System.Drawing.Point(65, 25);
            this.DiffPopBox.Name = "DiffPopBox";
            this.DiffPopBox.Size = new System.Drawing.Size(102, 24);
            this.DiffPopBox.TabIndex = 515;
            this.DiffPopBox.Text = "Population";
            this.DiffPopBox.UseVisualStyleBackColor = true;
            this.DiffPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label66.Location = new System.Drawing.Point(10, 50);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(78, 20);
            this.label66.TabIndex = 513;
            this.label66.Text = "Estimators";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label65.Location = new System.Drawing.Point(10, 25);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(51, 20);
            this.label65.TabIndex = 513;
            this.label65.Text = "Range";
            // 
            // DiffIterationsBox
            // 
            this.DiffIterationsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffIterationsBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffIterationsBox.Location = new System.Drawing.Point(265, 287);
            this.DiffIterationsBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.DiffIterationsBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffIterationsBox.Name = "DiffIterationsBox";
            this.DiffIterationsBox.Size = new System.Drawing.Size(80, 27);
            this.DiffIterationsBox.TabIndex = 512;
            this.DiffIterationsBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.DiffIterationsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffBurninBox
            // 
            this.DiffBurninBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffBurninBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBurninBox.Location = new System.Drawing.Point(40, 287);
            this.DiffBurninBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.DiffBurninBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBurninBox.Name = "DiffBurninBox";
            this.DiffBurninBox.Size = new System.Drawing.Size(80, 27);
            this.DiffBurninBox.TabIndex = 512;
            this.DiffBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.DiffBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffBatchesBox
            // 
            this.DiffBatchesBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffBatchesBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBatchesBox.Location = new System.Drawing.Point(153, 287);
            this.DiffBatchesBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.DiffBatchesBox.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.DiffBatchesBox.Name = "DiffBatchesBox";
            this.DiffBatchesBox.Size = new System.Drawing.Size(80, 27);
            this.DiffBatchesBox.TabIndex = 512;
            this.DiffBatchesBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBatchesBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label83.Location = new System.Drawing.Point(262, 267);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(80, 20);
            this.label83.TabIndex = 511;
            this.label83.Text = "#Iterations";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label68.Location = new System.Drawing.Point(38, 267);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(60, 20);
            this.label68.TabIndex = 511;
            this.label68.Text = "#Burnin";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label67.Location = new System.Drawing.Point(150, 267);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(69, 20);
            this.label67.TabIndex = 511;
            this.label67.Text = "#Batches";
            // 
            // DiffHuang2019Box
            // 
            this.DiffHuang2019Box.AutoSize = true;
            this.DiffHuang2019Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffHuang2019Box.Location = new System.Drawing.Point(188, 147);
            this.DiffHuang2019Box.Name = "DiffHuang2019Box";
            this.DiffHuang2019Box.Size = new System.Drawing.Size(121, 24);
            this.DiffHuang2019Box.TabIndex = 0;
            this.DiffHuang2019Box.Text = "Huang unpub";
            this.DiffHuang2019Box.UseVisualStyleBackColor = true;
            this.DiffHuang2019Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffJost2008Box
            // 
            this.DiffJost2008Box.AutoSize = true;
            this.DiffJost2008Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffJost2008Box.Location = new System.Drawing.Point(25, 147);
            this.DiffJost2008Box.Name = "DiffJost2008Box";
            this.DiffJost2008Box.Size = new System.Drawing.Size(117, 24);
            this.DiffJost2008Box.TabIndex = 0;
            this.DiffJost2008Box.Text = "Jost 2008 (D)";
            this.DiffJost2008Box.UseVisualStyleBackColor = true;
            this.DiffJost2008Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHedrick2005Box
            // 
            this.DiffHedrick2005Box.AutoSize = true;
            this.DiffHedrick2005Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffHedrick2005Box.Location = new System.Drawing.Point(188, 122);
            this.DiffHedrick2005Box.Name = "DiffHedrick2005Box";
            this.DiffHedrick2005Box.Size = new System.Drawing.Size(156, 24);
            this.DiffHedrick2005Box.TabIndex = 0;
            this.DiffHedrick2005Box.Text = "Hedrick 2005 (G\'st)";
            this.DiffHedrick2005Box.UseVisualStyleBackColor = true;
            this.DiffHedrick2005Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHudson1992Box
            // 
            this.DiffHudson1992Box.AutoSize = true;
            this.DiffHudson1992Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffHudson1992Box.Location = new System.Drawing.Point(25, 122);
            this.DiffHudson1992Box.Name = "DiffHudson1992Box";
            this.DiffHudson1992Box.Size = new System.Drawing.Size(154, 24);
            this.DiffHudson1992Box.TabIndex = 0;
            this.DiffHudson1992Box.Text = "Hudson et al. 1992";
            this.DiffHudson1992Box.UseVisualStyleBackColor = true;
            this.DiffHudson1992Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTestPermBox
            // 
            this.DiffTestPermBox.AutoSize = true;
            this.DiffTestPermBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffTestPermBox.Location = new System.Drawing.Point(25, 242);
            this.DiffTestPermBox.Name = "DiffTestPermBox";
            this.DiffTestPermBox.Size = new System.Drawing.Size(255, 24);
            this.DiffTestPermBox.TabIndex = 0;
            this.DiffTestPermBox.Text = "Raymond && Rousset 1995 MC test";
            this.DiffTestPermBox.UseVisualStyleBackColor = true;
            this.DiffTestPermBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // DiffTestAlleleBox
            // 
            this.DiffTestAlleleBox.AutoSize = true;
            this.DiffTestAlleleBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffTestAlleleBox.Location = new System.Drawing.Point(25, 217);
            this.DiffTestAlleleBox.Name = "DiffTestAlleleBox";
            this.DiffTestAlleleBox.Size = new System.Drawing.Size(170, 24);
            this.DiffTestAlleleBox.TabIndex = 0;
            this.DiffTestAlleleBox.Text = "Fisher\'s G test (allele)";
            this.DiffTestAlleleBox.UseVisualStyleBackColor = true;
            this.DiffTestAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffNei1973Box
            // 
            this.DiffNei1973Box.AutoSize = true;
            this.DiffNei1973Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffNei1973Box.Location = new System.Drawing.Point(188, 97);
            this.DiffNei1973Box.Name = "DiffNei1973Box";
            this.DiffNei1973Box.Size = new System.Drawing.Size(125, 24);
            this.DiffNei1973Box.TabIndex = 0;
            this.DiffNei1973Box.Text = "Nei 1973 (Gst)";
            this.DiffNei1973Box.UseVisualStyleBackColor = true;
            this.DiffNei1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTestPhenoBox
            // 
            this.DiffTestPhenoBox.AutoSize = true;
            this.DiffTestPhenoBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffTestPhenoBox.Location = new System.Drawing.Point(25, 192);
            this.DiffTestPhenoBox.Name = "DiffTestPhenoBox";
            this.DiffTestPhenoBox.Size = new System.Drawing.Size(216, 24);
            this.DiffTestPhenoBox.TabIndex = 0;
            this.DiffTestPhenoBox.Text = "Fisher\'s G test (geno/pheno)";
            this.DiffTestPhenoBox.UseVisualStyleBackColor = true;
            this.DiffTestPhenoBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHuang2018SMMBox
            // 
            this.DiffHuang2018SMMBox.AutoSize = true;
            this.DiffHuang2018SMMBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffHuang2018SMMBox.Location = new System.Drawing.Point(188, 72);
            this.DiffHuang2018SMMBox.Name = "DiffHuang2018SMMBox";
            this.DiffHuang2018SMMBox.Size = new System.Drawing.Size(159, 24);
            this.DiffHuang2018SMMBox.TabIndex = 0;
            this.DiffHuang2018SMMBox.Text = "Huang 2021 (SMM)";
            this.DiffHuang2018SMMBox.UseVisualStyleBackColor = true;
            this.DiffHuang2018SMMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffSlatkin1995Box
            // 
            this.DiffSlatkin1995Box.AutoSize = true;
            this.DiffSlatkin1995Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffSlatkin1995Box.Location = new System.Drawing.Point(25, 97);
            this.DiffSlatkin1995Box.Name = "DiffSlatkin1995Box";
            this.DiffSlatkin1995Box.Size = new System.Drawing.Size(145, 24);
            this.DiffSlatkin1995Box.TabIndex = 0;
            this.DiffSlatkin1995Box.Text = "Slatkin 1995 (Rst)";
            this.DiffSlatkin1995Box.UseVisualStyleBackColor = true;
            this.DiffSlatkin1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHuang2018IAMBox
            // 
            this.DiffHuang2018IAMBox.AutoSize = true;
            this.DiffHuang2018IAMBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DiffHuang2018IAMBox.Location = new System.Drawing.Point(25, 72);
            this.DiffHuang2018IAMBox.Name = "DiffHuang2018IAMBox";
            this.DiffHuang2018IAMBox.Size = new System.Drawing.Size(152, 24);
            this.DiffHuang2018IAMBox.TabIndex = 0;
            this.DiffHuang2018IAMBox.Text = "Huang 2021 (IAM)";
            this.DiffHuang2018IAMBox.UseVisualStyleBackColor = true;
            this.DiffHuang2018IAMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxAssignment
            // 
            this.GroupBoxAssignment.Controls.Add(this.AssignmentErrorBox);
            this.GroupBoxAssignment.Controls.Add(this.AssignmentPloidyBox);
            this.GroupBoxAssignment.Controls.Add(this.label8);
            this.GroupBoxAssignment.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxAssignment.Location = new System.Drawing.Point(757, 378);
            this.GroupBoxAssignment.Name = "GroupBoxAssignment";
            this.GroupBoxAssignment.Size = new System.Drawing.Size(370, 58);
            this.GroupBoxAssignment.TabIndex = 6;
            this.GroupBoxAssignment.TabStop = false;
            this.GroupBoxAssignment.Text = "Population assignment";
            // 
            // AssignmentErrorBox
            // 
            this.AssignmentErrorBox.DecimalPlaces = 4;
            this.AssignmentErrorBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AssignmentErrorBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.AssignmentErrorBox.Location = new System.Drawing.Point(288, 22);
            this.AssignmentErrorBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.AssignmentErrorBox.Name = "AssignmentErrorBox";
            this.AssignmentErrorBox.Size = new System.Drawing.Size(68, 27);
            this.AssignmentErrorBox.TabIndex = 202;
            this.AssignmentErrorBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.AssignmentErrorBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AssignmentPloidyBox
            // 
            this.AssignmentPloidyBox.AutoSize = true;
            this.AssignmentPloidyBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AssignmentPloidyBox.Location = new System.Drawing.Point(15, 23);
            this.AssignmentPloidyBox.Name = "AssignmentPloidyBox";
            this.AssignmentPloidyBox.Size = new System.Drawing.Size(151, 24);
            this.AssignmentPloidyBox.TabIndex = 0;
            this.AssignmentPloidyBox.Text = "Ploidy consistency";
            this.AssignmentPloidyBox.UseVisualStyleBackColor = true;
            this.AssignmentPloidyBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label8.Location = new System.Drawing.Point(192, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Mistype rate";
            // 
            // GroupBoxSpatial
            // 
            this.GroupBoxSpatial.Controls.Add(this.SpatialDistClassBox);
            this.GroupBoxSpatial.Controls.Add(this.label6);
            this.GroupBoxSpatial.Controls.Add(this.label5);
            this.GroupBoxSpatial.Controls.Add(this.SpatialDistIntervalBox);
            this.GroupBoxSpatial.Controls.Add(this.SpatialJackknifeBox);
            this.GroupBoxSpatial.Controls.Add(this.SpatialHaversineBox);
            this.GroupBoxSpatial.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxSpatial.Location = new System.Drawing.Point(2, 397);
            this.GroupBoxSpatial.Name = "GroupBoxSpatial";
            this.GroupBoxSpatial.Size = new System.Drawing.Size(370, 137);
            this.GroupBoxSpatial.TabIndex = 10;
            this.GroupBoxSpatial.TabStop = false;
            this.GroupBoxSpatial.Text = "Spatial pattern analysis";
            // 
            // SpatialDistClassBox
            // 
            this.SpatialDistClassBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SpatialDistClassBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SpatialDistClassBox.FormattingEnabled = true;
            this.SpatialDistClassBox.Items.AddRange(new object[] {
            "Manually input intervals",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.SpatialDistClassBox.Location = new System.Drawing.Point(142, 22);
            this.SpatialDistClassBox.Name = "SpatialDistClassBox";
            this.SpatialDistClassBox.Size = new System.Drawing.Size(217, 28);
            this.SpatialDistClassBox.TabIndex = 517;
            this.SpatialDistClassBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label6.Location = new System.Drawing.Point(10, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 20);
            this.label6.TabIndex = 406;
            this.label6.Text = "Distance intervals";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label5.Location = new System.Drawing.Point(10, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 20);
            this.label5.TabIndex = 406;
            this.label5.Text = "# distance classes";
            // 
            // SpatialDistIntervalBox
            // 
            this.SpatialDistIntervalBox.AcceptsReturn = true;
            this.SpatialDistIntervalBox.AcceptsTab = true;
            this.SpatialDistIntervalBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SpatialDistIntervalBox.HideSelection = false;
            this.SpatialDistIntervalBox.Location = new System.Drawing.Point(142, 52);
            this.SpatialDistIntervalBox.Name = "SpatialDistIntervalBox";
            this.SpatialDistIntervalBox.Size = new System.Drawing.Size(217, 27);
            this.SpatialDistIntervalBox.TabIndex = 405;
            this.SpatialDistIntervalBox.Text = "1,2,3,4";
            this.SpatialDistIntervalBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SpatialJackknifeBox
            // 
            this.SpatialJackknifeBox.AutoSize = true;
            this.SpatialJackknifeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SpatialJackknifeBox.Location = new System.Drawing.Point(15, 107);
            this.SpatialJackknifeBox.Name = "SpatialJackknifeBox";
            this.SpatialJackknifeBox.Size = new System.Drawing.Size(247, 24);
            this.SpatialJackknifeBox.TabIndex = 0;
            this.SpatialJackknifeBox.Text = "Estimate SE by Jackknife method";
            this.SpatialJackknifeBox.UseVisualStyleBackColor = true;
            this.SpatialJackknifeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SpatialHaversineBox
            // 
            this.SpatialHaversineBox.AutoSize = true;
            this.SpatialHaversineBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SpatialHaversineBox.Location = new System.Drawing.Point(15, 82);
            this.SpatialHaversineBox.Name = "SpatialHaversineBox";
            this.SpatialHaversineBox.Size = new System.Drawing.Size(258, 24);
            this.SpatialHaversineBox.TabIndex = 0;
            this.SpatialHaversineBox.Text = "Haversine distance (degree to km)";
            this.SpatialHaversineBox.UseVisualStyleBackColor = true;
            this.SpatialHaversineBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxBayesAss
            // 
            this.GroupBoxBayesAss.Controls.Add(this.label94);
            this.GroupBoxBayesAss.Controls.Add(this.label95);
            this.GroupBoxBayesAss.Controls.Add(this.label93);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssDeltaMBox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssDeltaFBox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssDeltaABox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssNoLikelihoodBox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssMethodBox);
            this.GroupBoxBayesAss.Controls.Add(this.label88);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssNThinningBox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssBurninBox);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssNRepsBox);
            this.GroupBoxBayesAss.Controls.Add(this.label69);
            this.GroupBoxBayesAss.Controls.Add(this.BayesAssNRunsBox);
            this.GroupBoxBayesAss.Controls.Add(this.label70);
            this.GroupBoxBayesAss.Controls.Add(this.label71);
            this.GroupBoxBayesAss.Controls.Add(this.label73);
            this.GroupBoxBayesAss.Controls.Add(this.label74);
            this.GroupBoxBayesAss.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxBayesAss.Location = new System.Drawing.Point(378, 884);
            this.GroupBoxBayesAss.Name = "GroupBoxBayesAss";
            this.GroupBoxBayesAss.Size = new System.Drawing.Size(370, 193);
            this.GroupBoxBayesAss.TabIndex = 6;
            this.GroupBoxBayesAss.TabStop = false;
            this.GroupBoxBayesAss.Text = "BayesAss";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(198, 133);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(50, 20);
            this.label94.TabIndex = 521;
            this.label94.Text = "deltaF";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(23, 162);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(56, 20);
            this.label95.TabIndex = 521;
            this.label95.Text = "deltaM";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(23, 133);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(53, 20);
            this.label93.TabIndex = 521;
            this.label93.Text = "deltaA";
            // 
            // BayesAssDeltaMBox
            // 
            this.BayesAssDeltaMBox.DecimalPlaces = 4;
            this.BayesAssDeltaMBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssDeltaMBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesAssDeltaMBox.Location = new System.Drawing.Point(102, 157);
            this.BayesAssDeltaMBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesAssDeltaMBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.BayesAssDeltaMBox.Name = "BayesAssDeltaMBox";
            this.BayesAssDeltaMBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssDeltaMBox.TabIndex = 522;
            this.BayesAssDeltaMBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // BayesAssDeltaFBox
            // 
            this.BayesAssDeltaFBox.DecimalPlaces = 4;
            this.BayesAssDeltaFBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssDeltaFBox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesAssDeltaFBox.Location = new System.Drawing.Point(277, 130);
            this.BayesAssDeltaFBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesAssDeltaFBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.BayesAssDeltaFBox.Name = "BayesAssDeltaFBox";
            this.BayesAssDeltaFBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssDeltaFBox.TabIndex = 522;
            this.BayesAssDeltaFBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // BayesAssDeltaABox
            // 
            this.BayesAssDeltaABox.DecimalPlaces = 4;
            this.BayesAssDeltaABox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssDeltaABox.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesAssDeltaABox.Location = new System.Drawing.Point(102, 130);
            this.BayesAssDeltaABox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesAssDeltaABox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.BayesAssDeltaABox.Name = "BayesAssDeltaABox";
            this.BayesAssDeltaABox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssDeltaABox.TabIndex = 522;
            this.BayesAssDeltaABox.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // BayesAssNoLikelihoodBox
            // 
            this.BayesAssNoLikelihoodBox.AutoSize = true;
            this.BayesAssNoLikelihoodBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssNoLikelihoodBox.Location = new System.Drawing.Point(203, 160);
            this.BayesAssNoLikelihoodBox.Name = "BayesAssNoLikelihoodBox";
            this.BayesAssNoLikelihoodBox.Size = new System.Drawing.Size(149, 24);
            this.BayesAssNoLikelihoodBox.TabIndex = 520;
            this.BayesAssNoLikelihoodBox.Text = "Fix likelihood to 1";
            this.BayesAssNoLikelihoodBox.UseVisualStyleBackColor = true;
            // 
            // BayesAssMethodBox
            // 
            this.BayesAssMethodBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BayesAssMethodBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BayesAssMethodBox.FormattingEnabled = true;
            this.BayesAssMethodBox.Items.AddRange(new object[] {
            "Fixed Dummy Genotype",
            "Variable Dummy Genotype",
            "Fixed Genotype",
            "Variable Genotype",
            "Phenotype"});
            this.BayesAssMethodBox.Location = new System.Drawing.Point(92, 22);
            this.BayesAssMethodBox.Name = "BayesAssMethodBox";
            this.BayesAssMethodBox.Size = new System.Drawing.Size(266, 28);
            this.BayesAssMethodBox.TabIndex = 519;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label88.Location = new System.Drawing.Point(10, 25);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(61, 20);
            this.label88.TabIndex = 518;
            this.label88.Text = "Method";
            // 
            // BayesAssNThinningBox
            // 
            this.BayesAssNThinningBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssNThinningBox.Location = new System.Drawing.Point(102, 102);
            this.BayesAssNThinningBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesAssNThinningBox.Name = "BayesAssNThinningBox";
            this.BayesAssNThinningBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssNThinningBox.TabIndex = 514;
            this.BayesAssNThinningBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // BayesAssBurninBox
            // 
            this.BayesAssBurninBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssBurninBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesAssBurninBox.Location = new System.Drawing.Point(102, 75);
            this.BayesAssBurninBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.BayesAssBurninBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesAssBurninBox.Name = "BayesAssBurninBox";
            this.BayesAssBurninBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssBurninBox.TabIndex = 515;
            this.BayesAssBurninBox.Value = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            // 
            // BayesAssNRepsBox
            // 
            this.BayesAssNRepsBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssNRepsBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesAssNRepsBox.Location = new System.Drawing.Point(277, 75);
            this.BayesAssNRepsBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.BayesAssNRepsBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesAssNRepsBox.Name = "BayesAssNRepsBox";
            this.BayesAssNRepsBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssNRepsBox.TabIndex = 516;
            this.BayesAssNRepsBox.Value = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(197, 107);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(49, 20);
            this.label69.TabIndex = 509;
            this.label69.Text = "#Runs";
            // 
            // BayesAssNRunsBox
            // 
            this.BayesAssNRunsBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BayesAssNRunsBox.Location = new System.Drawing.Point(277, 102);
            this.BayesAssNRunsBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.BayesAssNRunsBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesAssNRunsBox.Name = "BayesAssNRunsBox";
            this.BayesAssNRunsBox.Size = new System.Drawing.Size(80, 27);
            this.BayesAssNRunsBox.TabIndex = 517;
            this.BayesAssNRunsBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(197, 78);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(50, 20);
            this.label70.TabIndex = 510;
            this.label70.Text = "#Reps";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(10, 55);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(132, 20);
            this.label71.TabIndex = 511;
            this.label71.Text = "MCMC parameters";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(22, 78);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(60, 20);
            this.label73.TabIndex = 512;
            this.label73.Text = "#Burnin";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(22, 107);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(75, 20);
            this.label74.TabIndex = 513;
            this.label74.Text = "#Thinning";
            // 
            // GroupBoxClustering
            // 
            this.GroupBoxClustering.Controls.Add(this.label3);
            this.GroupBoxClustering.Controls.Add(this.ClusteringWPGMABox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringWARDBox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringUPGMABox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringWPGMCBox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringFurthestBox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringUPGMCBox);
            this.GroupBoxClustering.Controls.Add(this.ClusteringNearestBox);
            this.GroupBoxClustering.Controls.Add(this.label92);
            this.GroupBoxClustering.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxClustering.Location = new System.Drawing.Point(378, 283);
            this.GroupBoxClustering.Name = "GroupBoxClustering";
            this.GroupBoxClustering.Size = new System.Drawing.Size(370, 97);
            this.GroupBoxClustering.TabIndex = 10;
            this.GroupBoxClustering.TabStop = false;
            this.GroupBoxClustering.Text = "Hierarchical clustering";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label3.Location = new System.Drawing.Point(10, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 402;
            this.label3.Text = "Methods";
            // 
            // ClusteringWPGMABox
            // 
            this.ClusteringWPGMABox.AutoSize = true;
            this.ClusteringWPGMABox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringWPGMABox.Location = new System.Drawing.Point(25, 67);
            this.ClusteringWPGMABox.Name = "ClusteringWPGMABox";
            this.ClusteringWPGMABox.Size = new System.Drawing.Size(86, 24);
            this.ClusteringWPGMABox.TabIndex = 0;
            this.ClusteringWPGMABox.Text = "WPGMA";
            this.ClusteringWPGMABox.UseVisualStyleBackColor = true;
            this.ClusteringWPGMABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringWARDBox
            // 
            this.ClusteringWARDBox.AutoSize = true;
            this.ClusteringWARDBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringWARDBox.Location = new System.Drawing.Point(292, 67);
            this.ClusteringWARDBox.Name = "ClusteringWARDBox";
            this.ClusteringWARDBox.Size = new System.Drawing.Size(74, 24);
            this.ClusteringWARDBox.TabIndex = 0;
            this.ClusteringWARDBox.Text = "WARD";
            this.ClusteringWARDBox.UseVisualStyleBackColor = true;
            this.ClusteringWARDBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringUPGMABox
            // 
            this.ClusteringUPGMABox.AutoSize = true;
            this.ClusteringUPGMABox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringUPGMABox.Location = new System.Drawing.Point(202, 42);
            this.ClusteringUPGMABox.Name = "ClusteringUPGMABox";
            this.ClusteringUPGMABox.Size = new System.Drawing.Size(82, 24);
            this.ClusteringUPGMABox.TabIndex = 0;
            this.ClusteringUPGMABox.Text = "UPGMA";
            this.ClusteringUPGMABox.UseVisualStyleBackColor = true;
            this.ClusteringUPGMABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringWPGMCBox
            // 
            this.ClusteringWPGMCBox.AutoSize = true;
            this.ClusteringWPGMCBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringWPGMCBox.Location = new System.Drawing.Point(202, 67);
            this.ClusteringWPGMCBox.Name = "ClusteringWPGMCBox";
            this.ClusteringWPGMCBox.Size = new System.Drawing.Size(85, 24);
            this.ClusteringWPGMCBox.TabIndex = 0;
            this.ClusteringWPGMCBox.Text = "WPGMC";
            this.ClusteringWPGMCBox.UseVisualStyleBackColor = true;
            this.ClusteringWPGMCBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringFurthestBox
            // 
            this.ClusteringFurthestBox.AutoSize = true;
            this.ClusteringFurthestBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringFurthestBox.Location = new System.Drawing.Point(115, 42);
            this.ClusteringFurthestBox.Name = "ClusteringFurthestBox";
            this.ClusteringFurthestBox.Size = new System.Drawing.Size(83, 24);
            this.ClusteringFurthestBox.TabIndex = 0;
            this.ClusteringFurthestBox.Text = "Furthest";
            this.ClusteringFurthestBox.UseVisualStyleBackColor = true;
            this.ClusteringFurthestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringUPGMCBox
            // 
            this.ClusteringUPGMCBox.AutoSize = true;
            this.ClusteringUPGMCBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringUPGMCBox.Location = new System.Drawing.Point(115, 67);
            this.ClusteringUPGMCBox.Name = "ClusteringUPGMCBox";
            this.ClusteringUPGMCBox.Size = new System.Drawing.Size(81, 24);
            this.ClusteringUPGMCBox.TabIndex = 0;
            this.ClusteringUPGMCBox.Text = "UPGMC";
            this.ClusteringUPGMCBox.UseVisualStyleBackColor = true;
            this.ClusteringUPGMCBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringNearestBox
            // 
            this.ClusteringNearestBox.AutoSize = true;
            this.ClusteringNearestBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClusteringNearestBox.Location = new System.Drawing.Point(25, 42);
            this.ClusteringNearestBox.Name = "ClusteringNearestBox";
            this.ClusteringNearestBox.Size = new System.Drawing.Size(82, 24);
            this.ClusteringNearestBox.TabIndex = 0;
            this.ClusteringNearestBox.Text = "Nearest";
            this.ClusteringNearestBox.UseVisualStyleBackColor = true;
            this.ClusteringNearestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label92.Location = new System.Drawing.Point(128, 22);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(227, 20);
            this.label92.TabIndex = 516;
            this.label92.Text = "* Req. genetic distance estimates";
            // 
            // GroupBoxAMOVA
            // 
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAMLBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAGenotypeBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAAnisoBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAHomoCorrBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAHomoBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVASMMBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAIAMBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAIgnoreIndBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVAOutputSSBox);
            this.GroupBoxAMOVA.Controls.Add(this.AMOVANPermBox);
            this.GroupBoxAMOVA.Controls.Add(this.label102);
            this.GroupBoxAMOVA.Controls.Add(this.label58);
            this.GroupBoxAMOVA.Controls.Add(this.label2);
            this.GroupBoxAMOVA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxAMOVA.Location = new System.Drawing.Point(378, 673);
            this.GroupBoxAMOVA.Name = "GroupBoxAMOVA";
            this.GroupBoxAMOVA.Size = new System.Drawing.Size(370, 205);
            this.GroupBoxAMOVA.TabIndex = 6;
            this.GroupBoxAMOVA.TabStop = false;
            this.GroupBoxAMOVA.Text = "AMOVA";
            // 
            // AMOVAMLBox
            // 
            this.AMOVAMLBox.AutoSize = true;
            this.AMOVAMLBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAMLBox.Location = new System.Drawing.Point(23, 175);
            this.AMOVAMLBox.Name = "AMOVAMLBox";
            this.AMOVAMLBox.Size = new System.Drawing.Size(210, 24);
            this.AMOVAMLBox.TabIndex = 509;
            this.AMOVAMLBox.Text = "Maximum-likelihood (IAM)";
            this.AMOVAMLBox.UseVisualStyleBackColor = true;
            this.AMOVAMLBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAGenotypeBox
            // 
            this.AMOVAGenotypeBox.AutoSize = true;
            this.AMOVAGenotypeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAGenotypeBox.Location = new System.Drawing.Point(185, 150);
            this.AMOVAGenotypeBox.Name = "AMOVAGenotypeBox";
            this.AMOVAGenotypeBox.Size = new System.Drawing.Size(145, 24);
            this.AMOVAGenotypeBox.TabIndex = 509;
            this.AMOVAGenotypeBox.Text = "Weight genotype";
            this.AMOVAGenotypeBox.UseVisualStyleBackColor = true;
            this.AMOVAGenotypeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAAnisoBox
            // 
            this.AMOVAAnisoBox.AutoSize = true;
            this.AMOVAAnisoBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAAnisoBox.Location = new System.Drawing.Point(23, 150);
            this.AMOVAAnisoBox.Name = "AMOVAAnisoBox";
            this.AMOVAAnisoBox.Size = new System.Drawing.Size(103, 24);
            this.AMOVAAnisoBox.TabIndex = 509;
            this.AMOVAAnisoBox.Text = "Anisoploid";
            this.AMOVAAnisoBox.UseVisualStyleBackColor = true;
            this.AMOVAAnisoBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAHomoCorrBox
            // 
            this.AMOVAHomoCorrBox.AutoSize = true;
            this.AMOVAHomoCorrBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAHomoCorrBox.Location = new System.Drawing.Point(137, 125);
            this.AMOVAHomoCorrBox.Name = "AMOVAHomoCorrBox";
            this.AMOVAHomoCorrBox.Size = new System.Drawing.Size(193, 24);
            this.AMOVAHomoCorrBox.TabIndex = 509;
            this.AMOVAHomoCorrBox.Text = "with type rate correction";
            this.AMOVAHomoCorrBox.UseVisualStyleBackColor = true;
            this.AMOVAHomoCorrBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAHomoBox
            // 
            this.AMOVAHomoBox.AutoSize = true;
            this.AMOVAHomoBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAHomoBox.Location = new System.Drawing.Point(23, 125);
            this.AMOVAHomoBox.Name = "AMOVAHomoBox";
            this.AMOVAHomoBox.Size = new System.Drawing.Size(108, 24);
            this.AMOVAHomoBox.TabIndex = 509;
            this.AMOVAHomoBox.Text = "Homoploid";
            this.AMOVAHomoBox.UseVisualStyleBackColor = true;
            this.AMOVAHomoBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVASMMBox
            // 
            this.AMOVASMMBox.AutoSize = true;
            this.AMOVASMMBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVASMMBox.Location = new System.Drawing.Point(258, 25);
            this.AMOVASMMBox.Name = "AMOVASMMBox";
            this.AMOVASMMBox.Size = new System.Drawing.Size(65, 24);
            this.AMOVASMMBox.TabIndex = 508;
            this.AMOVASMMBox.Text = "SMM";
            this.AMOVASMMBox.UseVisualStyleBackColor = true;
            this.AMOVASMMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAIAMBox
            // 
            this.AMOVAIAMBox.AutoSize = true;
            this.AMOVAIAMBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAIAMBox.Location = new System.Drawing.Point(147, 25);
            this.AMOVAIAMBox.Name = "AMOVAIAMBox";
            this.AMOVAIAMBox.Size = new System.Drawing.Size(58, 24);
            this.AMOVAIAMBox.TabIndex = 508;
            this.AMOVAIAMBox.Text = "IAM";
            this.AMOVAIAMBox.UseVisualStyleBackColor = true;
            this.AMOVAIAMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAIgnoreIndBox
            // 
            this.AMOVAIgnoreIndBox.AutoSize = true;
            this.AMOVAIgnoreIndBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAIgnoreIndBox.Location = new System.Drawing.Point(17, 50);
            this.AMOVAIgnoreIndBox.Name = "AMOVAIgnoreIndBox";
            this.AMOVAIgnoreIndBox.Size = new System.Drawing.Size(137, 24);
            this.AMOVAIgnoreIndBox.TabIndex = 507;
            this.AMOVAIgnoreIndBox.Text = "Ignore ind. level";
            this.AMOVAIgnoreIndBox.UseVisualStyleBackColor = true;
            this.AMOVAIgnoreIndBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAOutputSSBox
            // 
            this.AMOVAOutputSSBox.AutoSize = true;
            this.AMOVAOutputSSBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVAOutputSSBox.Location = new System.Drawing.Point(17, 75);
            this.AMOVAOutputSSBox.Name = "AMOVAOutputSSBox";
            this.AMOVAOutputSSBox.Size = new System.Drawing.Size(184, 24);
            this.AMOVAOutputSSBox.TabIndex = 507;
            this.AMOVAOutputSSBox.Text = "Output SS for each unit";
            this.AMOVAOutputSSBox.UseVisualStyleBackColor = true;
            this.AMOVAOutputSSBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVANPermBox
            // 
            this.AMOVANPermBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AMOVANPermBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.AMOVANPermBox.Location = new System.Drawing.Point(273, 50);
            this.AMOVANPermBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.AMOVANPermBox.Name = "AMOVANPermBox";
            this.AMOVANPermBox.Size = new System.Drawing.Size(72, 27);
            this.AMOVANPermBox.TabIndex = 506;
            this.AMOVANPermBox.Value = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.AMOVANPermBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label102.Location = new System.Drawing.Point(10, 103);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(67, 20);
            this.label102.TabIndex = 402;
            this.label102.Text = "Methods";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label58.Location = new System.Drawing.Point(10, 25);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(113, 20);
            this.label58.TabIndex = 402;
            this.label58.Text = "Distance model";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label2.Location = new System.Drawing.Point(172, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "#Permutation";
            // 
            // GroupBoxParentage
            // 
            this.GroupBoxParentage.Controls.Add(this.ParentageRedoBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageEstSampleBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageUnknownBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageParentPairBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageSkipSimBox);
            this.GroupBoxParentage.Controls.Add(this.ParentagePaternityBox);
            this.GroupBoxParentage.Controls.Add(this.label81);
            this.GroupBoxParentage.Controls.Add(this.ParentageEstErrorBox);
            this.GroupBoxParentage.Controls.Add(this.label51);
            this.GroupBoxParentage.Controls.Add(this.ParentageMethodBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageOutputBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageErrorNSimBox);
            this.GroupBoxParentage.Controls.Add(this.label45);
            this.GroupBoxParentage.Controls.Add(this.label52);
            this.GroupBoxParentage.Controls.Add(this.label72);
            this.GroupBoxParentage.Controls.Add(this.label103);
            this.GroupBoxParentage.Controls.Add(this.ParentageNSimBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageUnknownNCandidateBox);
            this.GroupBoxParentage.Controls.Add(this.label75);
            this.GroupBoxParentage.Controls.Add(this.ParentageParentPairNMotherBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageParentPairNFatherBox);
            this.GroupBoxParentage.Controls.Add(this.label76);
            this.GroupBoxParentage.Controls.Add(this.ParentagePaternityNFatherBox);
            this.GroupBoxParentage.Controls.Add(this.ParentageSamplingRateBox);
            this.GroupBoxParentage.Controls.Add(this.label77);
            this.GroupBoxParentage.Controls.Add(this.label18);
            this.GroupBoxParentage.Controls.Add(this.label78);
            this.GroupBoxParentage.Controls.Add(this.label79);
            this.GroupBoxParentage.Controls.Add(this.ParentageMistypeRateBox);
            this.GroupBoxParentage.Controls.Add(this.label80);
            this.GroupBoxParentage.Controls.Add(this.label82);
            this.GroupBoxParentage.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxParentage.Location = new System.Drawing.Point(2, 542);
            this.GroupBoxParentage.Name = "GroupBoxParentage";
            this.GroupBoxParentage.Size = new System.Drawing.Size(370, 473);
            this.GroupBoxParentage.TabIndex = 9;
            this.GroupBoxParentage.TabStop = false;
            this.GroupBoxParentage.Text = "Parentage analysis";
            // 
            // ParentageRedoBox
            // 
            this.ParentageRedoBox.AutoSize = true;
            this.ParentageRedoBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageRedoBox.Location = new System.Drawing.Point(203, 410);
            this.ParentageRedoBox.Name = "ParentageRedoBox";
            this.ParentageRedoBox.Size = new System.Drawing.Size(125, 24);
            this.ParentageRedoBox.TabIndex = 66;
            this.ParentageRedoBox.Text = "Redo analyses";
            this.ParentageRedoBox.UseVisualStyleBackColor = true;
            this.ParentageRedoBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageEstSampleBox
            // 
            this.ParentageEstSampleBox.AutoSize = true;
            this.ParentageEstSampleBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageEstSampleBox.Location = new System.Drawing.Point(10, 410);
            this.ParentageEstSampleBox.Name = "ParentageEstSampleBox";
            this.ParentageEstSampleBox.Size = new System.Drawing.Size(170, 24);
            this.ParentageEstSampleBox.TabIndex = 66;
            this.ParentageEstSampleBox.Text = "Estimate sample rate";
            this.ParentageEstSampleBox.UseVisualStyleBackColor = true;
            this.ParentageEstSampleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageUnknownBox
            // 
            this.ParentageUnknownBox.AutoSize = true;
            this.ParentageUnknownBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageUnknownBox.Location = new System.Drawing.Point(92, 82);
            this.ParentageUnknownBox.Name = "ParentageUnknownBox";
            this.ParentageUnknownBox.Size = new System.Drawing.Size(200, 24);
            this.ParentageUnknownBox.TabIndex = 65;
            this.ParentageUnknownBox.Text = "Parent pair (sex unknown)";
            this.ParentageUnknownBox.UseVisualStyleBackColor = true;
            this.ParentageUnknownBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // ParentageParentPairBox
            // 
            this.ParentageParentPairBox.AutoSize = true;
            this.ParentageParentPairBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageParentPairBox.Location = new System.Drawing.Point(208, 57);
            this.ParentageParentPairBox.Name = "ParentageParentPairBox";
            this.ParentageParentPairBox.Size = new System.Drawing.Size(102, 24);
            this.ParentageParentPairBox.TabIndex = 65;
            this.ParentageParentPairBox.Text = "Parent pair";
            this.ParentageParentPairBox.UseVisualStyleBackColor = true;
            this.ParentageParentPairBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // ParentageSkipSimBox
            // 
            this.ParentageSkipSimBox.AutoSize = true;
            this.ParentageSkipSimBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageSkipSimBox.Location = new System.Drawing.Point(203, 132);
            this.ParentageSkipSimBox.Name = "ParentageSkipSimBox";
            this.ParentageSkipSimBox.Size = new System.Drawing.Size(132, 24);
            this.ParentageSkipSimBox.TabIndex = 65;
            this.ParentageSkipSimBox.Text = "Skip simulation";
            this.ParentageSkipSimBox.UseVisualStyleBackColor = true;
            this.ParentageSkipSimBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentagePaternityBox
            // 
            this.ParentagePaternityBox.AutoSize = true;
            this.ParentagePaternityBox.Checked = true;
            this.ParentagePaternityBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ParentagePaternityBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentagePaternityBox.Location = new System.Drawing.Point(92, 57);
            this.ParentagePaternityBox.Name = "ParentagePaternityBox";
            this.ParentagePaternityBox.Size = new System.Drawing.Size(88, 24);
            this.ParentagePaternityBox.TabIndex = 65;
            this.ParentagePaternityBox.Text = "Paternity";
            this.ParentagePaternityBox.UseVisualStyleBackColor = true;
            this.ParentagePaternityBox.CheckedChanged += new System.EventHandler(this.ShowPanel);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label81.Location = new System.Drawing.Point(10, 327);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(212, 20);
            this.label81.TabIndex = 63;
            this.label81.Text = "Estimate genotyping error rate";
            // 
            // ParentageEstErrorBox
            // 
            this.ParentageEstErrorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ParentageEstErrorBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageEstErrorBox.FormattingEnabled = true;
            this.ParentageEstErrorBox.Items.AddRange(new object[] {
            "Don\'t estimate",
            "80% confidence level",
            "95% confidence level",
            "99% confidence level",
            "99.9% confidence level"});
            this.ParentageEstErrorBox.Location = new System.Drawing.Point(33, 350);
            this.ParentageEstErrorBox.Name = "ParentageEstErrorBox";
            this.ParentageEstErrorBox.Size = new System.Drawing.Size(304, 28);
            this.ParentageEstErrorBox.TabIndex = 64;
            this.ParentageEstErrorBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            this.ParentageEstErrorBox.SelectedValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label51.Location = new System.Drawing.Point(10, 442);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(89, 20);
            this.label51.TabIndex = 63;
            this.label51.Text = "Output style";
            // 
            // ParentageMethodBox
            // 
            this.ParentageMethodBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ParentageMethodBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageMethodBox.FormattingEnabled = true;
            this.ParentageMethodBox.Items.AddRange(new object[] {
            "Phenotype (Huang et al. 2020)",
            "Exclusion (Zwart et al. 2016)",
            "Dominant (Rodzen et al. 2004)"});
            this.ParentageMethodBox.Location = new System.Drawing.Point(92, 22);
            this.ParentageMethodBox.Name = "ParentageMethodBox";
            this.ParentageMethodBox.Size = new System.Drawing.Size(266, 28);
            this.ParentageMethodBox.TabIndex = 64;
            this.ParentageMethodBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            this.ParentageMethodBox.SelectedValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageOutputBox
            // 
            this.ParentageOutputBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ParentageOutputBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageOutputBox.FormattingEnabled = true;
            this.ParentageOutputBox.Items.AddRange(new object[] {
            "Top 1 LOD parent",
            "Top 2 LOD parents",
            "Top 5 LOD parents",
            "All positive LOD parents",
            "All candidate parents"});
            this.ParentageOutputBox.Location = new System.Drawing.Point(115, 437);
            this.ParentageOutputBox.Name = "ParentageOutputBox";
            this.ParentageOutputBox.Size = new System.Drawing.Size(222, 28);
            this.ParentageOutputBox.TabIndex = 64;
            this.ParentageOutputBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            this.ParentageOutputBox.SelectedValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageErrorNSimBox
            // 
            this.ParentageErrorNSimBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageErrorNSimBox.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageErrorNSimBox.Location = new System.Drawing.Point(258, 378);
            this.ParentageErrorNSimBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.ParentageErrorNSimBox.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageErrorNSimBox.Name = "ParentageErrorNSimBox";
            this.ParentageErrorNSimBox.Size = new System.Drawing.Size(80, 27);
            this.ParentageErrorNSimBox.TabIndex = 44;
            this.ParentageErrorNSimBox.Value = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.ParentageErrorNSimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label45.Location = new System.Drawing.Point(10, 58);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(46, 20);
            this.label45.TabIndex = 60;
            this.label45.Text = "Types";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label52.Location = new System.Drawing.Point(10, 25);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(61, 20);
            this.label52.TabIndex = 60;
            this.label52.Text = "Method";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label72.Location = new System.Drawing.Point(10, 108);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(159, 20);
            this.label72.TabIndex = 60;
            this.label72.Text = "Simulation parameters";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label103.Location = new System.Drawing.Point(98, 382);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(158, 20);
            this.label103.TabIndex = 51;
            this.label103.Text = "#sample to estimate δ";
            // 
            // ParentageNSimBox
            // 
            this.ParentageNSimBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageNSimBox.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageNSimBox.Location = new System.Drawing.Point(118, 130);
            this.ParentageNSimBox.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.ParentageNSimBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageNSimBox.Name = "ParentageNSimBox";
            this.ParentageNSimBox.Size = new System.Drawing.Size(70, 27);
            this.ParentageNSimBox.TabIndex = 42;
            this.ParentageNSimBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageNSimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageUnknownNCandidateBox
            // 
            this.ParentageUnknownNCandidateBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageUnknownNCandidateBox.Location = new System.Drawing.Point(258, 295);
            this.ParentageUnknownNCandidateBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.Name = "ParentageUnknownNCandidateBox";
            this.ParentageUnknownNCandidateBox.Size = new System.Drawing.Size(80, 27);
            this.ParentageUnknownNCandidateBox.TabIndex = 45;
            this.ParentageUnknownNCandidateBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label75.Location = new System.Drawing.Point(198, 162);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(91, 20);
            this.label75.TabIndex = 50;
            this.label75.Text = "Mistype rate";
            // 
            // ParentageParentPairNMotherBox
            // 
            this.ParentageParentPairNMotherBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageParentPairNMotherBox.Location = new System.Drawing.Point(258, 240);
            this.ParentageParentPairNMotherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.Name = "ParentageParentPairNMotherBox";
            this.ParentageParentPairNMotherBox.Size = new System.Drawing.Size(80, 27);
            this.ParentageParentPairNMotherBox.TabIndex = 47;
            this.ParentageParentPairNMotherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageParentPairNFatherBox
            // 
            this.ParentageParentPairNFatherBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageParentPairNFatherBox.Location = new System.Drawing.Point(258, 212);
            this.ParentageParentPairNFatherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.Name = "ParentageParentPairNFatherBox";
            this.ParentageParentPairNFatherBox.Size = new System.Drawing.Size(80, 27);
            this.ParentageParentPairNFatherBox.TabIndex = 46;
            this.ParentageParentPairNFatherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label76.Location = new System.Drawing.Point(22, 133);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(95, 20);
            this.label76.TabIndex = 52;
            this.label76.Text = "#Simulations";
            // 
            // ParentagePaternityNFatherBox
            // 
            this.ParentagePaternityNFatherBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentagePaternityNFatherBox.Location = new System.Drawing.Point(258, 185);
            this.ParentagePaternityNFatherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.Name = "ParentagePaternityNFatherBox";
            this.ParentagePaternityNFatherBox.Size = new System.Drawing.Size(80, 27);
            this.ParentagePaternityNFatherBox.TabIndex = 48;
            this.ParentagePaternityNFatherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageSamplingRateBox
            // 
            this.ParentageSamplingRateBox.DecimalPlaces = 4;
            this.ParentageSamplingRateBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageSamplingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.Location = new System.Drawing.Point(118, 157);
            this.ParentageSamplingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageSamplingRateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.Name = "ParentageSamplingRateBox";
            this.ParentageSamplingRateBox.Size = new System.Drawing.Size(70, 27);
            this.ParentageSamplingRateBox.TabIndex = 39;
            this.ParentageSamplingRateBox.Value = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label77.Location = new System.Drawing.Point(22, 272);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(181, 20);
            this.label77.TabIndex = 57;
            this.label77.Text = "Parent pair (sex unknown):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label18.Location = new System.Drawing.Point(108, 298);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(139, 20);
            this.label18.TabIndex = 58;
            this.label18.Text = "#Candidate parents";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label78.Location = new System.Drawing.Point(102, 243);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(144, 20);
            this.label78.TabIndex = 58;
            this.label78.Text = "#Candidate mothers";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label79.Location = new System.Drawing.Point(22, 217);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(213, 20);
            this.label79.TabIndex = 55;
            this.label79.Text = "Parent pair: #Candidate fathers";
            // 
            // ParentageMistypeRateBox
            // 
            this.ParentageMistypeRateBox.DecimalPlaces = 4;
            this.ParentageMistypeRateBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ParentageMistypeRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageMistypeRateBox.Location = new System.Drawing.Point(295, 157);
            this.ParentageMistypeRateBox.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.ParentageMistypeRateBox.Name = "ParentageMistypeRateBox";
            this.ParentageMistypeRateBox.Size = new System.Drawing.Size(70, 27);
            this.ParentageMistypeRateBox.TabIndex = 40;
            this.ParentageMistypeRateBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageMistypeRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label80.Location = new System.Drawing.Point(22, 188);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(211, 20);
            this.label80.TabIndex = 56;
            this.label80.Text = "Paternity:    #Candidate fathers";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label82.Location = new System.Drawing.Point(22, 162);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(89, 20);
            this.label82.TabIndex = 49;
            this.label82.Text = "Sample rate";
            // 
            // GroupBoxDist
            // 
            this.GroupBoxDist.Controls.Add(this.DistNei1972Box);
            this.GroupBoxDist.Controls.Add(this.DistRegBox);
            this.GroupBoxDist.Controls.Add(this.DistPopBox);
            this.GroupBoxDist.Controls.Add(this.DistIndBox);
            this.GroupBoxDist.Controls.Add(this.label89);
            this.GroupBoxDist.Controls.Add(this.label112);
            this.GroupBoxDist.Controls.Add(this.label50);
            this.GroupBoxDist.Controls.Add(this.label38);
            this.GroupBoxDist.Controls.Add(this.DistSlatkinBox);
            this.GroupBoxDist.Controls.Add(this.DistRoger1973Box);
            this.GroupBoxDist.Controls.Add(this.DistNei1983Box);
            this.GroupBoxDist.Controls.Add(this.DistReynolds1983Box);
            this.GroupBoxDist.Controls.Add(this.DistNei1973Box);
            this.GroupBoxDist.Controls.Add(this.DistReynold1993Box);
            this.GroupBoxDist.Controls.Add(this.DistGoldstein1995Box);
            this.GroupBoxDist.Controls.Add(this.DistCavalli1967Box);
            this.GroupBoxDist.Controls.Add(this.DistEuclideanBox);
            this.GroupBoxDist.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxDist.Location = new System.Drawing.Point(757, 142);
            this.GroupBoxDist.Name = "GroupBoxDist";
            this.GroupBoxDist.Size = new System.Drawing.Size(370, 227);
            this.GroupBoxDist.TabIndex = 6;
            this.GroupBoxDist.TabStop = false;
            this.GroupBoxDist.Text = "Genetic distance";
            // 
            // DistNei1972Box
            // 
            this.DistNei1972Box.AutoSize = true;
            this.DistNei1972Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistNei1972Box.Location = new System.Drawing.Point(218, 72);
            this.DistNei1972Box.Name = "DistNei1972Box";
            this.DistNei1972Box.Size = new System.Drawing.Size(113, 24);
            this.DistNei1972Box.TabIndex = 0;
            this.DistNei1972Box.Text = "Nei 1972 DS";
            this.DistNei1972Box.UseVisualStyleBackColor = true;
            this.DistNei1972Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistRegBox
            // 
            this.DistRegBox.AutoSize = true;
            this.DistRegBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistRegBox.Location = new System.Drawing.Point(280, 25);
            this.DistRegBox.Name = "DistRegBox";
            this.DistRegBox.Size = new System.Drawing.Size(78, 24);
            this.DistRegBox.TabIndex = 406;
            this.DistRegBox.Text = "Region";
            this.DistRegBox.UseVisualStyleBackColor = true;
            this.DistRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistPopBox
            // 
            this.DistPopBox.AutoSize = true;
            this.DistPopBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistPopBox.Location = new System.Drawing.Point(175, 25);
            this.DistPopBox.Name = "DistPopBox";
            this.DistPopBox.Size = new System.Drawing.Size(102, 24);
            this.DistPopBox.TabIndex = 405;
            this.DistPopBox.Text = "Population";
            this.DistPopBox.UseVisualStyleBackColor = true;
            this.DistPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistIndBox
            // 
            this.DistIndBox.AutoSize = true;
            this.DistIndBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistIndBox.Location = new System.Drawing.Point(72, 25);
            this.DistIndBox.Name = "DistIndBox";
            this.DistIndBox.Size = new System.Drawing.Size(96, 24);
            this.DistIndBox.TabIndex = 404;
            this.DistIndBox.Text = "Individual";
            this.DistIndBox.UseVisualStyleBackColor = true;
            this.DistIndBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(42, 370);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(0, 20);
            this.label89.TabIndex = 403;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label112.Location = new System.Drawing.Point(228, 197);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(133, 20);
            this.label112.TabIndex = 403;
            this.label112.Text = "* req. Fst estimates";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label50.Location = new System.Drawing.Point(10, 50);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(78, 20);
            this.label50.TabIndex = 403;
            this.label50.Text = "Estimators";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label38.Location = new System.Drawing.Point(10, 25);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(51, 20);
            this.label38.TabIndex = 403;
            this.label38.Text = "Range";
            // 
            // DistSlatkinBox
            // 
            this.DistSlatkinBox.AutoSize = true;
            this.DistSlatkinBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistSlatkinBox.Location = new System.Drawing.Point(25, 197);
            this.DistSlatkinBox.Name = "DistSlatkinBox";
            this.DistSlatkinBox.Size = new System.Drawing.Size(208, 24);
            this.DistSlatkinBox.TabIndex = 0;
            this.DistSlatkinBox.Text = "Slatkin 1995 DSl Fst/(1-Fst)";
            this.DistSlatkinBox.UseVisualStyleBackColor = true;
            this.DistSlatkinBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistRoger1973Box
            // 
            this.DistRoger1973Box.AutoSize = true;
            this.DistRoger1973Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistRoger1973Box.Location = new System.Drawing.Point(218, 147);
            this.DistRoger1973Box.Name = "DistRoger1973Box";
            this.DistRoger1973Box.Size = new System.Drawing.Size(135, 24);
            this.DistRoger1973Box.TabIndex = 0;
            this.DistRoger1973Box.Text = "Roger 1972 DR ";
            this.DistRoger1973Box.UseVisualStyleBackColor = true;
            this.DistRoger1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistNei1983Box
            // 
            this.DistNei1983Box.AutoSize = true;
            this.DistNei1983Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistNei1983Box.Location = new System.Drawing.Point(218, 97);
            this.DistNei1983Box.Name = "DistNei1983Box";
            this.DistNei1983Box.Size = new System.Drawing.Size(115, 24);
            this.DistNei1983Box.TabIndex = 0;
            this.DistNei1983Box.Text = "Nei 1983 DA";
            this.DistNei1983Box.UseVisualStyleBackColor = true;
            this.DistNei1983Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistReynolds1983Box
            // 
            this.DistReynolds1983Box.AutoSize = true;
            this.DistReynolds1983Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistReynolds1983Box.Location = new System.Drawing.Point(25, 172);
            this.DistReynolds1983Box.Name = "DistReynolds1983Box";
            this.DistReynolds1983Box.Size = new System.Drawing.Size(229, 24);
            this.DistReynolds1983Box.TabIndex = 0;
            this.DistReynolds1983Box.Text = "Reynolds 1983 DRA -ln(1-Fst) ";
            this.DistReynolds1983Box.UseVisualStyleBackColor = true;
            this.DistReynolds1983Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistNei1973Box
            // 
            this.DistNei1973Box.AutoSize = true;
            this.DistNei1973Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistNei1973Box.Location = new System.Drawing.Point(25, 147);
            this.DistNei1973Box.Name = "DistNei1973Box";
            this.DistNei1973Box.Size = new System.Drawing.Size(118, 24);
            this.DistNei1973Box.TabIndex = 0;
            this.DistNei1973Box.Text = "Nei 1973 Dm";
            this.DistNei1973Box.UseVisualStyleBackColor = true;
            this.DistNei1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistReynold1993Box
            // 
            this.DistReynold1993Box.AutoSize = true;
            this.DistReynold1993Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistReynold1993Box.Location = new System.Drawing.Point(25, 97);
            this.DistReynold1993Box.Name = "DistReynold1993Box";
            this.DistReynold1993Box.Size = new System.Drawing.Size(158, 24);
            this.DistReynold1993Box.TabIndex = 0;
            this.DistReynold1993Box.Text = "Reynolds 1983  θW";
            this.DistReynold1993Box.UseVisualStyleBackColor = true;
            this.DistReynold1993Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistGoldstein1995Box
            // 
            this.DistGoldstein1995Box.AutoSize = true;
            this.DistGoldstein1995Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistGoldstein1995Box.Location = new System.Drawing.Point(218, 122);
            this.DistGoldstein1995Box.Name = "DistGoldstein1995Box";
            this.DistGoldstein1995Box.Size = new System.Drawing.Size(160, 24);
            this.DistGoldstein1995Box.TabIndex = 0;
            this.DistGoldstein1995Box.Text = "Goldstein 1995 dμ2";
            this.DistGoldstein1995Box.UseVisualStyleBackColor = true;
            this.DistGoldstein1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistCavalli1967Box
            // 
            this.DistCavalli1967Box.AutoSize = true;
            this.DistCavalli1967Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistCavalli1967Box.Location = new System.Drawing.Point(25, 72);
            this.DistCavalli1967Box.Name = "DistCavalli1967Box";
            this.DistCavalli1967Box.Size = new System.Drawing.Size(194, 24);
            this.DistCavalli1967Box.TabIndex = 0;
            this.DistCavalli1967Box.Text = "Cavalli-Sforza 1967 DCH";
            this.DistCavalli1967Box.UseVisualStyleBackColor = true;
            this.DistCavalli1967Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistEuclideanBox
            // 
            this.DistEuclideanBox.AutoSize = true;
            this.DistEuclideanBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DistEuclideanBox.Location = new System.Drawing.Point(25, 122);
            this.DistEuclideanBox.Name = "DistEuclideanBox";
            this.DistEuclideanBox.Size = new System.Drawing.Size(154, 24);
            this.DistEuclideanBox.TabIndex = 0;
            this.DistEuclideanBox.Text = "Euclidean distance";
            this.DistEuclideanBox.UseVisualStyleBackColor = true;
            this.DistEuclideanBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxRelationship
            // 
            this.GroupBoxRelationship.Controls.Add(this.RelationshipRegBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipJackknifeBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipPopBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipLoiselle1995Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipRitland1996Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipHuang2015Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipLoiselle1995mBox);
            this.GroupBoxRelationship.Controls.Add(this.label4);
            this.GroupBoxRelationship.Controls.Add(this.label9);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipHuangUnpubBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipHuangUnpubmBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipHardy1999Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipWeir1996Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipHuang2014Box);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipRitland1996mBox);
            this.GroupBoxRelationship.Controls.Add(this.RelationshipTotBox);
            this.GroupBoxRelationship.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxRelationship.Location = new System.Drawing.Point(757, 443);
            this.GroupBoxRelationship.Name = "GroupBoxRelationship";
            this.GroupBoxRelationship.Size = new System.Drawing.Size(370, 227);
            this.GroupBoxRelationship.TabIndex = 6;
            this.GroupBoxRelationship.TabStop = false;
            this.GroupBoxRelationship.Text = "Relationship coefficient";
            // 
            // RelationshipRegBox
            // 
            this.RelationshipRegBox.AutoSize = true;
            this.RelationshipRegBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipRegBox.Location = new System.Drawing.Point(178, 25);
            this.RelationshipRegBox.Name = "RelationshipRegBox";
            this.RelationshipRegBox.Size = new System.Drawing.Size(78, 24);
            this.RelationshipRegBox.TabIndex = 404;
            this.RelationshipRegBox.Text = "Region";
            this.RelationshipRegBox.UseVisualStyleBackColor = true;
            this.RelationshipRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipJackknifeBox
            // 
            this.RelationshipJackknifeBox.AutoSize = true;
            this.RelationshipJackknifeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipJackknifeBox.Location = new System.Drawing.Point(17, 197);
            this.RelationshipJackknifeBox.Name = "RelationshipJackknifeBox";
            this.RelationshipJackknifeBox.Size = new System.Drawing.Size(247, 24);
            this.RelationshipJackknifeBox.TabIndex = 404;
            this.RelationshipJackknifeBox.Text = "Estimate SE by Jackknife method";
            this.RelationshipJackknifeBox.UseVisualStyleBackColor = true;
            this.RelationshipJackknifeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipPopBox
            // 
            this.RelationshipPopBox.AutoSize = true;
            this.RelationshipPopBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipPopBox.Location = new System.Drawing.Point(65, 25);
            this.RelationshipPopBox.Name = "RelationshipPopBox";
            this.RelationshipPopBox.Size = new System.Drawing.Size(102, 24);
            this.RelationshipPopBox.TabIndex = 404;
            this.RelationshipPopBox.Text = "Population";
            this.RelationshipPopBox.UseVisualStyleBackColor = true;
            this.RelationshipPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipLoiselle1995Box
            // 
            this.RelationshipLoiselle1995Box.AutoSize = true;
            this.RelationshipLoiselle1995Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipLoiselle1995Box.Location = new System.Drawing.Point(187, 122);
            this.RelationshipLoiselle1995Box.Name = "RelationshipLoiselle1995Box";
            this.RelationshipLoiselle1995Box.Size = new System.Drawing.Size(140, 24);
            this.RelationshipLoiselle1995Box.TabIndex = 0;
            this.RelationshipLoiselle1995Box.Text = "Loiselle 1995 (θ)";
            this.RelationshipLoiselle1995Box.UseVisualStyleBackColor = true;
            this.RelationshipLoiselle1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipRitland1996Box
            // 
            this.RelationshipRitland1996Box.AutoSize = true;
            this.RelationshipRitland1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipRitland1996Box.Location = new System.Drawing.Point(187, 97);
            this.RelationshipRitland1996Box.Name = "RelationshipRitland1996Box";
            this.RelationshipRitland1996Box.Size = new System.Drawing.Size(137, 24);
            this.RelationshipRitland1996Box.TabIndex = 0;
            this.RelationshipRitland1996Box.Text = "Ritland 1996 (θ)";
            this.RelationshipRitland1996Box.UseVisualStyleBackColor = true;
            this.RelationshipRitland1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipHuang2015Box
            // 
            this.RelationshipHuang2015Box.AutoSize = true;
            this.RelationshipHuang2015Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipHuang2015Box.Location = new System.Drawing.Point(187, 72);
            this.RelationshipHuang2015Box.Name = "RelationshipHuang2015Box";
            this.RelationshipHuang2015Box.Size = new System.Drawing.Size(184, 24);
            this.RelationshipHuang2015Box.TabIndex = 0;
            this.RelationshipHuang2015Box.Text = "Huang 2015 Likelihood";
            this.RelationshipHuang2015Box.UseVisualStyleBackColor = true;
            this.RelationshipHuang2015Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipLoiselle1995mBox
            // 
            this.RelationshipLoiselle1995mBox.AutoSize = true;
            this.RelationshipLoiselle1995mBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipLoiselle1995mBox.Location = new System.Drawing.Point(25, 122);
            this.RelationshipLoiselle1995mBox.Name = "RelationshipLoiselle1995mBox";
            this.RelationshipLoiselle1995mBox.Size = new System.Drawing.Size(136, 24);
            this.RelationshipLoiselle1995mBox.TabIndex = 0;
            this.RelationshipLoiselle1995mBox.Text = "Loiselle 1995 (r)";
            this.RelationshipLoiselle1995mBox.UseVisualStyleBackColor = true;
            this.RelationshipLoiselle1995mBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label4.Location = new System.Drawing.Point(10, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 401;
            this.label4.Text = "Range";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label9.Location = new System.Drawing.Point(10, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 20);
            this.label9.TabIndex = 401;
            this.label9.Text = "Estimators";
            // 
            // RelationshipHuangUnpubBox
            // 
            this.RelationshipHuangUnpubBox.AutoSize = true;
            this.RelationshipHuangUnpubBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipHuangUnpubBox.Location = new System.Drawing.Point(187, 172);
            this.RelationshipHuangUnpubBox.Name = "RelationshipHuangUnpubBox";
            this.RelationshipHuangUnpubBox.Size = new System.Drawing.Size(144, 24);
            this.RelationshipHuangUnpubBox.TabIndex = 0;
            this.RelationshipHuangUnpubBox.Text = "Huang unpub (θ)";
            this.RelationshipHuangUnpubBox.UseVisualStyleBackColor = true;
            this.RelationshipHuangUnpubBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipHuangUnpubmBox
            // 
            this.RelationshipHuangUnpubmBox.AutoSize = true;
            this.RelationshipHuangUnpubmBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipHuangUnpubmBox.Location = new System.Drawing.Point(25, 172);
            this.RelationshipHuangUnpubmBox.Name = "RelationshipHuangUnpubmBox";
            this.RelationshipHuangUnpubmBox.Size = new System.Drawing.Size(140, 24);
            this.RelationshipHuangUnpubmBox.TabIndex = 0;
            this.RelationshipHuangUnpubmBox.Text = "Huang unpub (r)";
            this.RelationshipHuangUnpubmBox.UseVisualStyleBackColor = true;
            this.RelationshipHuangUnpubmBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipHardy1999Box
            // 
            this.RelationshipHardy1999Box.AutoSize = true;
            this.RelationshipHardy1999Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipHardy1999Box.Location = new System.Drawing.Point(25, 147);
            this.RelationshipHardy1999Box.Name = "RelationshipHardy1999Box";
            this.RelationshipHardy1999Box.Size = new System.Drawing.Size(126, 24);
            this.RelationshipHardy1999Box.TabIndex = 0;
            this.RelationshipHardy1999Box.Text = "Hardy 1999 (r)";
            this.RelationshipHardy1999Box.UseVisualStyleBackColor = true;
            this.RelationshipHardy1999Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipWeir1996Box
            // 
            this.RelationshipWeir1996Box.AutoSize = true;
            this.RelationshipWeir1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipWeir1996Box.Location = new System.Drawing.Point(187, 147);
            this.RelationshipWeir1996Box.Name = "RelationshipWeir1996Box";
            this.RelationshipWeir1996Box.Size = new System.Drawing.Size(120, 24);
            this.RelationshipWeir1996Box.TabIndex = 0;
            this.RelationshipWeir1996Box.Text = "Weir 1996 (θ)";
            this.RelationshipWeir1996Box.UseVisualStyleBackColor = true;
            this.RelationshipWeir1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipHuang2014Box
            // 
            this.RelationshipHuang2014Box.AutoSize = true;
            this.RelationshipHuang2014Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipHuang2014Box.Location = new System.Drawing.Point(25, 72);
            this.RelationshipHuang2014Box.Name = "RelationshipHuang2014Box";
            this.RelationshipHuang2014Box.Size = new System.Drawing.Size(152, 24);
            this.RelationshipHuang2014Box.TabIndex = 0;
            this.RelationshipHuang2014Box.Text = "Huang 2014 MOM";
            this.RelationshipHuang2014Box.UseVisualStyleBackColor = true;
            this.RelationshipHuang2014Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipRitland1996mBox
            // 
            this.RelationshipRitland1996mBox.AutoSize = true;
            this.RelationshipRitland1996mBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipRitland1996mBox.Location = new System.Drawing.Point(25, 97);
            this.RelationshipRitland1996mBox.Name = "RelationshipRitland1996mBox";
            this.RelationshipRitland1996mBox.Size = new System.Drawing.Size(133, 24);
            this.RelationshipRitland1996mBox.TabIndex = 0;
            this.RelationshipRitland1996mBox.Text = "Ritland 1996 (r)";
            this.RelationshipRitland1996mBox.UseVisualStyleBackColor = true;
            this.RelationshipRitland1996mBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelationshipTotBox
            // 
            this.RelationshipTotBox.AutoSize = true;
            this.RelationshipTotBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RelationshipTotBox.Location = new System.Drawing.Point(265, 25);
            this.RelationshipTotBox.Name = "RelationshipTotBox";
            this.RelationshipTotBox.Size = new System.Drawing.Size(98, 24);
            this.RelationshipTotBox.TabIndex = 0;
            this.RelationshipTotBox.Text = "Total pop.";
            this.RelationshipTotBox.UseVisualStyleBackColor = true;
            this.RelationshipTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GroupBoxInbreeding
            // 
            this.GroupBoxInbreeding.Controls.Add(this.label40);
            this.GroupBoxInbreeding.Controls.Add(this.InbreedingJackknifeBox);
            this.GroupBoxInbreeding.Controls.Add(this.InbreedingLoiselle1995Box);
            this.GroupBoxInbreeding.Controls.Add(this.InbreedingRitland1996Box);
            this.GroupBoxInbreeding.Controls.Add(this.InbreedingHuangUnpubBox);
            this.GroupBoxInbreeding.Controls.Add(this.InbreedingWeir1996Box);
            this.GroupBoxInbreeding.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxInbreeding.Location = new System.Drawing.Point(378, 388);
            this.GroupBoxInbreeding.Name = "GroupBoxInbreeding";
            this.GroupBoxInbreeding.Size = new System.Drawing.Size(370, 122);
            this.GroupBoxInbreeding.TabIndex = 8;
            this.GroupBoxInbreeding.TabStop = false;
            this.GroupBoxInbreeding.Text = "Individual inbreeding coef.";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label40.Location = new System.Drawing.Point(10, 22);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(78, 20);
            this.label40.TabIndex = 408;
            this.label40.Text = "Estimators";
            // 
            // InbreedingJackknifeBox
            // 
            this.InbreedingJackknifeBox.AutoSize = true;
            this.InbreedingJackknifeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InbreedingJackknifeBox.Location = new System.Drawing.Point(17, 92);
            this.InbreedingJackknifeBox.Name = "InbreedingJackknifeBox";
            this.InbreedingJackknifeBox.Size = new System.Drawing.Size(247, 24);
            this.InbreedingJackknifeBox.TabIndex = 407;
            this.InbreedingJackknifeBox.Text = "Estimate SE by Jackknife method";
            this.InbreedingJackknifeBox.UseVisualStyleBackColor = true;
            // 
            // InbreedingLoiselle1995Box
            // 
            this.InbreedingLoiselle1995Box.AutoSize = true;
            this.InbreedingLoiselle1995Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InbreedingLoiselle1995Box.Location = new System.Drawing.Point(178, 42);
            this.InbreedingLoiselle1995Box.Name = "InbreedingLoiselle1995Box";
            this.InbreedingLoiselle1995Box.Size = new System.Drawing.Size(117, 24);
            this.InbreedingLoiselle1995Box.TabIndex = 405;
            this.InbreedingLoiselle1995Box.Text = "Loiselle 1995";
            this.InbreedingLoiselle1995Box.UseVisualStyleBackColor = true;
            this.InbreedingLoiselle1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingRitland1996Box
            // 
            this.InbreedingRitland1996Box.AutoSize = true;
            this.InbreedingRitland1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InbreedingRitland1996Box.Location = new System.Drawing.Point(23, 42);
            this.InbreedingRitland1996Box.Name = "InbreedingRitland1996Box";
            this.InbreedingRitland1996Box.Size = new System.Drawing.Size(114, 24);
            this.InbreedingRitland1996Box.TabIndex = 406;
            this.InbreedingRitland1996Box.Text = "Ritland 1996";
            this.InbreedingRitland1996Box.UseVisualStyleBackColor = true;
            this.InbreedingRitland1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingHuangUnpubBox
            // 
            this.InbreedingHuangUnpubBox.AutoSize = true;
            this.InbreedingHuangUnpubBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InbreedingHuangUnpubBox.Location = new System.Drawing.Point(178, 67);
            this.InbreedingHuangUnpubBox.Name = "InbreedingHuangUnpubBox";
            this.InbreedingHuangUnpubBox.Size = new System.Drawing.Size(121, 24);
            this.InbreedingHuangUnpubBox.TabIndex = 402;
            this.InbreedingHuangUnpubBox.Text = "Huang unpub";
            this.InbreedingHuangUnpubBox.UseVisualStyleBackColor = true;
            this.InbreedingHuangUnpubBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingWeir1996Box
            // 
            this.InbreedingWeir1996Box.AutoSize = true;
            this.InbreedingWeir1996Box.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InbreedingWeir1996Box.Location = new System.Drawing.Point(23, 67);
            this.InbreedingWeir1996Box.Name = "InbreedingWeir1996Box";
            this.InbreedingWeir1996Box.Size = new System.Drawing.Size(97, 24);
            this.InbreedingWeir1996Box.TabIndex = 402;
            this.InbreedingWeir1996Box.Text = "Weir 1996";
            this.InbreedingWeir1996Box.UseVisualStyleBackColor = true;
            this.InbreedingWeir1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiversityPage
            // 
            this.DiversityPage.Controls.Add(this.groupBox6);
            this.DiversityPage.Location = new System.Drawing.Point(4, 54);
            this.DiversityPage.Name = "DiversityPage";
            this.DiversityPage.Size = new System.Drawing.Size(1419, 694);
            this.DiversityPage.TabIndex = 8;
            this.DiversityPage.Text = "Diversity";
            this.DiversityPage.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.DiversityResBox);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1419, 694);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Genetic diversity";
            // 
            // DiversityResBox
            // 
            this.DiversityResBox.AcceptsReturn = true;
            this.DiversityResBox.AcceptsTab = true;
            this.DiversityResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DiversityResBox.HideSelection = false;
            this.DiversityResBox.Location = new System.Drawing.Point(3, 23);
            this.DiversityResBox.MaxLength = 32767000;
            this.DiversityResBox.Multiline = true;
            this.DiversityResBox.Name = "DiversityResBox";
            this.DiversityResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DiversityResBox.Size = new System.Drawing.Size(1413, 668);
            this.DiversityResBox.TabIndex = 1;
            this.DiversityResBox.WordWrap = false;
            this.DiversityResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyPage
            // 
            this.FrequencyPage.Controls.Add(this.groupBox3);
            this.FrequencyPage.Location = new System.Drawing.Point(4, 54);
            this.FrequencyPage.Name = "FrequencyPage";
            this.FrequencyPage.Size = new System.Drawing.Size(1419, 694);
            this.FrequencyPage.TabIndex = 2;
            this.FrequencyPage.Text = "Frequency";
            this.FrequencyPage.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.FrequencyResBox);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1419, 694);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Allele frequencies";
            // 
            // FrequencyResBox
            // 
            this.FrequencyResBox.AcceptsReturn = true;
            this.FrequencyResBox.AcceptsTab = true;
            this.FrequencyResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FrequencyResBox.HideSelection = false;
            this.FrequencyResBox.Location = new System.Drawing.Point(3, 23);
            this.FrequencyResBox.MaxLength = 32767000;
            this.FrequencyResBox.Multiline = true;
            this.FrequencyResBox.Name = "FrequencyResBox";
            this.FrequencyResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.FrequencyResBox.Size = new System.Drawing.Size(1413, 668);
            this.FrequencyResBox.TabIndex = 1;
            this.FrequencyResBox.WordWrap = false;
            this.FrequencyResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistributionPage
            // 
            this.DistributionPage.Controls.Add(this.groupBox5);
            this.DistributionPage.Location = new System.Drawing.Point(4, 54);
            this.DistributionPage.Name = "DistributionPage";
            this.DistributionPage.Size = new System.Drawing.Size(1419, 694);
            this.DistributionPage.TabIndex = 4;
            this.DistributionPage.Text = "Distribution";
            this.DistributionPage.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.DistributionResBox);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1419, 694);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Double-reduction equilibrium test for phenotypic frequency";
            // 
            // DistributionResBox
            // 
            this.DistributionResBox.AcceptsReturn = true;
            this.DistributionResBox.AcceptsTab = true;
            this.DistributionResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DistributionResBox.HideSelection = false;
            this.DistributionResBox.Location = new System.Drawing.Point(3, 23);
            this.DistributionResBox.MaxLength = 32767000;
            this.DistributionResBox.Multiline = true;
            this.DistributionResBox.Name = "DistributionResBox";
            this.DistributionResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DistributionResBox.Size = new System.Drawing.Size(1413, 668);
            this.DistributionResBox.TabIndex = 1;
            this.DistributionResBox.WordWrap = false;
            this.DistributionResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkagePage
            // 
            this.LinkagePage.Controls.Add(this.groupBox19);
            this.LinkagePage.Location = new System.Drawing.Point(4, 54);
            this.LinkagePage.Name = "LinkagePage";
            this.LinkagePage.Size = new System.Drawing.Size(1419, 694);
            this.LinkagePage.TabIndex = 11;
            this.LinkagePage.Text = "Linkage";
            this.LinkagePage.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.LinkageResBox);
            this.groupBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox19.Location = new System.Drawing.Point(0, 0);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(1419, 694);
            this.groupBox19.TabIndex = 2;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Linkage disequilibrium test";
            // 
            // LinkageResBox
            // 
            this.LinkageResBox.AcceptsReturn = true;
            this.LinkageResBox.AcceptsTab = true;
            this.LinkageResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LinkageResBox.HideSelection = false;
            this.LinkageResBox.Location = new System.Drawing.Point(3, 23);
            this.LinkageResBox.MaxLength = 32767000;
            this.LinkageResBox.Multiline = true;
            this.LinkageResBox.Name = "LinkageResBox";
            this.LinkageResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LinkageResBox.Size = new System.Drawing.Size(1413, 668);
            this.LinkageResBox.TabIndex = 1;
            this.LinkageResBox.WordWrap = false;
            this.LinkageResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // NePage
            // 
            this.NePage.Controls.Add(this.groupBox56);
            this.NePage.Location = new System.Drawing.Point(4, 54);
            this.NePage.Name = "NePage";
            this.NePage.Size = new System.Drawing.Size(1419, 694);
            this.NePage.TabIndex = 18;
            this.NePage.Text = "Ne";
            this.NePage.UseVisualStyleBackColor = true;
            // 
            // groupBox56
            // 
            this.groupBox56.Controls.Add(this.NeResBox);
            this.groupBox56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox56.Location = new System.Drawing.Point(0, 0);
            this.groupBox56.Name = "groupBox56";
            this.groupBox56.Size = new System.Drawing.Size(1419, 694);
            this.groupBox56.TabIndex = 3;
            this.groupBox56.TabStop = false;
            this.groupBox56.Text = "Effective population size";
            // 
            // NeResBox
            // 
            this.NeResBox.AcceptsReturn = true;
            this.NeResBox.AcceptsTab = true;
            this.NeResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NeResBox.HideSelection = false;
            this.NeResBox.Location = new System.Drawing.Point(3, 23);
            this.NeResBox.MaxLength = 32767000;
            this.NeResBox.Multiline = true;
            this.NeResBox.Name = "NeResBox";
            this.NeResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.NeResBox.Size = new System.Drawing.Size(1413, 668);
            this.NeResBox.TabIndex = 1;
            this.NeResBox.WordWrap = false;
            // 
            // DiffPage
            // 
            this.DiffPage.Controls.Add(this.groupBox4);
            this.DiffPage.Location = new System.Drawing.Point(4, 54);
            this.DiffPage.Name = "DiffPage";
            this.DiffPage.Size = new System.Drawing.Size(1419, 694);
            this.DiffPage.TabIndex = 3;
            this.DiffPage.Text = "Differentiation";
            this.DiffPage.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.DiffResBox);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1419, 694);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Genetic differantation";
            // 
            // DiffResBox
            // 
            this.DiffResBox.AcceptsReturn = true;
            this.DiffResBox.AcceptsTab = true;
            this.DiffResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DiffResBox.HideSelection = false;
            this.DiffResBox.Location = new System.Drawing.Point(3, 23);
            this.DiffResBox.MaxLength = 32767000;
            this.DiffResBox.Multiline = true;
            this.DiffResBox.Name = "DiffResBox";
            this.DiffResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DiffResBox.Size = new System.Drawing.Size(1413, 668);
            this.DiffResBox.TabIndex = 1;
            this.DiffResBox.WordWrap = false;
            this.DiffResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistPage
            // 
            this.DistPage.Controls.Add(this.groupBox22);
            this.DistPage.Location = new System.Drawing.Point(4, 54);
            this.DistPage.Name = "DistPage";
            this.DistPage.Size = new System.Drawing.Size(1419, 694);
            this.DistPage.TabIndex = 12;
            this.DistPage.Text = "Distance";
            this.DistPage.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.DistResBox);
            this.groupBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox22.Location = new System.Drawing.Point(0, 0);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(1419, 694);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Genetic distance";
            // 
            // DistResBox
            // 
            this.DistResBox.AcceptsReturn = true;
            this.DistResBox.AcceptsTab = true;
            this.DistResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DistResBox.HideSelection = false;
            this.DistResBox.Location = new System.Drawing.Point(3, 23);
            this.DistResBox.MaxLength = 32767000;
            this.DistResBox.Multiline = true;
            this.DistResBox.Name = "DistResBox";
            this.DistResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DistResBox.Size = new System.Drawing.Size(1413, 668);
            this.DistResBox.TabIndex = 1;
            this.DistResBox.WordWrap = false;
            this.DistResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // OrdinationPage
            // 
            this.OrdinationPage.Controls.Add(this.splitContainer15);
            this.OrdinationPage.Location = new System.Drawing.Point(4, 54);
            this.OrdinationPage.Name = "OrdinationPage";
            this.OrdinationPage.Size = new System.Drawing.Size(1419, 694);
            this.OrdinationPage.TabIndex = 16;
            this.OrdinationPage.Text = "Ordination";
            this.OrdinationPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer15
            // 
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.Location = new System.Drawing.Point(0, 0);
            this.splitContainer15.Name = "splitContainer15";
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.groupBox52);
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.groupBox47);
            this.splitContainer15.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer15.SplitterDistance = 1068;
            this.splitContainer15.SplitterWidth = 5;
            this.splitContainer15.TabIndex = 5;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.PCoAPanel);
            this.groupBox52.Controls.Add(this.OrdinationToolStrip);
            this.groupBox52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox52.Location = new System.Drawing.Point(0, 0);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(1068, 694);
            this.groupBox52.TabIndex = 7;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Scatter plot preview";
            // 
            // PCoAPanel
            // 
            this.PCoAPanel.Controls.Add(this.OrdinationPicBox);
            this.PCoAPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PCoAPanel.Location = new System.Drawing.Point(3, 51);
            this.PCoAPanel.Name = "PCoAPanel";
            this.PCoAPanel.Size = new System.Drawing.Size(1062, 640);
            this.PCoAPanel.TabIndex = 1;
            // 
            // OrdinationPicBox
            // 
            this.OrdinationPicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OrdinationPicBox.Location = new System.Drawing.Point(0, 0);
            this.OrdinationPicBox.Name = "OrdinationPicBox";
            this.OrdinationPicBox.Size = new System.Drawing.Size(1062, 640);
            this.OrdinationPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.OrdinationPicBox.TabIndex = 2;
            this.OrdinationPicBox.TabStop = false;
            this.OrdinationPicBox.SizeChanged += new System.EventHandler(this.OrdinationComboBox_SelectedIndexChanged);
            // 
            // OrdinationToolStrip
            // 
            this.OrdinationToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.OrdinationToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OrdinationComboBox,
            this.toolStripSeparator6,
            this.OrdinationPreviousButton,
            this.OrdinationNextButton,
            this.SaveOrdinationButton,
            this.toolStripSeparator8,
            this.toolStripLabel1,
            this.OrdinationFontSizeBox,
            this.toolStripLabel2,
            this.OrdinationStyleBox,
            this.toolStripLabel8,
            this.OrdinationMarkerSizeBox,
            this.toolStripLabel3,
            this.OrdinationMarkerBox,
            this.toolStripLabel5,
            this.OrdinationAxesBox});
            this.OrdinationToolStrip.Location = new System.Drawing.Point(3, 23);
            this.OrdinationToolStrip.Name = "OrdinationToolStrip";
            this.OrdinationToolStrip.Size = new System.Drawing.Size(1062, 28);
            this.OrdinationToolStrip.TabIndex = 0;
            this.OrdinationToolStrip.Text = "toolStrip3";
            // 
            // OrdinationComboBox
            // 
            this.OrdinationComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrdinationComboBox.DropDownWidth = 500;
            this.OrdinationComboBox.Name = "OrdinationComboBox";
            this.OrdinationComboBox.Size = new System.Drawing.Size(300, 28);
            this.OrdinationComboBox.SelectedIndexChanged += new System.EventHandler(this.OrdinationComboBox_SelectedIndexChanged);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 28);
            // 
            // OrdinationPreviousButton
            // 
            this.OrdinationPreviousButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.OrdinationPreviousButton.Image = ((System.Drawing.Image)(resources.GetObject("OrdinationPreviousButton.Image")));
            this.OrdinationPreviousButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrdinationPreviousButton.Name = "OrdinationPreviousButton";
            this.OrdinationPreviousButton.Size = new System.Drawing.Size(75, 25);
            this.OrdinationPreviousButton.Text = "&Previous";
            this.OrdinationPreviousButton.Click += new System.EventHandler(this.ScrollPic);
            // 
            // OrdinationNextButton
            // 
            this.OrdinationNextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.OrdinationNextButton.Image = ((System.Drawing.Image)(resources.GetObject("OrdinationNextButton.Image")));
            this.OrdinationNextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrdinationNextButton.Name = "OrdinationNextButton";
            this.OrdinationNextButton.Size = new System.Drawing.Size(48, 25);
            this.OrdinationNextButton.Text = "&Next";
            this.OrdinationNextButton.Click += new System.EventHandler(this.ScrollPic);
            // 
            // SaveOrdinationButton
            // 
            this.SaveOrdinationButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SaveOrdinationButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveOrdinationButton.Image")));
            this.SaveOrdinationButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveOrdinationButton.Name = "SaveOrdinationButton";
            this.SaveOrdinationButton.Size = new System.Drawing.Size(47, 25);
            this.SaveOrdinationButton.Text = "&Save";
            this.SaveOrdinationButton.Click += new System.EventHandler(this.SavePic);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(71, 25);
            this.toolStripLabel1.Text = "FontSize";
            // 
            // OrdinationFontSizeBox
            // 
            this.OrdinationFontSizeBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.OrdinationFontSizeBox.Name = "OrdinationFontSizeBox";
            this.OrdinationFontSizeBox.Size = new System.Drawing.Size(32, 28);
            this.OrdinationFontSizeBox.Text = "12";
            this.OrdinationFontSizeBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToolStripKeyDown);
            this.OrdinationFontSizeBox.TextChanged += new System.EventHandler(this.OrdinationFontSizeBox_TextChanged);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(45, 25);
            this.toolStripLabel2.Text = "Style";
            // 
            // OrdinationStyleBox
            // 
            this.OrdinationStyleBox.Items.AddRange(new object[] {
            "Marker",
            "#",
            "ID",
            "Marker + #",
            "Marker + ID"});
            this.OrdinationStyleBox.Name = "OrdinationStyleBox";
            this.OrdinationStyleBox.Size = new System.Drawing.Size(112, 28);
            this.OrdinationStyleBox.TextChanged += new System.EventHandler(this.OrdinationStyleBox_SelectedIndexChanged);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(90, 25);
            this.toolStripLabel8.Text = "MarkerSize";
            // 
            // OrdinationMarkerSizeBox
            // 
            this.OrdinationMarkerSizeBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.OrdinationMarkerSizeBox.Name = "OrdinationMarkerSizeBox";
            this.OrdinationMarkerSizeBox.Size = new System.Drawing.Size(12, 28);
            this.OrdinationMarkerSizeBox.Text = "10";
            this.OrdinationMarkerSizeBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToolStripKeyDown);
            this.OrdinationMarkerSizeBox.TextChanged += new System.EventHandler(this.OrdinationMarkerSizeBox_TextChanged);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(61, 25);
            this.toolStripLabel3.Text = "Marker";
            // 
            // OrdinationMarkerBox
            // 
            this.OrdinationMarkerBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.OrdinationMarkerBox.Name = "OrdinationMarkerBox";
            this.OrdinationMarkerBox.Size = new System.Drawing.Size(15, 28);
            this.OrdinationMarkerBox.Text = "+✕○●△▲□■⬠⬟⬡⬢";
            this.OrdinationMarkerBox.TextChanged += new System.EventHandler(this.OrdinationMarkerBox_TextChanged);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(44, 25);
            this.toolStripLabel5.Text = "Axes";
            // 
            // OrdinationAxesBox
            // 
            this.OrdinationAxesBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.OrdinationAxesBox.Name = "OrdinationAxesBox";
            this.OrdinationAxesBox.Size = new System.Drawing.Size(36, 28);
            this.OrdinationAxesBox.Text = "1,2";
            this.OrdinationAxesBox.TextChanged += new System.EventHandler(this.OrdinationAxesBox_TextChanged);
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.OrdinationResBox);
            this.groupBox47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox47.Location = new System.Drawing.Point(0, 0);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(346, 694);
            this.groupBox47.TabIndex = 4;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "Ordination result details";
            // 
            // OrdinationResBox
            // 
            this.OrdinationResBox.AcceptsReturn = true;
            this.OrdinationResBox.AcceptsTab = true;
            this.OrdinationResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OrdinationResBox.HideSelection = false;
            this.OrdinationResBox.Location = new System.Drawing.Point(3, 23);
            this.OrdinationResBox.MaxLength = 32767000;
            this.OrdinationResBox.Multiline = true;
            this.OrdinationResBox.Name = "OrdinationResBox";
            this.OrdinationResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.OrdinationResBox.Size = new System.Drawing.Size(340, 668);
            this.OrdinationResBox.TabIndex = 1;
            this.OrdinationResBox.WordWrap = false;
            this.OrdinationResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringPage
            // 
            this.ClusteringPage.Controls.Add(this.splitContainer16);
            this.ClusteringPage.Location = new System.Drawing.Point(4, 54);
            this.ClusteringPage.Name = "ClusteringPage";
            this.ClusteringPage.Size = new System.Drawing.Size(1419, 694);
            this.ClusteringPage.TabIndex = 17;
            this.ClusteringPage.Text = "Clustering";
            this.ClusteringPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer16
            // 
            this.splitContainer16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer16.Location = new System.Drawing.Point(0, 0);
            this.splitContainer16.Name = "splitContainer16";
            // 
            // splitContainer16.Panel1
            // 
            this.splitContainer16.Panel1.Controls.Add(this.groupBox51);
            // 
            // splitContainer16.Panel2
            // 
            this.splitContainer16.Panel2.Controls.Add(this.groupBox49);
            this.splitContainer16.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer16.SplitterDistance = 650;
            this.splitContainer16.SplitterWidth = 5;
            this.splitContainer16.TabIndex = 6;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.ClusteringPanel);
            this.groupBox51.Controls.Add(this.ClusteringToolStrip);
            this.groupBox51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox51.Location = new System.Drawing.Point(0, 0);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(650, 694);
            this.groupBox51.TabIndex = 6;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Tree preview";
            // 
            // ClusteringPanel
            // 
            this.ClusteringPanel.AutoScroll = true;
            this.ClusteringPanel.AutoSize = true;
            this.ClusteringPanel.Controls.Add(this.ClusteringPicBox);
            this.ClusteringPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ClusteringPanel.Location = new System.Drawing.Point(3, 52);
            this.ClusteringPanel.Name = "ClusteringPanel";
            this.ClusteringPanel.Size = new System.Drawing.Size(644, 639);
            this.ClusteringPanel.TabIndex = 1;
            // 
            // ClusteringPicBox
            // 
            this.ClusteringPicBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.ClusteringPicBox.Location = new System.Drawing.Point(0, 0);
            this.ClusteringPicBox.Name = "ClusteringPicBox";
            this.ClusteringPicBox.Size = new System.Drawing.Size(644, 617);
            this.ClusteringPicBox.TabIndex = 3;
            this.ClusteringPicBox.TabStop = false;
            this.ClusteringPicBox.SizeChanged += new System.EventHandler(this.ClusteringComboBox_SelectedIndexChanged);
            // 
            // ClusteringToolStrip
            // 
            this.ClusteringToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.ClusteringToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClusteringComboBox,
            this.toolStripSeparator5,
            this.ClusteringPreviousButton,
            this.ClusteringNextButton,
            this.SaveClusteringButton,
            this.toolStripSeparator11,
            this.toolStripLabel15,
            this.ClusteringFontSizeBox,
            this.toolStripLabel14,
            this.ClusteringLineSepBox});
            this.ClusteringToolStrip.Location = new System.Drawing.Point(3, 23);
            this.ClusteringToolStrip.Name = "ClusteringToolStrip";
            this.ClusteringToolStrip.Size = new System.Drawing.Size(644, 29);
            this.ClusteringToolStrip.TabIndex = 0;
            this.ClusteringToolStrip.Text = "toolStrip2";
            // 
            // ClusteringComboBox
            // 
            this.ClusteringComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ClusteringComboBox.Name = "ClusteringComboBox";
            this.ClusteringComboBox.Size = new System.Drawing.Size(324, 29);
            this.ClusteringComboBox.SelectedIndexChanged += new System.EventHandler(this.ClusteringComboBox_SelectedIndexChanged);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 29);
            // 
            // ClusteringPreviousButton
            // 
            this.ClusteringPreviousButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClusteringPreviousButton.Image = ((System.Drawing.Image)(resources.GetObject("ClusteringPreviousButton.Image")));
            this.ClusteringPreviousButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClusteringPreviousButton.Name = "ClusteringPreviousButton";
            this.ClusteringPreviousButton.Size = new System.Drawing.Size(75, 26);
            this.ClusteringPreviousButton.Text = "&Previous";
            this.ClusteringPreviousButton.Click += new System.EventHandler(this.ScrollPic);
            // 
            // ClusteringNextButton
            // 
            this.ClusteringNextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClusteringNextButton.Image = ((System.Drawing.Image)(resources.GetObject("ClusteringNextButton.Image")));
            this.ClusteringNextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClusteringNextButton.Name = "ClusteringNextButton";
            this.ClusteringNextButton.Size = new System.Drawing.Size(48, 26);
            this.ClusteringNextButton.Text = "&Next";
            this.ClusteringNextButton.Click += new System.EventHandler(this.ScrollPic);
            // 
            // SaveClusteringButton
            // 
            this.SaveClusteringButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SaveClusteringButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveClusteringButton.Image")));
            this.SaveClusteringButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveClusteringButton.Name = "SaveClusteringButton";
            this.SaveClusteringButton.Size = new System.Drawing.Size(47, 26);
            this.SaveClusteringButton.Text = "&Save";
            this.SaveClusteringButton.Click += new System.EventHandler(this.SavePic);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 29);
            // 
            // toolStripLabel15
            // 
            this.toolStripLabel15.Name = "toolStripLabel15";
            this.toolStripLabel15.Size = new System.Drawing.Size(71, 26);
            this.toolStripLabel15.Text = "FontSize";
            // 
            // ClusteringFontSizeBox
            // 
            this.ClusteringFontSizeBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.ClusteringFontSizeBox.Name = "ClusteringFontSizeBox";
            this.ClusteringFontSizeBox.Size = new System.Drawing.Size(6, 29);
            this.ClusteringFontSizeBox.Text = "12";
            this.ClusteringFontSizeBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToolStripKeyDown);
            this.ClusteringFontSizeBox.TextChanged += new System.EventHandler(this.ClusteringFontSizeBox_TextChanged);
            // 
            // toolStripLabel14
            // 
            this.toolStripLabel14.Name = "toolStripLabel14";
            this.toolStripLabel14.Size = new System.Drawing.Size(70, 20);
            this.toolStripLabel14.Text = "LineSkip";
            // 
            // ClusteringLineSepBox
            // 
            this.ClusteringLineSepBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.ClusteringLineSepBox.Name = "ClusteringLineSepBox";
            this.ClusteringLineSepBox.Size = new System.Drawing.Size(6, 27);
            this.ClusteringLineSepBox.Text = "12";
            this.ClusteringLineSepBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToolStripKeyDown);
            this.ClusteringLineSepBox.TextChanged += new System.EventHandler(this.ClusteringLineSepBox_TextChanged);
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.ClusteringResBox);
            this.groupBox49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox49.Location = new System.Drawing.Point(0, 0);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(764, 694);
            this.groupBox49.TabIndex = 5;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Hierarchical clustering";
            // 
            // ClusteringResBox
            // 
            this.ClusteringResBox.AcceptsReturn = true;
            this.ClusteringResBox.AcceptsTab = true;
            this.ClusteringResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ClusteringResBox.HideSelection = false;
            this.ClusteringResBox.Location = new System.Drawing.Point(3, 23);
            this.ClusteringResBox.MaxLength = 32767000;
            this.ClusteringResBox.Multiline = true;
            this.ClusteringResBox.Name = "ClusteringResBox";
            this.ClusteringResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ClusteringResBox.Size = new System.Drawing.Size(758, 668);
            this.ClusteringResBox.TabIndex = 1;
            this.ClusteringResBox.WordWrap = false;
            this.ClusteringResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingPage
            // 
            this.InbreedingPage.Controls.Add(this.groupBox2);
            this.InbreedingPage.Location = new System.Drawing.Point(4, 54);
            this.InbreedingPage.Name = "InbreedingPage";
            this.InbreedingPage.Size = new System.Drawing.Size(1419, 694);
            this.InbreedingPage.TabIndex = 5;
            this.InbreedingPage.Text = "Inbreeding";
            this.InbreedingPage.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.InbreedingResBox);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1419, 694);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Individual inbreeding coefficient";
            // 
            // InbreedingResBox
            // 
            this.InbreedingResBox.AcceptsReturn = true;
            this.InbreedingResBox.AcceptsTab = true;
            this.InbreedingResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InbreedingResBox.HideSelection = false;
            this.InbreedingResBox.Location = new System.Drawing.Point(3, 23);
            this.InbreedingResBox.MaxLength = 32767000;
            this.InbreedingResBox.Multiline = true;
            this.InbreedingResBox.Name = "InbreedingResBox";
            this.InbreedingResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InbreedingResBox.Size = new System.Drawing.Size(1413, 668);
            this.InbreedingResBox.TabIndex = 1;
            this.InbreedingResBox.WordWrap = false;
            this.InbreedingResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // HIndexPage
            // 
            this.HIndexPage.Controls.Add(this.groupBox11);
            this.HIndexPage.Location = new System.Drawing.Point(4, 54);
            this.HIndexPage.Name = "HIndexPage";
            this.HIndexPage.Size = new System.Drawing.Size(1419, 694);
            this.HIndexPage.TabIndex = 7;
            this.HIndexPage.Text = "H-Index";
            this.HIndexPage.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.HIndexResBox);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(0, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1419, 694);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Individual hetrozygosity";
            // 
            // HIndexResBox
            // 
            this.HIndexResBox.AcceptsReturn = true;
            this.HIndexResBox.AcceptsTab = true;
            this.HIndexResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HIndexResBox.HideSelection = false;
            this.HIndexResBox.Location = new System.Drawing.Point(3, 23);
            this.HIndexResBox.MaxLength = 32767000;
            this.HIndexResBox.Multiline = true;
            this.HIndexResBox.Name = "HIndexResBox";
            this.HIndexResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.HIndexResBox.Size = new System.Drawing.Size(1413, 668);
            this.HIndexResBox.TabIndex = 1;
            this.HIndexResBox.WordWrap = false;
            this.HIndexResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AssignmentPage
            // 
            this.AssignmentPage.Controls.Add(this.groupBox12);
            this.AssignmentPage.Location = new System.Drawing.Point(4, 54);
            this.AssignmentPage.Name = "AssignmentPage";
            this.AssignmentPage.Size = new System.Drawing.Size(1419, 694);
            this.AssignmentPage.TabIndex = 9;
            this.AssignmentPage.Text = "Assignment";
            this.AssignmentPage.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.AssignmentResBox);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(0, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1419, 694);
            this.groupBox12.TabIndex = 6;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Population assignment";
            // 
            // AssignmentResBox
            // 
            this.AssignmentResBox.AcceptsReturn = true;
            this.AssignmentResBox.AcceptsTab = true;
            this.AssignmentResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AssignmentResBox.HideSelection = false;
            this.AssignmentResBox.Location = new System.Drawing.Point(3, 23);
            this.AssignmentResBox.MaxLength = 32767000;
            this.AssignmentResBox.Multiline = true;
            this.AssignmentResBox.Name = "AssignmentResBox";
            this.AssignmentResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AssignmentResBox.Size = new System.Drawing.Size(1413, 668);
            this.AssignmentResBox.TabIndex = 1;
            this.AssignmentResBox.WordWrap = false;
            this.AssignmentResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SpatialPage
            // 
            this.SpatialPage.Controls.Add(this.groupBox59);
            this.SpatialPage.Location = new System.Drawing.Point(4, 54);
            this.SpatialPage.Name = "SpatialPage";
            this.SpatialPage.Size = new System.Drawing.Size(1419, 694);
            this.SpatialPage.TabIndex = 19;
            this.SpatialPage.Text = "Spatial";
            this.SpatialPage.UseVisualStyleBackColor = true;
            // 
            // groupBox59
            // 
            this.groupBox59.Controls.Add(this.SpatialResBox);
            this.groupBox59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox59.Location = new System.Drawing.Point(0, 0);
            this.groupBox59.Name = "groupBox59";
            this.groupBox59.Size = new System.Drawing.Size(1419, 694);
            this.groupBox59.TabIndex = 8;
            this.groupBox59.TabStop = false;
            this.groupBox59.Text = "Spatial pattern analysis";
            // 
            // SpatialResBox
            // 
            this.SpatialResBox.AcceptsReturn = true;
            this.SpatialResBox.AcceptsTab = true;
            this.SpatialResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpatialResBox.HideSelection = false;
            this.SpatialResBox.Location = new System.Drawing.Point(3, 23);
            this.SpatialResBox.MaxLength = 32767000;
            this.SpatialResBox.Multiline = true;
            this.SpatialResBox.Name = "SpatialResBox";
            this.SpatialResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SpatialResBox.Size = new System.Drawing.Size(1413, 668);
            this.SpatialResBox.TabIndex = 1;
            this.SpatialResBox.WordWrap = false;
            // 
            // RelationshipPage
            // 
            this.RelationshipPage.Controls.Add(this.groupBox17);
            this.RelationshipPage.Location = new System.Drawing.Point(4, 54);
            this.RelationshipPage.Name = "RelationshipPage";
            this.RelationshipPage.Size = new System.Drawing.Size(1419, 694);
            this.RelationshipPage.TabIndex = 10;
            this.RelationshipPage.Text = "Relationship";
            this.RelationshipPage.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.RelationshipResBox);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox17.Location = new System.Drawing.Point(0, 0);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1419, 694);
            this.groupBox17.TabIndex = 7;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Pairwise relatedness/kinship coefficient";
            // 
            // RelationshipResBox
            // 
            this.RelationshipResBox.AcceptsReturn = true;
            this.RelationshipResBox.AcceptsTab = true;
            this.RelationshipResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RelationshipResBox.HideSelection = false;
            this.RelationshipResBox.Location = new System.Drawing.Point(3, 23);
            this.RelationshipResBox.MaxLength = 32767000;
            this.RelationshipResBox.Multiline = true;
            this.RelationshipResBox.Name = "RelationshipResBox";
            this.RelationshipResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.RelationshipResBox.Size = new System.Drawing.Size(1413, 668);
            this.RelationshipResBox.TabIndex = 1;
            this.RelationshipResBox.WordWrap = false;
            this.RelationshipResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // HeritabilityPage
            // 
            this.HeritabilityPage.Controls.Add(this.groupBox60);
            this.HeritabilityPage.Location = new System.Drawing.Point(4, 54);
            this.HeritabilityPage.Margin = new System.Windows.Forms.Padding(2);
            this.HeritabilityPage.Name = "HeritabilityPage";
            this.HeritabilityPage.Size = new System.Drawing.Size(1419, 694);
            this.HeritabilityPage.TabIndex = 20;
            this.HeritabilityPage.Text = "Heritability";
            this.HeritabilityPage.UseVisualStyleBackColor = true;
            // 
            // groupBox60
            // 
            this.groupBox60.Controls.Add(this.HeritabilityResBox);
            this.groupBox60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox60.Location = new System.Drawing.Point(0, 0);
            this.groupBox60.Name = "groupBox60";
            this.groupBox60.Size = new System.Drawing.Size(1419, 694);
            this.groupBox60.TabIndex = 8;
            this.groupBox60.TabStop = false;
            this.groupBox60.Text = "Heritability";
            // 
            // HeritabilityResBox
            // 
            this.HeritabilityResBox.AcceptsReturn = true;
            this.HeritabilityResBox.AcceptsTab = true;
            this.HeritabilityResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HeritabilityResBox.HideSelection = false;
            this.HeritabilityResBox.Location = new System.Drawing.Point(3, 23);
            this.HeritabilityResBox.MaxLength = 32767000;
            this.HeritabilityResBox.Multiline = true;
            this.HeritabilityResBox.Name = "HeritabilityResBox";
            this.HeritabilityResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.HeritabilityResBox.Size = new System.Drawing.Size(1413, 668);
            this.HeritabilityResBox.TabIndex = 1;
            this.HeritabilityResBox.WordWrap = false;
            // 
            // QstPage
            // 
            this.QstPage.Controls.Add(this.groupBox18);
            this.QstPage.Location = new System.Drawing.Point(4, 54);
            this.QstPage.Margin = new System.Windows.Forms.Padding(2);
            this.QstPage.Name = "QstPage";
            this.QstPage.Padding = new System.Windows.Forms.Padding(2);
            this.QstPage.Size = new System.Drawing.Size(1419, 694);
            this.QstPage.TabIndex = 22;
            this.QstPage.Text = "Qst";
            this.QstPage.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.QstResBox);
            this.groupBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox18.Location = new System.Drawing.Point(2, 2);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(1415, 690);
            this.groupBox18.TabIndex = 9;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Qst";
            // 
            // QstResBox
            // 
            this.QstResBox.AcceptsReturn = true;
            this.QstResBox.AcceptsTab = true;
            this.QstResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QstResBox.HideSelection = false;
            this.QstResBox.Location = new System.Drawing.Point(3, 23);
            this.QstResBox.MaxLength = 32767000;
            this.QstResBox.Multiline = true;
            this.QstResBox.Name = "QstResBox";
            this.QstResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.QstResBox.Size = new System.Drawing.Size(1409, 664);
            this.QstResBox.TabIndex = 1;
            this.QstResBox.WordWrap = false;
            // 
            // ParentagePage
            // 
            this.ParentagePage.Controls.Add(this.tabControl2);
            this.ParentagePage.Location = new System.Drawing.Point(4, 54);
            this.ParentagePage.Name = "ParentagePage";
            this.ParentagePage.Size = new System.Drawing.Size(1419, 694);
            this.ParentagePage.TabIndex = 15;
            this.ParentagePage.Text = "Parentage";
            this.ParentagePage.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage20);
            this.tabControl2.Controls.Add(this.tabPage17);
            this.tabControl2.Controls.Add(this.tabPage18);
            this.tabControl2.Controls.Add(this.tabPage19);
            this.tabControl2.Controls.Add(this.tabPage23);
            this.tabControl2.Controls.Add(this.tabPage24);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1419, 694);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.splitContainer12);
            this.tabPage20.Location = new System.Drawing.Point(4, 29);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(1411, 661);
            this.tabPage20.TabIndex = 3;
            this.tabPage20.Text = "Simulation";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // splitContainer12
            // 
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer12.Location = new System.Drawing.Point(0, 0);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.groupBox45);
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.groupBox46);
            this.splitContainer12.Size = new System.Drawing.Size(1411, 661);
            this.splitContainer12.SplitterDistance = 365;
            this.splitContainer12.SplitterWidth = 5;
            this.splitContainer12.TabIndex = 1;
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.DPU_80);
            this.groupBox45.Controls.Add(this.DP_80);
            this.groupBox45.Controls.Add(this.DPF_80);
            this.groupBox45.Controls.Add(this.DPF_95);
            this.groupBox45.Controls.Add(this.DP_95);
            this.groupBox45.Controls.Add(this.DPU_95);
            this.groupBox45.Controls.Add(this.DPF_99);
            this.groupBox45.Controls.Add(this.DP_99);
            this.groupBox45.Controls.Add(this.DPU_99);
            this.groupBox45.Controls.Add(this.DPF_999);
            this.groupBox45.Controls.Add(this.DPU_999);
            this.groupBox45.Controls.Add(this.DP_999);
            this.groupBox45.Controls.Add(this.D2_80);
            this.groupBox45.Controls.Add(this.DPM_80);
            this.groupBox45.Controls.Add(this.D1_80);
            this.groupBox45.Controls.Add(this.D2_95);
            this.groupBox45.Controls.Add(this.D1_95);
            this.groupBox45.Controls.Add(this.DPM_95);
            this.groupBox45.Controls.Add(this.D2_99);
            this.groupBox45.Controls.Add(this.D1_99);
            this.groupBox45.Controls.Add(this.DPM_99);
            this.groupBox45.Controls.Add(this.D2_999);
            this.groupBox45.Controls.Add(this.D1_999);
            this.groupBox45.Controls.Add(this.DPM_999);
            this.groupBox45.Controls.Add(this.label53);
            this.groupBox45.Controls.Add(this.label54);
            this.groupBox45.Controls.Add(this.label55);
            this.groupBox45.Controls.Add(this.label56);
            this.groupBox45.Controls.Add(this.label57);
            this.groupBox45.Controls.Add(this.label59);
            this.groupBox45.Controls.Add(this.label60);
            this.groupBox45.Controls.Add(this.label61);
            this.groupBox45.Controls.Add(this.label62);
            this.groupBox45.Controls.Add(this.label63);
            this.groupBox45.Controls.Add(this.label64);
            this.groupBox45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox45.Location = new System.Drawing.Point(0, 0);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(365, 661);
            this.groupBox45.TabIndex = 1;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Critical values of Delta";
            // 
            // DPU_80
            // 
            this.DPU_80.DecimalPlaces = 5;
            this.DPU_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPU_80.Location = new System.Drawing.Point(327, 410);
            this.DPU_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPU_80.Name = "DPU_80";
            this.DPU_80.Size = new System.Drawing.Size(77, 27);
            this.DPU_80.TabIndex = 9;
            this.DPU_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_80
            // 
            this.DP_80.DecimalPlaces = 5;
            this.DP_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_80.Location = new System.Drawing.Point(327, 343);
            this.DP_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_80.Name = "DP_80";
            this.DP_80.Size = new System.Drawing.Size(77, 27);
            this.DP_80.TabIndex = 11;
            this.DP_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPF_80
            // 
            this.DPF_80.DecimalPlaces = 5;
            this.DPF_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_80.Location = new System.Drawing.Point(327, 278);
            this.DPF_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_80.Name = "DPF_80";
            this.DPF_80.Size = new System.Drawing.Size(77, 27);
            this.DPF_80.TabIndex = 22;
            this.DPF_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPF_95
            // 
            this.DPF_95.DecimalPlaces = 5;
            this.DPF_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_95.Location = new System.Drawing.Point(228, 278);
            this.DPF_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_95.Name = "DPF_95";
            this.DPF_95.Size = new System.Drawing.Size(77, 27);
            this.DPF_95.TabIndex = 2;
            this.DPF_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_95
            // 
            this.DP_95.DecimalPlaces = 5;
            this.DP_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_95.Location = new System.Drawing.Point(228, 343);
            this.DP_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_95.Name = "DP_95";
            this.DP_95.Size = new System.Drawing.Size(77, 27);
            this.DP_95.TabIndex = 13;
            this.DP_95.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPU_95
            // 
            this.DPU_95.DecimalPlaces = 5;
            this.DPU_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPU_95.Location = new System.Drawing.Point(228, 410);
            this.DPU_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPU_95.Name = "DPU_95";
            this.DPU_95.Size = new System.Drawing.Size(77, 27);
            this.DPU_95.TabIndex = 5;
            this.DPU_95.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPU_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPF_99
            // 
            this.DPF_99.DecimalPlaces = 5;
            this.DPF_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_99.Location = new System.Drawing.Point(125, 278);
            this.DPF_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_99.Name = "DPF_99";
            this.DPF_99.Size = new System.Drawing.Size(77, 27);
            this.DPF_99.TabIndex = 12;
            this.DPF_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_99
            // 
            this.DP_99.DecimalPlaces = 5;
            this.DP_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_99.Location = new System.Drawing.Point(125, 343);
            this.DP_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_99.Name = "DP_99";
            this.DP_99.Size = new System.Drawing.Size(77, 27);
            this.DP_99.TabIndex = 3;
            this.DP_99.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPU_99
            // 
            this.DPU_99.DecimalPlaces = 5;
            this.DPU_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPU_99.Location = new System.Drawing.Point(125, 410);
            this.DPU_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPU_99.Name = "DPU_99";
            this.DPU_99.Size = new System.Drawing.Size(77, 27);
            this.DPU_99.TabIndex = 15;
            this.DPU_99.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPU_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPF_999
            // 
            this.DPF_999.DecimalPlaces = 5;
            this.DPF_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_999.Location = new System.Drawing.Point(23, 278);
            this.DPF_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_999.Name = "DPF_999";
            this.DPF_999.Size = new System.Drawing.Size(77, 27);
            this.DPF_999.TabIndex = 10;
            this.DPF_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPU_999
            // 
            this.DPU_999.DecimalPlaces = 5;
            this.DPU_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPU_999.Location = new System.Drawing.Point(23, 410);
            this.DPU_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPU_999.Name = "DPU_999";
            this.DPU_999.Size = new System.Drawing.Size(77, 27);
            this.DPU_999.TabIndex = 7;
            this.DPU_999.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPU_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_999
            // 
            this.DP_999.DecimalPlaces = 5;
            this.DP_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_999.Location = new System.Drawing.Point(23, 343);
            this.DP_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_999.Name = "DP_999";
            this.DP_999.Size = new System.Drawing.Size(77, 27);
            this.DP_999.TabIndex = 23;
            this.DP_999.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D2_80
            // 
            this.D2_80.DecimalPlaces = 5;
            this.D2_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_80.Location = new System.Drawing.Point(327, 147);
            this.D2_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_80.Name = "D2_80";
            this.D2_80.Size = new System.Drawing.Size(77, 27);
            this.D2_80.TabIndex = 20;
            this.D2_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_80
            // 
            this.DPM_80.DecimalPlaces = 5;
            this.DPM_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_80.Location = new System.Drawing.Point(328, 213);
            this.DPM_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_80.Name = "DPM_80";
            this.DPM_80.Size = new System.Drawing.Size(77, 27);
            this.DPM_80.TabIndex = 24;
            this.DPM_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D1_80
            // 
            this.D1_80.DecimalPlaces = 5;
            this.D1_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_80.Location = new System.Drawing.Point(327, 80);
            this.D1_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_80.Name = "D1_80";
            this.D1_80.Size = new System.Drawing.Size(77, 27);
            this.D1_80.TabIndex = 18;
            this.D1_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D2_95
            // 
            this.D2_95.DecimalPlaces = 5;
            this.D2_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_95.Location = new System.Drawing.Point(228, 147);
            this.D2_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_95.Name = "D2_95";
            this.D2_95.Size = new System.Drawing.Size(77, 27);
            this.D2_95.TabIndex = 19;
            this.D2_95.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D1_95
            // 
            this.D1_95.DecimalPlaces = 5;
            this.D1_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_95.Location = new System.Drawing.Point(228, 80);
            this.D1_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_95.Name = "D1_95";
            this.D1_95.Size = new System.Drawing.Size(77, 27);
            this.D1_95.TabIndex = 25;
            this.D1_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_95
            // 
            this.DPM_95.DecimalPlaces = 5;
            this.DPM_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_95.Location = new System.Drawing.Point(228, 213);
            this.DPM_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_95.Name = "DPM_95";
            this.DPM_95.Size = new System.Drawing.Size(77, 27);
            this.DPM_95.TabIndex = 14;
            this.DPM_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D2_99
            // 
            this.D2_99.DecimalPlaces = 5;
            this.D2_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_99.Location = new System.Drawing.Point(125, 147);
            this.D2_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_99.Name = "D2_99";
            this.D2_99.Size = new System.Drawing.Size(77, 27);
            this.D2_99.TabIndex = 17;
            this.D2_99.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D1_99
            // 
            this.D1_99.DecimalPlaces = 5;
            this.D1_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_99.Location = new System.Drawing.Point(125, 80);
            this.D1_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_99.Name = "D1_99";
            this.D1_99.Size = new System.Drawing.Size(77, 27);
            this.D1_99.TabIndex = 21;
            this.D1_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_99
            // 
            this.DPM_99.DecimalPlaces = 5;
            this.DPM_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_99.Location = new System.Drawing.Point(127, 213);
            this.DPM_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_99.Name = "DPM_99";
            this.DPM_99.Size = new System.Drawing.Size(77, 27);
            this.DPM_99.TabIndex = 4;
            this.DPM_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D2_999
            // 
            this.D2_999.DecimalPlaces = 5;
            this.D2_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_999.Location = new System.Drawing.Point(23, 147);
            this.D2_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_999.Name = "D2_999";
            this.D2_999.Size = new System.Drawing.Size(77, 27);
            this.D2_999.TabIndex = 16;
            this.D2_999.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D1_999
            // 
            this.D1_999.DecimalPlaces = 5;
            this.D1_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_999.Location = new System.Drawing.Point(23, 80);
            this.D1_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_999.Name = "D1_999";
            this.D1_999.Size = new System.Drawing.Size(77, 27);
            this.D1_999.TabIndex = 6;
            this.D1_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_999
            // 
            this.DPM_999.DecimalPlaces = 5;
            this.DPM_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_999.Location = new System.Drawing.Point(25, 213);
            this.DPM_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_999.Name = "DPM_999";
            this.DPM_999.Size = new System.Drawing.Size(77, 27);
            this.DPM_999.TabIndex = 8;
            this.DPM_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(8, 188);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(178, 20);
            this.label53.TabIndex = 26;
            this.label53.Text = "Parent-pair: mother alone";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(8, 320);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(167, 20);
            this.label54.TabIndex = 30;
            this.label54.Text = "Parent-pair: two parents";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(8, 252);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(169, 20);
            this.label55.TabIndex = 31;
            this.label55.Text = "Parent-pair: father alone";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(8, 387);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(187, 20);
            this.label56.TabIndex = 29;
            this.label56.Text = "Parent-pair: sexes unknown";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(8, 57);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(184, 20);
            this.label57.TabIndex = 27;
            this.label57.Text = "Paternity: mother unknown";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(8, 122);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(168, 20);
            this.label59.TabIndex = 32;
            this.label59.Text = "Paternity: mother known";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(322, 30);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(60, 20);
            this.label60.TabIndex = 36;
            this.label60.Text = "Δ0.80 +";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(128, 30);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(62, 20);
            this.label61.TabIndex = 37;
            this.label61.Text = "Δ0.99 **";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(228, 30);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(56, 20);
            this.label62.TabIndex = 35;
            this.label62.Text = "Δ0.95 *";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(22, 30);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(76, 20);
            this.label63.TabIndex = 33;
            this.label63.Text = "Δ0.999 ***";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(122, 165);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(0, 20);
            this.label64.TabIndex = 34;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.ParentageSimResBox);
            this.groupBox46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox46.Location = new System.Drawing.Point(0, 0);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(1041, 661);
            this.groupBox46.TabIndex = 1;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Summary";
            // 
            // ParentageSimResBox
            // 
            this.ParentageSimResBox.AcceptsReturn = true;
            this.ParentageSimResBox.AcceptsTab = true;
            this.ParentageSimResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageSimResBox.HideSelection = false;
            this.ParentageSimResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageSimResBox.MaxLength = 32767000;
            this.ParentageSimResBox.Multiline = true;
            this.ParentageSimResBox.Name = "ParentageSimResBox";
            this.ParentageSimResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageSimResBox.Size = new System.Drawing.Size(1035, 635);
            this.ParentageSimResBox.TabIndex = 2;
            this.ParentageSimResBox.WordWrap = false;
            this.ParentageSimResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.splitContainer6);
            this.tabPage17.Location = new System.Drawing.Point(4, 29);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(1411, 661);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "Paternity";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.groupBox37);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.groupBox36);
            this.splitContainer6.Size = new System.Drawing.Size(1411, 661);
            this.splitContainer6.SplitterDistance = 427;
            this.splitContainer6.SplitterWidth = 5;
            this.splitContainer6.TabIndex = 0;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.ParentagePaternityOffspringBox);
            this.groupBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox37.Location = new System.Drawing.Point(0, 0);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(427, 661);
            this.groupBox37.TabIndex = 1;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Offspring, known mother and candidate fathers";
            // 
            // ParentagePaternityOffspringBox
            // 
            this.ParentagePaternityOffspringBox.AcceptsReturn = true;
            this.ParentagePaternityOffspringBox.AcceptsTab = true;
            this.ParentagePaternityOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentagePaternityOffspringBox.HideSelection = false;
            this.ParentagePaternityOffspringBox.Location = new System.Drawing.Point(3, 23);
            this.ParentagePaternityOffspringBox.MaxLength = 32767000;
            this.ParentagePaternityOffspringBox.Multiline = true;
            this.ParentagePaternityOffspringBox.Name = "ParentagePaternityOffspringBox";
            this.ParentagePaternityOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentagePaternityOffspringBox.Size = new System.Drawing.Size(421, 635);
            this.ParentagePaternityOffspringBox.TabIndex = 2;
            this.ParentagePaternityOffspringBox.WordWrap = false;
            this.ParentagePaternityOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.ParentagePaternityResBox);
            this.groupBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox36.Location = new System.Drawing.Point(0, 0);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(979, 661);
            this.groupBox36.TabIndex = 1;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Results";
            // 
            // ParentagePaternityResBox
            // 
            this.ParentagePaternityResBox.AcceptsReturn = true;
            this.ParentagePaternityResBox.AcceptsTab = true;
            this.ParentagePaternityResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentagePaternityResBox.HideSelection = false;
            this.ParentagePaternityResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentagePaternityResBox.MaxLength = 32767000;
            this.ParentagePaternityResBox.Multiline = true;
            this.ParentagePaternityResBox.Name = "ParentagePaternityResBox";
            this.ParentagePaternityResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentagePaternityResBox.Size = new System.Drawing.Size(973, 635);
            this.ParentagePaternityResBox.TabIndex = 2;
            this.ParentagePaternityResBox.WordWrap = false;
            this.ParentagePaternityResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.splitContainer7);
            this.tabPage18.Location = new System.Drawing.Point(4, 29);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(1411, 661);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Parent pair";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.splitContainer9);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.groupBox39);
            this.splitContainer7.Size = new System.Drawing.Size(1411, 661);
            this.splitContainer7.SplitterDistance = 426;
            this.splitContainer7.SplitterWidth = 5;
            this.splitContainer7.TabIndex = 1;
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.groupBox40);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.splitContainer10);
            this.splitContainer9.Size = new System.Drawing.Size(426, 661);
            this.splitContainer9.SplitterDistance = 154;
            this.splitContainer9.SplitterWidth = 5;
            this.splitContainer9.TabIndex = 0;
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.ParentageParentPairOffspringBox);
            this.groupBox40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox40.Location = new System.Drawing.Point(0, 0);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(426, 154);
            this.groupBox40.TabIndex = 2;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Offspring";
            // 
            // ParentageParentPairOffspringBox
            // 
            this.ParentageParentPairOffspringBox.AcceptsReturn = true;
            this.ParentageParentPairOffspringBox.AcceptsTab = true;
            this.ParentageParentPairOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairOffspringBox.HideSelection = false;
            this.ParentageParentPairOffspringBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageParentPairOffspringBox.MaxLength = 32767000;
            this.ParentageParentPairOffspringBox.Multiline = true;
            this.ParentageParentPairOffspringBox.Name = "ParentageParentPairOffspringBox";
            this.ParentageParentPairOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairOffspringBox.Size = new System.Drawing.Size(420, 128);
            this.ParentageParentPairOffspringBox.TabIndex = 2;
            this.ParentageParentPairOffspringBox.WordWrap = false;
            this.ParentageParentPairOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // splitContainer10
            // 
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.Location = new System.Drawing.Point(0, 0);
            this.splitContainer10.Name = "splitContainer10";
            this.splitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.groupBox41);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.groupBox42);
            this.splitContainer10.Size = new System.Drawing.Size(426, 502);
            this.splitContainer10.SplitterDistance = 193;
            this.splitContainer10.SplitterWidth = 5;
            this.splitContainer10.TabIndex = 1;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.ParentageParentPairMotherBox);
            this.groupBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox41.Location = new System.Drawing.Point(0, 0);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(426, 193);
            this.groupBox41.TabIndex = 2;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "Candidate mothers";
            // 
            // ParentageParentPairMotherBox
            // 
            this.ParentageParentPairMotherBox.AcceptsReturn = true;
            this.ParentageParentPairMotherBox.AcceptsTab = true;
            this.ParentageParentPairMotherBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairMotherBox.HideSelection = false;
            this.ParentageParentPairMotherBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageParentPairMotherBox.MaxLength = 32767000;
            this.ParentageParentPairMotherBox.Multiline = true;
            this.ParentageParentPairMotherBox.Name = "ParentageParentPairMotherBox";
            this.ParentageParentPairMotherBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairMotherBox.Size = new System.Drawing.Size(420, 167);
            this.ParentageParentPairMotherBox.TabIndex = 2;
            this.ParentageParentPairMotherBox.WordWrap = false;
            this.ParentageParentPairMotherBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.ParentageParentPairFatherBox);
            this.groupBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox42.Location = new System.Drawing.Point(0, 0);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(426, 304);
            this.groupBox42.TabIndex = 2;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Candidate fathers";
            // 
            // ParentageParentPairFatherBox
            // 
            this.ParentageParentPairFatherBox.AcceptsReturn = true;
            this.ParentageParentPairFatherBox.AcceptsTab = true;
            this.ParentageParentPairFatherBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairFatherBox.HideSelection = false;
            this.ParentageParentPairFatherBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageParentPairFatherBox.MaxLength = 32767000;
            this.ParentageParentPairFatherBox.Multiline = true;
            this.ParentageParentPairFatherBox.Name = "ParentageParentPairFatherBox";
            this.ParentageParentPairFatherBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairFatherBox.Size = new System.Drawing.Size(420, 278);
            this.ParentageParentPairFatherBox.TabIndex = 2;
            this.ParentageParentPairFatherBox.WordWrap = false;
            this.ParentageParentPairFatherBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.ParentageParentPairResBox);
            this.groupBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox39.Location = new System.Drawing.Point(0, 0);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(980, 661);
            this.groupBox39.TabIndex = 1;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "Results";
            // 
            // ParentageParentPairResBox
            // 
            this.ParentageParentPairResBox.AcceptsReturn = true;
            this.ParentageParentPairResBox.AcceptsTab = true;
            this.ParentageParentPairResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairResBox.HideSelection = false;
            this.ParentageParentPairResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageParentPairResBox.MaxLength = 32767000;
            this.ParentageParentPairResBox.Multiline = true;
            this.ParentageParentPairResBox.Name = "ParentageParentPairResBox";
            this.ParentageParentPairResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairResBox.Size = new System.Drawing.Size(974, 635);
            this.ParentageParentPairResBox.TabIndex = 2;
            this.ParentageParentPairResBox.WordWrap = false;
            this.ParentageParentPairResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.splitContainer11);
            this.tabPage19.Location = new System.Drawing.Point(4, 29);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Size = new System.Drawing.Size(1411, 661);
            this.tabPage19.TabIndex = 2;
            this.tabPage19.Text = "Parent pair (sexes unknown)";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.splitContainer13);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.groupBox38);
            this.splitContainer11.Size = new System.Drawing.Size(1411, 661);
            this.splitContainer11.SplitterDistance = 426;
            this.splitContainer11.SplitterWidth = 5;
            this.splitContainer11.TabIndex = 2;
            // 
            // splitContainer13
            // 
            this.splitContainer13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer13.Location = new System.Drawing.Point(0, 0);
            this.splitContainer13.Name = "splitContainer13";
            this.splitContainer13.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.groupBox43);
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.groupBox44);
            this.splitContainer13.Size = new System.Drawing.Size(426, 661);
            this.splitContainer13.SplitterDistance = 266;
            this.splitContainer13.SplitterWidth = 5;
            this.splitContainer13.TabIndex = 2;
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.ParentageUnknownOffspringBox);
            this.groupBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox43.Location = new System.Drawing.Point(0, 0);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(426, 266);
            this.groupBox43.TabIndex = 3;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Offspring";
            // 
            // ParentageUnknownOffspringBox
            // 
            this.ParentageUnknownOffspringBox.AcceptsReturn = true;
            this.ParentageUnknownOffspringBox.AcceptsTab = true;
            this.ParentageUnknownOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownOffspringBox.HideSelection = false;
            this.ParentageUnknownOffspringBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageUnknownOffspringBox.MaxLength = 32767000;
            this.ParentageUnknownOffspringBox.Multiline = true;
            this.ParentageUnknownOffspringBox.Name = "ParentageUnknownOffspringBox";
            this.ParentageUnknownOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownOffspringBox.Size = new System.Drawing.Size(420, 240);
            this.ParentageUnknownOffspringBox.TabIndex = 2;
            this.ParentageUnknownOffspringBox.WordWrap = false;
            this.ParentageUnknownOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.ParentageUnknownParentBox);
            this.groupBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox44.Location = new System.Drawing.Point(0, 0);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(426, 390);
            this.groupBox44.TabIndex = 3;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "Candidate parents";
            // 
            // ParentageUnknownParentBox
            // 
            this.ParentageUnknownParentBox.AcceptsReturn = true;
            this.ParentageUnknownParentBox.AcceptsTab = true;
            this.ParentageUnknownParentBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownParentBox.HideSelection = false;
            this.ParentageUnknownParentBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageUnknownParentBox.MaxLength = 32767000;
            this.ParentageUnknownParentBox.Multiline = true;
            this.ParentageUnknownParentBox.Name = "ParentageUnknownParentBox";
            this.ParentageUnknownParentBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownParentBox.Size = new System.Drawing.Size(420, 364);
            this.ParentageUnknownParentBox.TabIndex = 2;
            this.ParentageUnknownParentBox.WordWrap = false;
            this.ParentageUnknownParentBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.ParentageUnknownResBox);
            this.groupBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox38.Location = new System.Drawing.Point(0, 0);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(980, 661);
            this.groupBox38.TabIndex = 1;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "Results";
            // 
            // ParentageUnknownResBox
            // 
            this.ParentageUnknownResBox.AcceptsReturn = true;
            this.ParentageUnknownResBox.AcceptsTab = true;
            this.ParentageUnknownResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownResBox.HideSelection = false;
            this.ParentageUnknownResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageUnknownResBox.MaxLength = 32767000;
            this.ParentageUnknownResBox.Multiline = true;
            this.ParentageUnknownResBox.Name = "ParentageUnknownResBox";
            this.ParentageUnknownResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownResBox.Size = new System.Drawing.Size(974, 635);
            this.ParentageUnknownResBox.TabIndex = 2;
            this.ParentageUnknownResBox.WordWrap = false;
            this.ParentageUnknownResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.groupBox53);
            this.tabPage23.Location = new System.Drawing.Point(4, 29);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Size = new System.Drawing.Size(1411, 661);
            this.tabPage23.TabIndex = 4;
            this.tabPage23.Text = "Genotyping error rate";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.ParentageErrorResBox);
            this.groupBox53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox53.Location = new System.Drawing.Point(0, 0);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(1411, 661);
            this.groupBox53.TabIndex = 4;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "Result";
            // 
            // ParentageErrorResBox
            // 
            this.ParentageErrorResBox.AcceptsReturn = true;
            this.ParentageErrorResBox.AcceptsTab = true;
            this.ParentageErrorResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageErrorResBox.HideSelection = false;
            this.ParentageErrorResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageErrorResBox.MaxLength = 32767000;
            this.ParentageErrorResBox.Multiline = true;
            this.ParentageErrorResBox.Name = "ParentageErrorResBox";
            this.ParentageErrorResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageErrorResBox.Size = new System.Drawing.Size(1405, 635);
            this.ParentageErrorResBox.TabIndex = 2;
            this.ParentageErrorResBox.WordWrap = false;
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.groupBox54);
            this.tabPage24.Location = new System.Drawing.Point(4, 29);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Size = new System.Drawing.Size(1411, 661);
            this.tabPage24.TabIndex = 5;
            this.tabPage24.Text = "Sample rate";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // groupBox54
            // 
            this.groupBox54.Controls.Add(this.ParentageSampleResBox);
            this.groupBox54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox54.Location = new System.Drawing.Point(0, 0);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Size = new System.Drawing.Size(1411, 661);
            this.groupBox54.TabIndex = 5;
            this.groupBox54.TabStop = false;
            this.groupBox54.Text = "Result";
            // 
            // ParentageSampleResBox
            // 
            this.ParentageSampleResBox.AcceptsReturn = true;
            this.ParentageSampleResBox.AcceptsTab = true;
            this.ParentageSampleResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageSampleResBox.HideSelection = false;
            this.ParentageSampleResBox.Location = new System.Drawing.Point(3, 23);
            this.ParentageSampleResBox.MaxLength = 32767000;
            this.ParentageSampleResBox.Multiline = true;
            this.ParentageSampleResBox.Name = "ParentageSampleResBox";
            this.ParentageSampleResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageSampleResBox.Size = new System.Drawing.Size(1405, 635);
            this.ParentageSampleResBox.TabIndex = 2;
            this.ParentageSampleResBox.WordWrap = false;
            // 
            // AMOVAPage
            // 
            this.AMOVAPage.Controls.Add(this.groupBox10);
            this.AMOVAPage.Location = new System.Drawing.Point(4, 54);
            this.AMOVAPage.Name = "AMOVAPage";
            this.AMOVAPage.Size = new System.Drawing.Size(1419, 694);
            this.AMOVAPage.TabIndex = 6;
            this.AMOVAPage.Text = "AMOVA";
            this.AMOVAPage.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.AMOVAResBox);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(0, 0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1419, 694);
            this.groupBox10.TabIndex = 4;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Analysis of molecular variance";
            // 
            // AMOVAResBox
            // 
            this.AMOVAResBox.AcceptsReturn = true;
            this.AMOVAResBox.AcceptsTab = true;
            this.AMOVAResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AMOVAResBox.HideSelection = false;
            this.AMOVAResBox.Location = new System.Drawing.Point(3, 23);
            this.AMOVAResBox.MaxLength = 32767000;
            this.AMOVAResBox.Multiline = true;
            this.AMOVAResBox.Name = "AMOVAResBox";
            this.AMOVAResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AMOVAResBox.Size = new System.Drawing.Size(1413, 668);
            this.AMOVAResBox.TabIndex = 1;
            this.AMOVAResBox.WordWrap = false;
            this.AMOVAResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // StructurePage
            // 
            this.StructurePage.Controls.Add(this.splitContainer1);
            this.StructurePage.Location = new System.Drawing.Point(4, 54);
            this.StructurePage.Name = "StructurePage";
            this.StructurePage.Size = new System.Drawing.Size(1419, 694);
            this.StructurePage.TabIndex = 13;
            this.StructurePage.Text = "Structure";
            this.StructurePage.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer1.SplitterDistance = 426;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox29);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox25);
            this.splitContainer3.Size = new System.Drawing.Size(426, 694);
            this.splitContainer3.SplitterDistance = 260;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 1;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.StructureResultFileBox);
            this.groupBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox29.Location = new System.Drawing.Point(0, 0);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(426, 260);
            this.groupBox29.TabIndex = 1;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Result files (right click to delete)";
            // 
            // StructureResultFileBox
            // 
            this.StructureResultFileBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.StructureResultFileBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StructureResultFileBox.FullRowSelect = true;
            this.StructureResultFileBox.HideSelection = false;
            this.StructureResultFileBox.Location = new System.Drawing.Point(3, 23);
            this.StructureResultFileBox.Name = "StructureResultFileBox";
            this.StructureResultFileBox.Size = new System.Drawing.Size(420, 234);
            this.StructureResultFileBox.TabIndex = 0;
            this.StructureResultFileBox.UseCompatibleStateImageBehavior = false;
            this.StructureResultFileBox.View = System.Windows.Forms.View.Details;
            this.StructureResultFileBox.SelectedIndexChanged += new System.EventHandler(this.StructureResultFileBox_SelectedIndexChanged);
            this.StructureResultFileBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ShowStructureResultMenu);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "id";
            this.columnHeader4.Width = 40;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Time";
            this.columnHeader8.Width = 160;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "K";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Model";
            this.columnHeader10.Width = 130;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.StructureRunListBox);
            this.groupBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox25.Location = new System.Drawing.Point(0, 0);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(426, 429);
            this.groupBox25.TabIndex = 0;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Run summary";
            // 
            // StructureRunListBox
            // 
            this.StructureRunListBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader3});
            this.StructureRunListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StructureRunListBox.FullRowSelect = true;
            this.StructureRunListBox.HideSelection = false;
            this.StructureRunListBox.Location = new System.Drawing.Point(3, 23);
            this.StructureRunListBox.Name = "StructureRunListBox";
            this.StructureRunListBox.Size = new System.Drawing.Size(420, 403);
            this.StructureRunListBox.TabIndex = 0;
            this.StructureRunListBox.UseCompatibleStateImageBehavior = false;
            this.StructureRunListBox.View = System.Windows.Forms.View.Details;
            this.StructureRunListBox.SelectedIndexChanged += new System.EventHandler(this.StructureRunListBox_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "id";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "K";
            this.columnHeader2.Width = 40;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Mean lnL";
            this.columnHeader6.Width = 90;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Var lnL";
            this.columnHeader7.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "ln PD";
            this.columnHeader3.Width = 90;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox26);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox27);
            this.splitContainer2.Size = new System.Drawing.Size(988, 694);
            this.splitContainer2.SplitterDistance = 202;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.StructurePicBox);
            this.groupBox26.Controls.Add(this.StructureToolStrip);
            this.groupBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox26.Location = new System.Drawing.Point(0, 0);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(988, 202);
            this.groupBox26.TabIndex = 1;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Chart";
            // 
            // StructurePicBox
            // 
            this.StructurePicBox.BackColor = System.Drawing.Color.LightGray;
            this.StructurePicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StructurePicBox.Location = new System.Drawing.Point(3, 51);
            this.StructurePicBox.Name = "StructurePicBox";
            this.StructurePicBox.Size = new System.Drawing.Size(982, 148);
            this.StructurePicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StructurePicBox.TabIndex = 0;
            this.StructurePicBox.TabStop = false;
            // 
            // StructureToolStrip
            // 
            this.StructureToolStrip.ImageScalingSize = new System.Drawing.Size(22, 22);
            this.StructureToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveStructureButton,
            this.ExportStructureButton,
            this.toolStripSeparator9,
            this.toolStripLabel13,
            this.StructureIndividualOrderBox,
            this.toolStripLabel9,
            this.StructureRearrangeColorBox});
            this.StructureToolStrip.Location = new System.Drawing.Point(3, 23);
            this.StructureToolStrip.Name = "StructureToolStrip";
            this.StructureToolStrip.Size = new System.Drawing.Size(982, 28);
            this.StructureToolStrip.TabIndex = 0;
            this.StructureToolStrip.Text = "toolStrip1";
            // 
            // SaveStructureButton
            // 
            this.SaveStructureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SaveStructureButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveStructureButton.Image")));
            this.SaveStructureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveStructureButton.Name = "SaveStructureButton";
            this.SaveStructureButton.Size = new System.Drawing.Size(47, 25);
            this.SaveStructureButton.Text = "&Save";
            this.SaveStructureButton.Click += new System.EventHandler(this.SavePic);
            // 
            // ExportStructureButton
            // 
            this.ExportStructureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ExportStructureButton.Image = ((System.Drawing.Image)(resources.GetObject("ExportStructureButton.Image")));
            this.ExportStructureButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ExportStructureButton.Name = "ExportStructureButton";
            this.ExportStructureButton.Size = new System.Drawing.Size(86, 25);
            this.ExportStructureButton.Text = "Export &lnL";
            this.ExportStructureButton.Click += new System.EventHandler(this.ExportlnL);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel13
            // 
            this.toolStripLabel13.Name = "toolStripLabel13";
            this.toolStripLabel13.Size = new System.Drawing.Size(45, 25);
            this.toolStripLabel13.Text = "Type";
            // 
            // StructureIndividualOrderBox
            // 
            this.StructureIndividualOrderBox.Items.AddRange(new object[] {
            "Ancestry (original order)",
            "Ancestry (by populations)",
            "Ancestry (by ancestry)",
            "Likelihood convergency"});
            this.StructureIndividualOrderBox.Name = "StructureIndividualOrderBox";
            this.StructureIndividualOrderBox.Size = new System.Drawing.Size(217, 28);
            this.StructureIndividualOrderBox.SelectedIndexChanged += new System.EventHandler(this.StructureIndividualOrderBox_SelectedIndexChanged);
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(126, 25);
            this.toolStripLabel9.Text = "Rearrange color";
            // 
            // StructureRearrangeColorBox
            // 
            this.StructureRearrangeColorBox.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.StructureRearrangeColorBox.Name = "StructureRearrangeColorBox";
            this.StructureRearrangeColorBox.Size = new System.Drawing.Size(92, 28);
            this.StructureRearrangeColorBox.SelectedIndexChanged += new System.EventHandler(this.StructureRearrangeColorBox_SelectedIndexChanged);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.StructureRunDetailBox);
            this.groupBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox27.Location = new System.Drawing.Point(0, 0);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(988, 487);
            this.groupBox27.TabIndex = 1;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Details";
            // 
            // StructureRunDetailBox
            // 
            this.StructureRunDetailBox.AcceptsReturn = true;
            this.StructureRunDetailBox.AcceptsTab = true;
            this.StructureRunDetailBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StructureRunDetailBox.HideSelection = false;
            this.StructureRunDetailBox.Location = new System.Drawing.Point(3, 23);
            this.StructureRunDetailBox.MaxLength = 32767000;
            this.StructureRunDetailBox.Multiline = true;
            this.StructureRunDetailBox.Name = "StructureRunDetailBox";
            this.StructureRunDetailBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.StructureRunDetailBox.Size = new System.Drawing.Size(982, 461);
            this.StructureRunDetailBox.TabIndex = 0;
            this.StructureRunDetailBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesAssPage
            // 
            this.BayesAssPage.Controls.Add(this.splitContainer17);
            this.BayesAssPage.Location = new System.Drawing.Point(4, 54);
            this.BayesAssPage.Margin = new System.Windows.Forms.Padding(2);
            this.BayesAssPage.Name = "BayesAssPage";
            this.BayesAssPage.Size = new System.Drawing.Size(1419, 694);
            this.BayesAssPage.TabIndex = 21;
            this.BayesAssPage.Text = "BayesAss";
            this.BayesAssPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer17
            // 
            this.splitContainer17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer17.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer17.Location = new System.Drawing.Point(0, 0);
            this.splitContainer17.Name = "splitContainer17";
            // 
            // splitContainer17.Panel1
            // 
            this.splitContainer17.Panel1.Controls.Add(this.splitContainer18);
            // 
            // splitContainer17.Panel2
            // 
            this.splitContainer17.Panel2.Controls.Add(this.splitContainer19);
            this.splitContainer17.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer17.SplitterDistance = 426;
            this.splitContainer17.SplitterWidth = 5;
            this.splitContainer17.TabIndex = 1;
            // 
            // splitContainer18
            // 
            this.splitContainer18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer18.Location = new System.Drawing.Point(0, 0);
            this.splitContainer18.Name = "splitContainer18";
            this.splitContainer18.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer18.Panel1
            // 
            this.splitContainer18.Panel1.Controls.Add(this.groupBox7);
            // 
            // splitContainer18.Panel2
            // 
            this.splitContainer18.Panel2.Controls.Add(this.groupBox9);
            this.splitContainer18.Size = new System.Drawing.Size(426, 694);
            this.splitContainer18.SplitterDistance = 333;
            this.splitContainer18.SplitterWidth = 5;
            this.splitContainer18.TabIndex = 1;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.BayesAssResultFileBox);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(426, 333);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Result files (right click to delete)";
            // 
            // BayesAssResultFileBox
            // 
            this.BayesAssResultFileBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13});
            this.BayesAssResultFileBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesAssResultFileBox.FullRowSelect = true;
            this.BayesAssResultFileBox.HideSelection = false;
            this.BayesAssResultFileBox.Location = new System.Drawing.Point(3, 23);
            this.BayesAssResultFileBox.Name = "BayesAssResultFileBox";
            this.BayesAssResultFileBox.Size = new System.Drawing.Size(420, 307);
            this.BayesAssResultFileBox.TabIndex = 0;
            this.BayesAssResultFileBox.UseCompatibleStateImageBehavior = false;
            this.BayesAssResultFileBox.View = System.Windows.Forms.View.Details;
            this.BayesAssResultFileBox.SelectedIndexChanged += new System.EventHandler(this.BayesAssResultFileBox_SelectedIndexChanged);
            this.BayesAssResultFileBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ShowBayesAssResultMenu);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "id";
            this.columnHeader5.Width = 40;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Time";
            this.columnHeader11.Width = 160;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "N x P x L";
            this.columnHeader12.Width = 120;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Model";
            this.columnHeader13.Width = 130;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.BayesAssRunListBox);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(0, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(426, 356);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Run summary";
            // 
            // BayesAssRunListBox
            // 
            this.BayesAssRunListBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader17,
            this.columnHeader18});
            this.BayesAssRunListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesAssRunListBox.FullRowSelect = true;
            this.BayesAssRunListBox.HideSelection = false;
            this.BayesAssRunListBox.Location = new System.Drawing.Point(3, 23);
            this.BayesAssRunListBox.Name = "BayesAssRunListBox";
            this.BayesAssRunListBox.Size = new System.Drawing.Size(420, 330);
            this.BayesAssRunListBox.TabIndex = 0;
            this.BayesAssRunListBox.UseCompatibleStateImageBehavior = false;
            this.BayesAssRunListBox.View = System.Windows.Forms.View.Details;
            this.BayesAssRunListBox.SelectedIndexChanged += new System.EventHandler(this.BayesAssRunListBox_SelectedIndexChanged);
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "id";
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Avg(m)";
            this.columnHeader15.Width = 90;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "lnL";
            this.columnHeader17.Width = 140;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Var lnL";
            this.columnHeader18.Width = 100;
            // 
            // splitContainer19
            // 
            this.splitContainer19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer19.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer19.IsSplitterFixed = true;
            this.splitContainer19.Location = new System.Drawing.Point(0, 0);
            this.splitContainer19.Name = "splitContainer19";
            this.splitContainer19.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer19.Panel1
            // 
            this.splitContainer19.Panel1.Controls.Add(this.groupBox13);
            // 
            // splitContainer19.Panel2
            // 
            this.splitContainer19.Panel2.Controls.Add(this.groupBox15);
            this.splitContainer19.Size = new System.Drawing.Size(988, 694);
            this.splitContainer19.SplitterDistance = 202;
            this.splitContainer19.SplitterWidth = 5;
            this.splitContainer19.TabIndex = 0;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.BayesAssPicBox);
            this.groupBox13.Controls.Add(this.BayesAssToolStrip);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox13.Location = new System.Drawing.Point(0, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(988, 202);
            this.groupBox13.TabIndex = 1;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Chart";
            // 
            // BayesAssPicBox
            // 
            this.BayesAssPicBox.BackColor = System.Drawing.Color.LightGray;
            this.BayesAssPicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesAssPicBox.Location = new System.Drawing.Point(3, 51);
            this.BayesAssPicBox.Name = "BayesAssPicBox";
            this.BayesAssPicBox.Size = new System.Drawing.Size(982, 148);
            this.BayesAssPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BayesAssPicBox.TabIndex = 0;
            this.BayesAssPicBox.TabStop = false;
            // 
            // BayesAssToolStrip
            // 
            this.BayesAssToolStrip.ImageScalingSize = new System.Drawing.Size(22, 22);
            this.BayesAssToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveBayesAssButton,
            this.ExportBayesAssButton,
            this.toolStripButton1,
            this.toolStripSeparator12,
            this.toolStripLabel16,
            this.BayesAssPlotStyleBox});
            this.BayesAssToolStrip.Location = new System.Drawing.Point(3, 23);
            this.BayesAssToolStrip.Name = "BayesAssToolStrip";
            this.BayesAssToolStrip.Size = new System.Drawing.Size(982, 28);
            this.BayesAssToolStrip.TabIndex = 0;
            this.BayesAssToolStrip.Text = "BayesAssToolStrip";
            // 
            // SaveBayesAssButton
            // 
            this.SaveBayesAssButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SaveBayesAssButton.Image = ((System.Drawing.Image)(resources.GetObject("SaveBayesAssButton.Image")));
            this.SaveBayesAssButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveBayesAssButton.Name = "SaveBayesAssButton";
            this.SaveBayesAssButton.Size = new System.Drawing.Size(47, 25);
            this.SaveBayesAssButton.Text = "&Save";
            this.SaveBayesAssButton.Click += new System.EventHandler(this.SavePic);
            // 
            // ExportBayesAssButton
            // 
            this.ExportBayesAssButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ExportBayesAssButton.Image = ((System.Drawing.Image)(resources.GetObject("ExportBayesAssButton.Image")));
            this.ExportBayesAssButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ExportBayesAssButton.Name = "ExportBayesAssButton";
            this.ExportBayesAssButton.Size = new System.Drawing.Size(86, 25);
            this.ExportBayesAssButton.Text = "Export &lnL";
            this.ExportBayesAssButton.Click += new System.EventHandler(this.ExportlnL);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(114, 25);
            this.toolStripButton1.Text = "Export &Details";
            this.toolStripButton1.Click += new System.EventHandler(this.ExportBayesAssDetails);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel16
            // 
            this.toolStripLabel16.Name = "toolStripLabel16";
            this.toolStripLabel16.Size = new System.Drawing.Size(45, 25);
            this.toolStripLabel16.Text = "Type";
            // 
            // BayesAssPlotStyleBox
            // 
            this.BayesAssPlotStyleBox.Items.AddRange(new object[] {
            "Migration ancestry",
            "Migration ancestry x generation",
            "Migration generation",
            "Migration ancestry (by group)",
            "Migration ancestry x generation (by group)",
            "Migration ancestry (by group)",
            "Genotype Likelihood convergency",
            "Migrant Likelihood convergency",
            "Total Likelihood convergency"});
            this.BayesAssPlotStyleBox.Name = "BayesAssPlotStyleBox";
            this.BayesAssPlotStyleBox.Size = new System.Drawing.Size(217, 28);
            this.BayesAssPlotStyleBox.SelectedIndexChanged += new System.EventHandler(this.BayesAssPlotStyleBox_SelectedIndexChanged);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.BayesAssRunDetailBox);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox15.Location = new System.Drawing.Point(0, 0);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(988, 487);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Details";
            // 
            // BayesAssRunDetailBox
            // 
            this.BayesAssRunDetailBox.AcceptsReturn = true;
            this.BayesAssRunDetailBox.AcceptsTab = true;
            this.BayesAssRunDetailBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesAssRunDetailBox.HideSelection = false;
            this.BayesAssRunDetailBox.Location = new System.Drawing.Point(3, 23);
            this.BayesAssRunDetailBox.MaxLength = 32767000;
            this.BayesAssRunDetailBox.Multiline = true;
            this.BayesAssRunDetailBox.Name = "BayesAssRunDetailBox";
            this.BayesAssRunDetailBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.BayesAssRunDetailBox.Size = new System.Drawing.Size(982, 461);
            this.BayesAssRunDetailBox.TabIndex = 0;
            this.BayesAssRunDetailBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // MantelPage
            // 
            this.MantelPage.Controls.Add(this.splitContainer4);
            this.MantelPage.Location = new System.Drawing.Point(4, 54);
            this.MantelPage.Name = "MantelPage";
            this.MantelPage.Size = new System.Drawing.Size(1419, 694);
            this.MantelPage.TabIndex = 14;
            this.MantelPage.Text = "Mantel";
            this.MantelPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer5);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.groupBox32);
            this.splitContainer4.Size = new System.Drawing.Size(1419, 694);
            this.splitContainer4.SplitterDistance = 368;
            this.splitContainer4.SplitterWidth = 5;
            this.splitContainer4.TabIndex = 0;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.groupBox31);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.groupBox30);
            this.splitContainer5.Size = new System.Drawing.Size(368, 694);
            this.splitContainer5.SplitterDistance = 166;
            this.splitContainer5.SplitterWidth = 5;
            this.splitContainer5.TabIndex = 1;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.linkLabel2);
            this.groupBox31.Controls.Add(this.MantelPermuteButton);
            this.groupBox31.Controls.Add(this.MantelExampleButton);
            this.groupBox31.Controls.Add(this.MantelNPermBox);
            this.groupBox31.Controls.Add(this.label44);
            this.groupBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox31.Location = new System.Drawing.Point(0, 0);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(368, 166);
            this.groupBox31.TabIndex = 1;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Parameters";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(22, 102);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(319, 60);
            this.linkLabel2.TabIndex = 512;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Faster and powerful Mantel tests in ISOLATION.\r\nControl up to 10 partial matrices" +
    "; 100X speed;\r\npartition; filter; FDR correction...";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // MantelPermuteButton
            // 
            this.MantelPermuteButton.Location = new System.Drawing.Point(27, 32);
            this.MantelPermuteButton.Name = "MantelPermuteButton";
            this.MantelPermuteButton.Size = new System.Drawing.Size(93, 27);
            this.MantelPermuteButton.TabIndex = 511;
            this.MantelPermuteButton.Text = "&Permute";
            this.MantelPermuteButton.UseVisualStyleBackColor = true;
            this.MantelPermuteButton.Click += new System.EventHandler(this.MantelPermute);
            // 
            // MantelExampleButton
            // 
            this.MantelExampleButton.Location = new System.Drawing.Point(137, 32);
            this.MantelExampleButton.Name = "MantelExampleButton";
            this.MantelExampleButton.Size = new System.Drawing.Size(93, 27);
            this.MantelExampleButton.TabIndex = 511;
            this.MantelExampleButton.Text = "&Example";
            this.MantelExampleButton.UseVisualStyleBackColor = true;
            this.MantelExampleButton.Click += new System.EventHandler(this.MantelExample);
            // 
            // MantelNPermBox
            // 
            this.MantelNPermBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.MantelNPermBox.Location = new System.Drawing.Point(137, 68);
            this.MantelNPermBox.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.MantelNPermBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.MantelNPermBox.Name = "MantelNPermBox";
            this.MantelNPermBox.Size = new System.Drawing.Size(93, 27);
            this.MantelNPermBox.TabIndex = 510;
            this.MantelNPermBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.MantelNPermBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(22, 70);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(104, 20);
            this.label44.TabIndex = 509;
            this.label44.Text = "#Permutations";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.MantelResBox);
            this.groupBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox30.Location = new System.Drawing.Point(0, 0);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(368, 523);
            this.groupBox30.TabIndex = 0;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Results";
            // 
            // MantelResBox
            // 
            this.MantelResBox.AcceptsReturn = true;
            this.MantelResBox.AcceptsTab = true;
            this.MantelResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MantelResBox.HideSelection = false;
            this.MantelResBox.Location = new System.Drawing.Point(3, 23);
            this.MantelResBox.MaxLength = 32767000;
            this.MantelResBox.Multiline = true;
            this.MantelResBox.Name = "MantelResBox";
            this.MantelResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.MantelResBox.Size = new System.Drawing.Size(362, 497);
            this.MantelResBox.TabIndex = 2;
            this.MantelResBox.WordWrap = false;
            this.MantelResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.MantelMatBox);
            this.groupBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox32.Location = new System.Drawing.Point(0, 0);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(1046, 694);
            this.groupBox32.TabIndex = 1;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Matrices (2 or up to 7 matrices, for simple or partial Mantel test, in order Y,X," +
    "Z1,Z2,Z3,Z4,Z5)";
            // 
            // MantelMatBox
            // 
            this.MantelMatBox.AcceptsReturn = true;
            this.MantelMatBox.AcceptsTab = true;
            this.MantelMatBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MantelMatBox.HideSelection = false;
            this.MantelMatBox.Location = new System.Drawing.Point(3, 23);
            this.MantelMatBox.MaxLength = 32767000;
            this.MantelMatBox.Multiline = true;
            this.MantelMatBox.Name = "MantelMatBox";
            this.MantelMatBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.MantelMatBox.Size = new System.Drawing.Size(1040, 668);
            this.MantelMatBox.TabIndex = 2;
            this.MantelMatBox.WordWrap = false;
            this.MantelMatBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ProgressTimer
            // 
            this.ProgressTimer.Enabled = true;
            this.ProgressTimer.Tick += new System.EventHandler(this.ProgressTimerTick);
            // 
            // SavePicDialog
            // 
            this.SavePicDialog.DefaultExt = "*.png";
            this.SavePicDialog.Filter = "*.png|*.png|*.jpg|*.jpg|*.gif|*.gif|*.tif|*.tif|*.bmp|*.bmp|*.emf|*.emf|*.wmf|*.w" +
    "mf";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.deleteAllToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(150, 52);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(149, 24);
            this.toolStripMenuItem1.Text = "&Delete";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.DeleteResult);
            // 
            // deleteAllToolStripMenuItem
            // 
            this.deleteAllToolStripMenuItem.Name = "deleteAllToolStripMenuItem";
            this.deleteAllToolStripMenuItem.Size = new System.Drawing.Size(149, 24);
            this.deleteAllToolStripMenuItem.Text = "Delete &All";
            this.deleteAllToolStripMenuItem.Click += new System.EventHandler(this.DeleteAllResult);
            // 
            // ImportFileDialog
            // 
            this.ImportFileDialog.Filter = "*.txt|*.txt|*.vcf|*.vcf|*.*|*.*";
            // 
            // PreSaveTimer
            // 
            this.PreSaveTimer.Enabled = true;
            this.PreSaveTimer.Interval = 10000;
            this.PreSaveTimer.Tick += new System.EventHandler(this.PreSaveTimerTick);
            // 
            // FoldTimer
            // 
            this.FoldTimer.Enabled = true;
            this.FoldTimer.Interval = 1000;
            this.FoldTimer.Tick += new System.EventHandler(this.FoldTimer_Tick);
            // 
            // SaveDataDialog
            // 
            this.SaveDataDialog.DefaultExt = "*.txt";
            this.SaveDataDialog.Filter = "*.txt|*.txt";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1427, 783);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.MainToolStrip);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "Form1";
            this.Text = "PolyGene V1.5";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.MainToolStrip.ResumeLayout(false);
            this.MainToolStrip.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.InputPage.ResumeLayout(false);
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).EndInit();
            this.splitContainer14.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.SimulationToolStrip.ResumeLayout(false);
            this.SimulationToolStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_NegPCRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SamplingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SelfingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_FemaleRateBox)).EndInit();
            this.ParametersPage.ResumeLayout(false);
            this.splitContainer20.Panel1.ResumeLayout(false);
            this.splitContainer20.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer20)).EndInit();
            this.splitContainer20.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.GroupBoxMethods.ResumeLayout(false);
            this.GroupBoxMethods.PerformLayout();
            this.GroupBoxAlleleFrequency.ResumeLayout(false);
            this.GroupBoxAlleleFrequency.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FrequencyNrRateBox)).EndInit();
            this.GroupBoxGeneralSettings.ResumeLayout(false);
            this.GroupBoxGeneralSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalSeedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalThreadBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalDecimalPlaceBox)).EndInit();
            this.ParametersPanel.ResumeLayout(false);
            this.GroupBoxHeritability.ResumeLayout(false);
            this.GroupBoxHeritability.PerformLayout();
            this.GroupBoxNe.ResumeLayout(false);
            this.GroupBoxNe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NeWaplesFBox)).EndInit();
            this.GroupBoxDistribution.ResumeLayout(false);
            this.GroupBoxDistribution.PerformLayout();
            this.GroupBoxStructure.ResumeLayout(false);
            this.GroupBoxStructure.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StructureADMBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureKmaxBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNThinningBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNRepsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsGammaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsEtaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFPriorStdBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureEpsRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFStdFBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureFPriorMeanBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureUpdateQBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlphaPrioriABox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlphaPrioriBBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureStdAlphaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxAlphaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureAlpha0Box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureMaxLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureStdLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureNRunsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StructureKminBox)).EndInit();
            this.GroupBoxLinkage.ResumeLayout(false);
            this.GroupBoxLinkage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageIterationsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBatchesBox)).EndInit();
            this.GroupBoxOrdination.ResumeLayout(false);
            this.GroupBoxOrdination.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrdinationDimBox)).EndInit();
            this.GroupBoxDiff.ResumeLayout(false);
            this.GroupBoxDiff.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiffIterationsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBatchesBox)).EndInit();
            this.GroupBoxAssignment.ResumeLayout(false);
            this.GroupBoxAssignment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentErrorBox)).EndInit();
            this.GroupBoxSpatial.ResumeLayout(false);
            this.GroupBoxSpatial.PerformLayout();
            this.GroupBoxBayesAss.ResumeLayout(false);
            this.GroupBoxBayesAss.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaMBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaFBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssDeltaABox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNThinningBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNRepsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssNRunsBox)).EndInit();
            this.GroupBoxClustering.ResumeLayout(false);
            this.GroupBoxClustering.PerformLayout();
            this.GroupBoxAMOVA.ResumeLayout(false);
            this.GroupBoxAMOVA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AMOVANPermBox)).EndInit();
            this.GroupBoxParentage.ResumeLayout(false);
            this.GroupBoxParentage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageErrorNSimBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageNSimBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNCandidateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNMotherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNFatherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNFatherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageSamplingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageMistypeRateBox)).EndInit();
            this.GroupBoxDist.ResumeLayout(false);
            this.GroupBoxDist.PerformLayout();
            this.GroupBoxRelationship.ResumeLayout(false);
            this.GroupBoxRelationship.PerformLayout();
            this.GroupBoxInbreeding.ResumeLayout(false);
            this.GroupBoxInbreeding.PerformLayout();
            this.DiversityPage.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.FrequencyPage.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.DistributionPage.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.LinkagePage.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.NePage.ResumeLayout(false);
            this.groupBox56.ResumeLayout(false);
            this.groupBox56.PerformLayout();
            this.DiffPage.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.DistPage.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.OrdinationPage.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).EndInit();
            this.splitContainer15.ResumeLayout(false);
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.PCoAPanel.ResumeLayout(false);
            this.PCoAPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrdinationPicBox)).EndInit();
            this.OrdinationToolStrip.ResumeLayout(false);
            this.OrdinationToolStrip.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.ClusteringPage.ResumeLayout(false);
            this.splitContainer16.Panel1.ResumeLayout(false);
            this.splitContainer16.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).EndInit();
            this.splitContainer16.ResumeLayout(false);
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.ClusteringPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringPicBox)).EndInit();
            this.ClusteringToolStrip.ResumeLayout(false);
            this.ClusteringToolStrip.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.groupBox49.PerformLayout();
            this.InbreedingPage.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.HIndexPage.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.AssignmentPage.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.SpatialPage.ResumeLayout(false);
            this.groupBox59.ResumeLayout(false);
            this.groupBox59.PerformLayout();
            this.RelationshipPage.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.HeritabilityPage.ResumeLayout(false);
            this.groupBox60.ResumeLayout(false);
            this.groupBox60.PerformLayout();
            this.QstPage.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.ParentagePage.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPU_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_999)).EndInit();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox39.ResumeLayout(false);
            this.groupBox39.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).EndInit();
            this.splitContainer13.ResumeLayout(false);
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox38.ResumeLayout(false);
            this.groupBox38.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.groupBox53.ResumeLayout(false);
            this.groupBox53.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.groupBox54.ResumeLayout(false);
            this.groupBox54.PerformLayout();
            this.AMOVAPage.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.StructurePage.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StructurePicBox)).EndInit();
            this.StructureToolStrip.ResumeLayout(false);
            this.StructureToolStrip.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.BayesAssPage.ResumeLayout(false);
            this.splitContainer17.Panel1.ResumeLayout(false);
            this.splitContainer17.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer17)).EndInit();
            this.splitContainer17.ResumeLayout(false);
            this.splitContainer18.Panel1.ResumeLayout(false);
            this.splitContainer18.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer18)).EndInit();
            this.splitContainer18.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.splitContainer19.Panel1.ResumeLayout(false);
            this.splitContainer19.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer19)).EndInit();
            this.splitContainer19.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesAssPicBox)).EndInit();
            this.BayesAssToolStrip.ResumeLayout(false);
            this.BayesAssToolStrip.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.MantelPage.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MantelNPermBox)).EndInit();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip MainToolStrip;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage InputPage;
        private System.Windows.Forms.TabPage ParametersPage;
        private System.Windows.Forms.TabPage FrequencyPage;
        private System.Windows.Forms.TabPage DiffPage;
        private System.Windows.Forms.TabPage InbreedingPage;
        private System.Windows.Forms.TabPage AMOVAPage;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox SimPop_AlleleFrequencyBox;
        private System.Windows.Forms.ToolStrip SimulationToolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton Reproduce1Button;
        private System.Windows.Forms.ToolStripButton Reproduce10Button;
        private System.Windows.Forms.ToolStripButton Reproduce100Button;
        private System.Windows.Forms.ToolStripButton Reproduce1000Button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox PhenotypeBox;
        private System.Windows.Forms.ToolStripButton SimulationuntilFstButton;
        private System.Windows.Forms.ToolStripComboBox SimPop_FstTerminalBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel GenLabel;
        private System.Windows.Forms.ToolStripLabel FstLabel;
        private System.Windows.Forms.GroupBox GroupBoxAlleleFrequency;
        private System.Windows.Forms.CheckBox GlobalWarningBox;
        private System.Windows.Forms.CheckBox FrequencyNullAlleleBox;
        private System.Windows.Forms.ComboBox FrequencyInheritanceModeBox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox SimPop_DioeciousBox;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown SimPop_SamplingRateBox;
        private System.Windows.Forms.NumericUpDown SimPop_SelfingRateBox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown SimPop_FemaleRateBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox GroupBoxGeneralSettings;
        private System.Windows.Forms.NumericUpDown GlobalDecimalPlaceBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox FrequencyResBox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox DiffResBox;
        private System.Windows.Forms.TabPage DistributionPage;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox DistributionResBox;
        private System.Windows.Forms.TabPage HIndexPage;
        private System.Windows.Forms.TabPage DiversityPage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.Button SimRandomizeDistanceToCentermereButton;
        private System.Windows.Forms.TextBox SimPop_DistBox;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown AMOVANPermBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer ProgressTimer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox InbreedingResBox;
        private System.Windows.Forms.TabPage AssignmentPage;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox DiversityResBox;
        private System.Windows.Forms.GroupBox GroupBoxAMOVA;
        private System.Windows.Forms.TextBox GlobalRegionBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox AMOVAResBox;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox HIndexResBox;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox AssignmentResBox;
        private System.Windows.Forms.ToolStripLabel TaskLabel;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.GroupBox GroupBoxAssignment;
        private System.Windows.Forms.NumericUpDown AssignmentErrorBox;
        private System.Windows.Forms.CheckBox AssignmentPloidyBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage RelationshipPage;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox RelationshipResBox;
        private System.Windows.Forms.GroupBox GroupBoxRelationship;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage LinkagePage;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox LinkageResBox;
        private System.Windows.Forms.GroupBox GroupBoxLinkage;
        private System.Windows.Forms.CheckBox LinkageTestPopBox;
        private System.Windows.Forms.GroupBox GroupBoxMethods;
        private System.Windows.Forms.CheckBox CalcAMOVABox;
        private System.Windows.Forms.CheckBox CalcRelationshipBox;
        private System.Windows.Forms.CheckBox CalcAssignmentBox;
        private System.Windows.Forms.CheckBox CalcHIndexBox;
        private System.Windows.Forms.CheckBox CalcInbreedingBox;
        private System.Windows.Forms.CheckBox CalcDistributionBox;
        private System.Windows.Forms.CheckBox CalcDiffBox;
        private System.Windows.Forms.CheckBox CalcLinkageBox;
        private System.Windows.Forms.TabPage DistPage;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox DistResBox;
        private System.Windows.Forms.CheckBox CalcDistBox;
        private System.Windows.Forms.GroupBox GroupBoxDist;
        private System.Windows.Forms.CheckBox DistCavalli1967Box;
        private System.Windows.Forms.CheckBox DistNei1972Box;
        private System.Windows.Forms.GroupBox GroupBoxDiff;
        private System.Windows.Forms.CheckBox DiffSlatkin1995Box;
        private System.Windows.Forms.CheckBox DistSlatkinBox;
        private System.Windows.Forms.CheckBox DistRoger1973Box;
        private System.Windows.Forms.CheckBox DistNei1983Box;
        private System.Windows.Forms.CheckBox DistReynolds1983Box;
        private System.Windows.Forms.CheckBox DistNei1973Box;
        private System.Windows.Forms.CheckBox DistReynold1993Box;
        private System.Windows.Forms.CheckBox DistGoldstein1995Box;
        private System.Windows.Forms.CheckBox DistEuclideanBox;
        private System.Windows.Forms.CheckBox DiffTestAlleleBox;
        private System.Windows.Forms.CheckBox DiffTestPhenoBox;
        private System.Windows.Forms.CheckBox RelationshipLoiselle1995Box;
        private System.Windows.Forms.CheckBox RelationshipRitland1996Box;
        private System.Windows.Forms.CheckBox RelationshipLoiselle1995mBox;
        private System.Windows.Forms.CheckBox RelationshipWeir1996Box;
        private System.Windows.Forms.CheckBox RelationshipRitland1996mBox;
        private System.Windows.Forms.CheckBox RelationshipPopBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox RelationshipTotBox;
        private System.Windows.Forms.NumericUpDown GlobalThreadBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox GroupBoxStructure;
        private System.Windows.Forms.CheckBox StructureADMBox;
        private System.Windows.Forms.CheckBox StructureLOCPRIORIBox;
        private System.Windows.Forms.TabPage StructurePage;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ListView StructureRunListBox;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.PictureBox StructurePicBox;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TextBox StructureRunDetailBox;
        private System.Windows.Forms.CheckBox CalcStructureBox;
        private System.Windows.Forms.NumericUpDown StructureKmaxBox;
        private System.Windows.Forms.NumericUpDown StructureBurninBox;
        private System.Windows.Forms.NumericUpDown StructureNRepsBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown StructureNRunsBox;
        private System.Windows.Forms.NumericUpDown StructureKminBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox LinkageTestTotBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.SaveFileDialog SavePicDialog;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown StructureStdAlphaBox;
        private System.Windows.Forms.NumericUpDown StructureAlpha0Box;
        private System.Windows.Forms.NumericUpDown StructureLambdaBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown StructureMaxRBox;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown StructureEpsGammaBox;
        private System.Windows.Forms.NumericUpDown StructureEpsEtaBox;
        private System.Windows.Forms.NumericUpDown StructureEpsRBox;
        private System.Windows.Forms.NumericUpDown StructureNThinningBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.ListView StructureResultFileBox;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ToolStripMenuItem deleteAllToolStripMenuItem;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown StructureFPriorStdBox;
        private System.Windows.Forms.NumericUpDown StructureFPriorMeanBox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox StructureFSameBox;
        private System.Windows.Forms.CheckBox StructureFmodelBox;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.NumericUpDown StructureFStdFBox;
        private System.Windows.Forms.TabPage MantelPage;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.Button MantelExampleButton;
        private System.Windows.Forms.NumericUpDown MantelNPermBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.TextBox MantelResBox;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.TextBox MantelMatBox;
        private System.Windows.Forms.Button MantelPermuteButton;
        private System.Windows.Forms.Button GlobalRandomizeSeedButton;
        private System.Windows.Forms.NumericUpDown GlobalSeedBox;
        private System.Windows.Forms.CheckBox GlobalRefreshSeedBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.NumericUpDown StructureADMBurninBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.NumericUpDown StructureUpdateQBox;
        private System.Windows.Forms.NumericUpDown StructureMaxAlphaBox;
        private System.Windows.Forms.OpenFileDialog ImportFileDialog;
        private System.Windows.Forms.CheckBox AMOVAIgnoreIndBox;
        private System.Windows.Forms.TabPage ParentagePage;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.GroupBox GroupBoxInbreeding;
        private System.Windows.Forms.CheckBox InbreedingLoiselle1995Box;
        private System.Windows.Forms.CheckBox InbreedingRitland1996Box;
        private System.Windows.Forms.CheckBox InbreedingWeir1996Box;
        private System.Windows.Forms.GroupBox GroupBoxParentage;
        private System.Windows.Forms.CheckBox CalcParentageBox;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown ParentageNSimBox;
        private System.Windows.Forms.NumericUpDown ParentageUnknownNCandidateBox;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.NumericUpDown ParentageParentPairNMotherBox;
        private System.Windows.Forms.NumericUpDown ParentageParentPairNFatherBox;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.NumericUpDown ParentagePaternityNFatherBox;
        private System.Windows.Forms.NumericUpDown ParentageSamplingRateBox;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.NumericUpDown ParentageMistypeRateBox;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.SplitContainer splitContainer13;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.CheckBox ParentageUnknownBox;
        private System.Windows.Forms.CheckBox ParentageParentPairBox;
        private System.Windows.Forms.CheckBox ParentageSkipSimBox;
        private System.Windows.Forms.CheckBox ParentagePaternityBox;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TextBox ParentageSimResBox;
        private System.Windows.Forms.TextBox ParentagePaternityOffspringBox;
        private System.Windows.Forms.TextBox ParentageParentPairOffspringBox;
        private System.Windows.Forms.TextBox ParentageParentPairMotherBox;
        private System.Windows.Forms.TextBox ParentageParentPairFatherBox;
        private System.Windows.Forms.TextBox ParentageUnknownOffspringBox;
        private System.Windows.Forms.TextBox ParentageUnknownParentBox;
        private System.Windows.Forms.ComboBox ParentageOutputBox;
        private System.Windows.Forms.TextBox ParentagePaternityResBox;
        private System.Windows.Forms.TextBox ParentageParentPairResBox;
        private System.Windows.Forms.TextBox ParentageUnknownResBox;
        private System.Windows.Forms.NumericUpDown D2_95;
        private System.Windows.Forms.NumericUpDown D2_99;
        private System.Windows.Forms.NumericUpDown D2_999;
        private System.Windows.Forms.NumericUpDown D2_80;
        private System.Windows.Forms.NumericUpDown D1_95;
        private System.Windows.Forms.NumericUpDown D1_99;
        private System.Windows.Forms.NumericUpDown DPM_95;
        private System.Windows.Forms.NumericUpDown D1_999;
        private System.Windows.Forms.NumericUpDown DPF_95;
        private System.Windows.Forms.NumericUpDown DPM_99;
        private System.Windows.Forms.NumericUpDown DPF_99;
        private System.Windows.Forms.NumericUpDown DPM_999;
        private System.Windows.Forms.NumericUpDown DPF_999;
        private System.Windows.Forms.NumericUpDown DPU_80;
        private System.Windows.Forms.NumericUpDown DP_95;
        private System.Windows.Forms.NumericUpDown DP_80;
        private System.Windows.Forms.NumericUpDown DP_99;
        private System.Windows.Forms.NumericUpDown DPU_999;
        private System.Windows.Forms.NumericUpDown DPU_95;
        private System.Windows.Forms.NumericUpDown DPF_80;
        private System.Windows.Forms.NumericUpDown DP_999;
        private System.Windows.Forms.NumericUpDown DPM_80;
        private System.Windows.Forms.NumericUpDown DPU_99;
        private System.Windows.Forms.NumericUpDown D1_80;
        private System.Windows.Forms.CheckBox DiffHedrick2005Box;
        private System.Windows.Forms.CheckBox DiffHudson1992Box;
        private System.Windows.Forms.CheckBox DiffNei1973Box;
        private System.Windows.Forms.CheckBox DiffJost2008Box;
        private System.Windows.Forms.CheckBox AMOVASMMBox;
        private System.Windows.Forms.CheckBox AMOVAIAMBox;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.CheckBox DiffHuang2018SMMBox;
        private System.Windows.Forms.CheckBox DiffHuang2018IAMBox;
        private System.Windows.Forms.NumericUpDown DiffBatchesBox;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.CheckBox DiffTestPermBox;
        private System.Windows.Forms.NumericUpDown DiffIterationsBox;
        private System.Windows.Forms.NumericUpDown DiffBurninBox;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown LinkageIterationsBox;
        private System.Windows.Forms.NumericUpDown LinkageBurninBox;
        private System.Windows.Forms.NumericUpDown LinkageBatchesBox;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.SplitContainer splitContainer14;
        private System.Windows.Forms.CheckBox LinkageRaymondTestBox;
        private System.Windows.Forms.CheckBox CalcOrdinationBox;
        private System.Windows.Forms.TabPage OrdinationPage;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TextBox OrdinationResBox;
        private System.Windows.Forms.GroupBox GroupBoxClustering;
        private System.Windows.Forms.CheckBox ClusteringWPGMABox;
        private System.Windows.Forms.CheckBox ClusteringWARDBox;
        private System.Windows.Forms.CheckBox ClusteringUPGMABox;
        private System.Windows.Forms.CheckBox ClusteringWPGMCBox;
        private System.Windows.Forms.CheckBox ClusteringFurthestBox;
        private System.Windows.Forms.CheckBox ClusteringUPGMCBox;
        private System.Windows.Forms.CheckBox ClusteringNearestBox;
        private System.Windows.Forms.CheckBox CalcClusteringBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage ClusteringPage;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TextBox ClusteringResBox;
        private System.Windows.Forms.CheckBox DistRegBox;
        private System.Windows.Forms.CheckBox DistPopBox;
        private System.Windows.Forms.CheckBox DistIndBox;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.CheckBox DiffRegBox;
        private System.Windows.Forms.CheckBox DiffPopBox;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.GroupBox GroupBoxDistribution;
        private System.Windows.Forms.CheckBox PhenotypeTestTotBox;
        private System.Windows.Forms.CheckBox PhenotypeTestRegBox;
        private System.Windows.Forms.CheckBox PhenotypeTestPopBox;
        private System.Windows.Forms.CheckBox LinkageTestRegBox;
        private System.Windows.Forms.GroupBox GroupBoxOrdination;
        private System.Windows.Forms.NumericUpDown OrdinationDimBox;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.SplitContainer splitContainer15;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.ToolStrip OrdinationToolStrip;
        private System.Windows.Forms.ToolStripComboBox OrdinationComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton OrdinationPreviousButton;
        private System.Windows.Forms.ToolStripButton OrdinationNextButton;
        private System.Windows.Forms.SplitContainer splitContainer16;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.ToolStrip ClusteringToolStrip;
        private System.Windows.Forms.ToolStripComboBox ClusteringComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton ClusteringPreviousButton;
        private System.Windows.Forms.ToolStripButton ClusteringNextButton;
        private System.Windows.Forms.Panel ClusteringPanel;
        private System.Windows.Forms.PictureBox ClusteringPicBox;
        private System.Windows.Forms.Panel PCoAPanel;
        private System.Windows.Forms.PictureBox OrdinationPicBox;
        private System.Windows.Forms.CheckBox DiffTotBox;
        private System.Windows.Forms.CheckBox RelationshipRegBox;
        private System.Windows.Forms.CheckBox SimPop_OutputGenotypeBox;
        private System.Windows.Forms.CheckBox FrequencyRemoveDupAlleleBox;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.NumericUpDown StructureStdLambdaBox;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.NumericUpDown StructureMaxLambdaBox;
        private System.Windows.Forms.CheckBox StructureDiffLambdaBox;
        private System.Windows.Forms.CheckBox StructureInferLambdaBox;
        private System.Windows.Forms.CheckBox StructureDiffAlphaBox;
        private System.Windows.Forms.CheckBox StructureInferAlphaBox;
        private System.Windows.Forms.CheckBox StructureUniformAlphaBox;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.NumericUpDown StructureAlphaPrioriABox;
        private System.Windows.Forms.NumericUpDown StructureAlphaPrioriBBox;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.CheckBox RelationshipHuang2015Box;
        private System.Windows.Forms.CheckBox RelationshipHuang2014Box;
        private System.Windows.Forms.Timer PreSaveTimer;
        private System.Windows.Forms.CheckBox AMOVAGenotypeBox;
        private System.Windows.Forms.CheckBox AMOVAAnisoBox;
        private System.Windows.Forms.CheckBox AMOVAHomoBox;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.CheckBox AMOVAMLBox;
        private System.Windows.Forms.CheckBox FrequencySelfingBox;
        private System.Windows.Forms.CheckBox FrequencyNegPCRBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown SimPop_NegPCRBox;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox ParentageEstErrorBox;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.TextBox ParentageErrorResBox;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.GroupBox groupBox54;
        private System.Windows.Forms.TextBox ParentageSampleResBox;
        private System.Windows.Forms.NumericUpDown ParentageErrorNSimBox;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.CheckBox ParentageEstSampleBox;
        private System.Windows.Forms.ComboBox ParentageMethodBox;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.CheckBox ParentageRedoBox;
        private System.Windows.Forms.CheckBox AMOVAHomoCorrBox;
        private System.Windows.Forms.ToolStripButton CalcButton;
        private System.Windows.Forms.ToolStripButton AbortButton;
        private System.Windows.Forms.ToolStripButton AboutButton;
        private System.Windows.Forms.ToolStripButton ManualButton;
        private System.Windows.Forms.ToolStripButton SimRunButton;
        private System.Windows.Forms.CheckBox CalcNeBox;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.CheckBox LinkageBurrowsTestBox;
        private System.Windows.Forms.CheckBox LinkageFisherTestBox;
        private System.Windows.Forms.GroupBox GroupBoxNe;
        private System.Windows.Forms.CheckBox NeWaples2010Box;
        private System.Windows.Forms.CheckBox NePudovkin1996Box;
        private System.Windows.Forms.CheckBox NeNomura2008Box;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.CheckBox DiffHuang2019Box;
        private System.Windows.Forms.TabPage NePage;
        private System.Windows.Forms.GroupBox groupBox56;
        private System.Windows.Forms.TextBox NeResBox;
        private System.Windows.Forms.ComboBox NeWaplesMSBox;
        private System.Windows.Forms.NumericUpDown NeWaplesFBox;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label Label109;
        private System.Windows.Forms.ComboBox FrequencySelfingRateEstimatorBox;
        private System.Windows.Forms.ToolStripButton ModelTestButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton ExportButton;
        private System.Windows.Forms.ToolStripButton ReproduceFounderButton;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ComboBox FormatBox;
        private System.Windows.Forms.ToolStripButton SaveOrdinationButton;
        private System.Windows.Forms.ToolStripButton SaveClusteringButton;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox OrdinationFontSizeBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox OrdinationStyleBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripTextBox OrdinationMarkerBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel8;
        private System.Windows.Forms.ToolStripTextBox OrdinationMarkerSizeBox;
        private System.Windows.Forms.ToolStrip StructureToolStrip;
        private System.Windows.Forms.ToolStripLabel toolStripLabel9;
        private System.Windows.Forms.ToolStripComboBox StructureRearrangeColorBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel13;
        private System.Windows.Forms.ToolStripComboBox StructureIndividualOrderBox;
        private System.Windows.Forms.ToolStripButton SaveStructureButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripLabel toolStripLabel15;
        private System.Windows.Forms.ToolStripTextBox ClusteringFontSizeBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel14;
        private System.Windows.Forms.ToolStripTextBox ClusteringLineSepBox;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.GroupBox GroupBoxHeritability;
        private System.Windows.Forms.CheckBox HeritabilityMousseau1998Box;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox HeritabilityRitland1996Box;
        private System.Windows.Forms.GroupBox GroupBoxSpatial;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SpatialDistIntervalBox;
        private System.Windows.Forms.TabPage SpatialPage;
        private System.Windows.Forms.CheckBox CalcSpatialBox;
        private System.Windows.Forms.CheckBox CalcHeritabilityBox;
        private System.Windows.Forms.CheckBox RelationshipHardy1999Box;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox OrdinationPCABox;
        private System.Windows.Forms.CheckBox OrdinationPCoABox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage HeritabilityPage;
        private System.Windows.Forms.GroupBox groupBox59;
        private System.Windows.Forms.TextBox SpatialResBox;
        private System.Windows.Forms.GroupBox groupBox60;
        private System.Windows.Forms.TextBox HeritabilityResBox;
        private System.Windows.Forms.CheckBox SpatialHaversineBox;
        private System.Windows.Forms.CheckBox HeritabilityHuangMLBox;
        private System.Windows.Forms.CheckBox HeritabilityThomas2000Box;
        private System.Windows.Forms.CheckBox HeritabilityHuangMOMBox;
        private System.Windows.Forms.CheckBox RelationshipJackknifeBox;
        private System.Windows.Forms.ComboBox SpatialDistClassBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox GlobalFoldControlBox;
        private System.Windows.Forms.Timer FoldTimer;
        private System.Windows.Forms.CheckBox HeritabilityJackknifeBox;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox InbreedingJackknifeBox;
        private System.Windows.Forms.TabPage BayesAssPage;
        private System.Windows.Forms.SplitContainer splitContainer17;
        private System.Windows.Forms.SplitContainer splitContainer18;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ListView BayesAssResultFileBox;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ListView BayesAssRunListBox;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.SplitContainer splitContainer19;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.PictureBox BayesAssPicBox;
        private System.Windows.Forms.ToolStrip BayesAssToolStrip;
        private System.Windows.Forms.ToolStripButton SaveBayesAssButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripLabel toolStripLabel16;
        private System.Windows.Forms.ToolStripComboBox BayesAssPlotStyleBox;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox BayesAssRunDetailBox;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.GroupBox GroupBoxBayesAss;
        private System.Windows.Forms.NumericUpDown BayesAssNThinningBox;
        private System.Windows.Forms.NumericUpDown BayesAssBurninBox;
        private System.Windows.Forms.NumericUpDown BayesAssNRepsBox;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.NumericUpDown BayesAssNRunsBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ComboBox BayesAssMethodBox;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.NumericUpDown BayesAssDeltaMBox;
        private System.Windows.Forms.NumericUpDown BayesAssDeltaFBox;
        private System.Windows.Forms.NumericUpDown BayesAssDeltaABox;
        private System.Windows.Forms.CheckBox BayesAssNoLikelihoodBox;
        private System.Windows.Forms.CheckBox CalcQstBox;
        private System.Windows.Forms.CheckBox CalcBayesAssBox;
        private System.Windows.Forms.TabPage QstPage;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox QstResBox;
        private System.Windows.Forms.SplitContainer splitContainer20;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel ParametersPanel;
        private System.Windows.Forms.ToolStripButton ExportStructureButton;
        private System.Windows.Forms.ToolStripButton ExportBayesAssButton;
        private System.Windows.Forms.SaveFileDialog SaveDataDialog;
        private System.Windows.Forms.ToolStripButton PauseButton;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem genepopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem structureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polyRelatednessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spagediToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem genodiveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vCFToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        public System.Windows.Forms.FolderBrowserDialog ExportFileDialog;
        private System.Windows.Forms.CheckBox SpatialJackknifeBox;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.NumericUpDown FrequencyNrRateBox;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.CheckBox RelationshipHuangUnpubmBox;
        private System.Windows.Forms.CheckBox RelationshipHuangUnpubBox;
        private System.Windows.Forms.CheckBox InbreedingHuangUnpubBox;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.CheckBox AMOVAOutputSSBox;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripTextBox OrdinationAxesBox;
    }
}


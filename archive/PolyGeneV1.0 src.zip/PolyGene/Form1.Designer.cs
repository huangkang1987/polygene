﻿namespace PolyGene
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.TaskLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.SimPop_AlleleFrequencyBox = new System.Windows.Forms.TextBox();
            this.SimulationToolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.untilFst = new System.Windows.Forms.ToolStripButton();
            this.SimPop_FstTerminalBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.GenLabel = new System.Windows.Forms.ToolStripLabel();
            this.FstLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PhenotypeBox = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SimPop_DistBox = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.SimPop_OutputGenotypeBox = new System.Windows.Forms.CheckBox();
            this.SimPop_DioeciousBox = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SimPop_NegPCRBox = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.SimPop_SamplingRateBox = new System.Windows.Forms.NumericUpDown();
            this.SimPop_SelfingRateBox = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.SimPop_FemaleRateBox = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.BayesianADMBurninBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianDiffAlphaBox = new System.Windows.Forms.CheckBox();
            this.BayesianDiffLambdaBox = new System.Windows.Forms.CheckBox();
            this.BayesianUniformAlphaBox = new System.Windows.Forms.CheckBox();
            this.BayesianInferAlphaBox = new System.Windows.Forms.CheckBox();
            this.BayesianInferLambdaBox = new System.Windows.Forms.CheckBox();
            this.BayesianIndividualOrderBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.BayesianPicHeightBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianKmaxBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianNThinningBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianBurninBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianSeparatorWidthBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianPicWidthBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianNRepsBox = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.BayesianEpsGammaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianEpsEtaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianFPriorStdBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianEpsRBox = new System.Windows.Forms.NumericUpDown();
            this.label99 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.BayesianFStdFBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianFStdPABox = new System.Windows.Forms.NumericUpDown();
            this.BayesianFPriorMeanBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianMaxRBox = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.BayesianUpdateQBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianAlphaPrioriABox = new System.Windows.Forms.NumericUpDown();
            this.BayesianAlphaPrioriBBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianStdAlphaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianMaxAlphaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianAlpha0Box = new System.Windows.Forms.NumericUpDown();
            this.BayesianMaxLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianStdLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.BayesianLambdaBox = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.BayesianNRunsBox = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BayesianKminBox = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.BayesianRearrangeColorBox = new System.Windows.Forms.CheckBox();
            this.BayesianADMBox = new System.Windows.Forms.CheckBox();
            this.FSAMEBOX = new System.Windows.Forms.CheckBox();
            this.BayesianFmodelBox = new System.Windows.Forms.CheckBox();
            this.BayesianLOCPRIORIBox = new System.Windows.Forms.CheckBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.label98 = new System.Windows.Forms.Label();
            this.PhenotypeTestTotBox = new System.Windows.Forms.CheckBox();
            this.PhenotypeTestRegBox = new System.Windows.Forms.CheckBox();
            this.PhenotypeTestPopBox = new System.Windows.Forms.CheckBox();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.label95 = new System.Windows.Forms.Label();
            this.PCOAFontSizeBox = new System.Windows.Forms.NumericUpDown();
            this.label91 = new System.Windows.Forms.Label();
            this.PCOADimBox = new System.Windows.Forms.NumericUpDown();
            this.label90 = new System.Windows.Forms.Label();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.ClusteringWPGMABox = new System.Windows.Forms.CheckBox();
            this.ClusteringFontSizeBox = new System.Windows.Forms.NumericUpDown();
            this.ClusteringWARDBox = new System.Windows.Forms.CheckBox();
            this.ClusteringUPGMABox = new System.Windows.Forms.CheckBox();
            this.ClusteringLineSepBox = new System.Windows.Forms.NumericUpDown();
            this.ClusteringWPGMCBox = new System.Windows.Forms.CheckBox();
            this.ClusteringFurthestBox = new System.Windows.Forms.CheckBox();
            this.ClusteringUPGMCBox = new System.Windows.Forms.CheckBox();
            this.ClusteringNearestBox = new System.Windows.Forms.CheckBox();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownBox = new System.Windows.Forms.CheckBox();
            this.ParentageParentPairBox = new System.Windows.Forms.CheckBox();
            this.ParentageSkipSimBox = new System.Windows.Forms.CheckBox();
            this.ParentagePaternityBox = new System.Windows.Forms.CheckBox();
            this.label51 = new System.Windows.Forms.Label();
            this.ParentageOutputBox = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.ParentageUnknownNSimBox = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.ParentageParentPairNSimBox = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.ParentagePaternityNSimBox = new System.Windows.Forms.NumericUpDown();
            this.label74 = new System.Windows.Forms.Label();
            this.ParentageUnknownNCandidateBox = new System.Windows.Forms.NumericUpDown();
            this.label75 = new System.Windows.Forms.Label();
            this.ParentageParentPairNMotherBox = new System.Windows.Forms.NumericUpDown();
            this.ParentageParentPairNFatherBox = new System.Windows.Forms.NumericUpDown();
            this.label76 = new System.Windows.Forms.Label();
            this.ParentagePaternityNFatherBox = new System.Windows.Forms.NumericUpDown();
            this.ParentageSamplingRateBox = new System.Windows.Forms.NumericUpDown();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.ParentageMistypeRateBox = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.label88 = new System.Windows.Forms.Label();
            this.InbreedingLoiselle1995Box = new System.Windows.Forms.CheckBox();
            this.InbreedingRitland1996Box = new System.Windows.Forms.CheckBox();
            this.InbreedingWeir1996Box = new System.Windows.Forms.CheckBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.CalcParentageBox = new System.Windows.Forms.CheckBox();
            this.CalcAMOVABox = new System.Windows.Forms.CheckBox();
            this.CalcDistBox = new System.Windows.Forms.CheckBox();
            this.CalcClusteringBox = new System.Windows.Forms.CheckBox();
            this.CalcPCoABox = new System.Windows.Forms.CheckBox();
            this.CalcBayesianBox = new System.Windows.Forms.CheckBox();
            this.CalcRelatednessBox = new System.Windows.Forms.CheckBox();
            this.CalcAssignmentBox = new System.Windows.Forms.CheckBox();
            this.CalcHIndexBox = new System.Windows.Forms.CheckBox();
            this.CalcInbreedingBox = new System.Windows.Forms.CheckBox();
            this.CalcPhenotypeBox = new System.Windows.Forms.CheckBox();
            this.CalcDiffBox = new System.Windows.Forms.CheckBox();
            this.CalcLinkageBox = new System.Windows.Forms.CheckBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.RelatednessRegBox = new System.Windows.Forms.CheckBox();
            this.RelatednessPopBox = new System.Windows.Forms.CheckBox();
            this.RelatednessLoiselle1995Box = new System.Windows.Forms.CheckBox();
            this.RelatednessRitland1996Box = new System.Windows.Forms.CheckBox();
            this.RelatednessHuang2015Box = new System.Windows.Forms.CheckBox();
            this.RelatednessLoiselle1995mBox = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.RelatednessWeir1996Box = new System.Windows.Forms.CheckBox();
            this.RelatednessHuang2014Box = new System.Windows.Forms.CheckBox();
            this.RelatednessRitland1996mBox = new System.Windows.Forms.CheckBox();
            this.RelatednessTotBox = new System.Windows.Forms.CheckBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.GlobalNullAlleleBox = new System.Windows.Forms.NumericUpDown();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.GlobalSeedBox = new System.Windows.Forms.NumericUpDown();
            this.GlobalThreadBox = new System.Windows.Forms.NumericUpDown();
            this.GlobalRefreshSeedBox = new System.Windows.Forms.CheckBox();
            this.GlobalWarningBox = new System.Windows.Forms.CheckBox();
            this.label45 = new System.Windows.Forms.Label();
            this.GlobalDecimalPlaceBox = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.LinkageIterationsBox = new System.Windows.Forms.NumericUpDown();
            this.LinkageBurninBox = new System.Windows.Forms.NumericUpDown();
            this.LinkageBatchesBox = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.LinkageTestTotBox = new System.Windows.Forms.CheckBox();
            this.LinkageTestPermBox = new System.Windows.Forms.CheckBox();
            this.LinkageTestRegBox = new System.Windows.Forms.CheckBox();
            this.LinkageTestPopBox = new System.Windows.Forms.CheckBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.FrequencyRemoveDupAlleleBox = new System.Windows.Forms.CheckBox();
            this.FrequencySelfingBox = new System.Windows.Forms.CheckBox();
            this.FrequencyNegPCRBox = new System.Windows.Forms.CheckBox();
            this.FrequencyNullAlleleBox = new System.Windows.Forms.CheckBox();
            this.FrequencyGenotypicModeBox = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.DistRegBox = new System.Windows.Forms.CheckBox();
            this.DistPopBox = new System.Windows.Forms.CheckBox();
            this.DistIndBox = new System.Windows.Forms.CheckBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.DistSlatkinBox = new System.Windows.Forms.CheckBox();
            this.DistRoger1973Box = new System.Windows.Forms.CheckBox();
            this.DistNei1983Box = new System.Windows.Forms.CheckBox();
            this.DistReynolds1983Box = new System.Windows.Forms.CheckBox();
            this.DistNei1973Box = new System.Windows.Forms.CheckBox();
            this.DistReynold1993Box = new System.Windows.Forms.CheckBox();
            this.DistGoldstein1995Box = new System.Windows.Forms.CheckBox();
            this.DistCavalli1967Box = new System.Windows.Forms.CheckBox();
            this.DistEuclideanBox = new System.Windows.Forms.CheckBox();
            this.DistNei1972Box = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.AMOVAMLBox = new System.Windows.Forms.CheckBox();
            this.AMOVAGenotypeBox = new System.Windows.Forms.CheckBox();
            this.AMOVAAnisoBox = new System.Windows.Forms.CheckBox();
            this.AMOVAHomoBox = new System.Windows.Forms.CheckBox();
            this.AMOVASMMBox = new System.Windows.Forms.CheckBox();
            this.AMOVAIAMBox = new System.Windows.Forms.CheckBox();
            this.AMOVAIgnoreIndBox = new System.Windows.Forms.CheckBox();
            this.AMOVARegionBox = new System.Windows.Forms.TextBox();
            this.AMOVANPermBox = new System.Windows.Forms.NumericUpDown();
            this.label102 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.AssignmentErrorBox = new System.Windows.Forms.NumericUpDown();
            this.AssignmentPloidyBox = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label87 = new System.Windows.Forms.Label();
            this.DiffRegBox = new System.Windows.Forms.CheckBox();
            this.DiffTotBox = new System.Windows.Forms.CheckBox();
            this.DiffPopBox = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.DiffIterationsBox = new System.Windows.Forms.NumericUpDown();
            this.DiffBurninBox = new System.Windows.Forms.NumericUpDown();
            this.DiffBatchesBox = new System.Windows.Forms.NumericUpDown();
            this.label83 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.DiffJost2008Box = new System.Windows.Forms.CheckBox();
            this.DiffHedrick2005Box = new System.Windows.Forms.CheckBox();
            this.DiffHudson1992Box = new System.Windows.Forms.CheckBox();
            this.DiffTestPermBox = new System.Windows.Forms.CheckBox();
            this.DiffTestAlleleBox = new System.Windows.Forms.CheckBox();
            this.DiffNei1973Box = new System.Windows.Forms.CheckBox();
            this.DiffTestPhenoBox = new System.Windows.Forms.CheckBox();
            this.DiffHuang2018SMMBox = new System.Windows.Forms.CheckBox();
            this.DiffSlatkin1995Box = new System.Windows.Forms.CheckBox();
            this.DiffHuang2018IAMBox = new System.Windows.Forms.CheckBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.DiversityResBox = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FrequencyResBox = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.PhenotypeResBox = new System.Windows.Forms.TextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.LinkageResBox = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DiffResBox = new System.Windows.Forms.TextBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.DistResBox = new System.Windows.Forms.TextBox();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.PCoAPicBox = new System.Windows.Forms.PictureBox();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.PCoAComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.PCoAResBox = new System.Windows.Forms.TextBox();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.splitContainer16 = new System.Windows.Forms.SplitContainer();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ClusteringPicBox = new System.Windows.Forms.PictureBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.ClusteringComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.ClusteringResBox = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.InbreedingResBox = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.HIndexResBox = new System.Windows.Forms.TextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.AssignmentResBox = new System.Windows.Forms.TextBox();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.RelatednessResBox = new System.Windows.Forms.TextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.label53 = new System.Windows.Forms.Label();
            this.D2_95 = new System.Windows.Forms.NumericUpDown();
            this.label54 = new System.Windows.Forms.Label();
            this.D2_99 = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.D2_999 = new System.Windows.Forms.NumericUpDown();
            this.D2_80 = new System.Windows.Forms.NumericUpDown();
            this.label56 = new System.Windows.Forms.Label();
            this.D1_95 = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.D1_99 = new System.Windows.Forms.NumericUpDown();
            this.DPM_95 = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.D1_999 = new System.Windows.Forms.NumericUpDown();
            this.label60 = new System.Windows.Forms.Label();
            this.DPF_95 = new System.Windows.Forms.NumericUpDown();
            this.label61 = new System.Windows.Forms.Label();
            this.DPM_99 = new System.Windows.Forms.NumericUpDown();
            this.label62 = new System.Windows.Forms.Label();
            this.DPF_99 = new System.Windows.Forms.NumericUpDown();
            this.label63 = new System.Windows.Forms.Label();
            this.DPM_999 = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.DPF_999 = new System.Windows.Forms.NumericUpDown();
            this.DPS_80 = new System.Windows.Forms.NumericUpDown();
            this.DP_95 = new System.Windows.Forms.NumericUpDown();
            this.DP_80 = new System.Windows.Forms.NumericUpDown();
            this.DP_99 = new System.Windows.Forms.NumericUpDown();
            this.DPS_999 = new System.Windows.Forms.NumericUpDown();
            this.DPS_95 = new System.Windows.Forms.NumericUpDown();
            this.DPF_80 = new System.Windows.Forms.NumericUpDown();
            this.DP_999 = new System.Windows.Forms.NumericUpDown();
            this.DPM_80 = new System.Windows.Forms.NumericUpDown();
            this.DPS_99 = new System.Windows.Forms.NumericUpDown();
            this.D1_80 = new System.Windows.Forms.NumericUpDown();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.ParentageSimResBox = new System.Windows.Forms.TextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.ParentagePaternityOffspringBox = new System.Windows.Forms.TextBox();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.ParentagePaternityResBox = new System.Windows.Forms.TextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairOffspringBox = new System.Windows.Forms.TextBox();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairMotherBox = new System.Windows.Forms.TextBox();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairFatherBox = new System.Windows.Forms.TextBox();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.ParentageParentPairResBox = new System.Windows.Forms.TextBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownOffspringBox = new System.Windows.Forms.TextBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownParentBox = new System.Windows.Forms.TextBox();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.ParentageUnknownResBox = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.AMOVAResBox = new System.Windows.Forms.TextBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.BayesianResultBox = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.BayesianResultExplorerBox = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.BayesianPicBox = new System.Windows.Forms.PictureBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.BayesianSummaryBox = new System.Windows.Forms.TextBox();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.MantelNPermBOx = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.MantelResBox = new System.Windows.Forms.TextBox();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.MantelMatBox = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.savePictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).BeginInit();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SimulationToolStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_NegPCRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SamplingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SelfingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_FemaleRateBox)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianADMBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicHeightBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianKmaxBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNThinningBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianSeparatorWidthBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicWidthBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNRepsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsGammaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsEtaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFPriorStdBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFStdFBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFStdPABox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFPriorMeanBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxRBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianUpdateQBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlphaPrioriABox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlphaPrioriBBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianStdAlphaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxAlphaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlpha0Box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianStdLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianLambdaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNRunsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianKminBox)).BeginInit();
            this.groupBox33.SuspendLayout();
            this.groupBox50.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PCOAFontSizeBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PCOADimBox)).BeginInit();
            this.groupBox48.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringFontSizeBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringLineSepBox)).BeginInit();
            this.groupBox35.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNSimBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNSimBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNSimBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNCandidateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNMotherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNFatherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNFatherBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageSamplingRateBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageMistypeRateBox)).BeginInit();
            this.groupBox34.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalNullAlleleBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalSeedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalThreadBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalDecimalPlaceBox)).BeginInit();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageIterationsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBatchesBox)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AMOVANPermBox)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentErrorBox)).BeginInit();
            this.groupBox23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiffIterationsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBurninBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBatchesBox)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).BeginInit();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PCoAPicBox)).BeginInit();
            this.toolStrip3.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).BeginInit();
            this.splitContainer16.Panel1.SuspendLayout();
            this.splitContainer16.Panel2.SuspendLayout();
            this.splitContainer16.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringPicBox)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            this.groupBox45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.D2_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_999)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_80)).BeginInit();
            this.groupBox46.SuspendLayout();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.groupBox40.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).BeginInit();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicBox)).BeginInit();
            this.groupBox27.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.groupBox31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MantelNPermBOx)).BeginInit();
            this.groupBox30.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripLabel1,
            this.toolStripSeparator4,
            this.toolStripLabel3,
            this.toolStripLabel2,
            this.toolStripSeparator2,
            this.toolStripProgressBar1,
            this.TaskLabel,
            this.toolStripButton11,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripButton14});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1884, 38);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(41, 35);
            this.toolStripButton1.Text = "&Calc";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(47, 35);
            this.toolStripLabel1.Text = "&Abort";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 38);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(50, 35);
            this.toolStripLabel3.Text = "A&bout";
            this.toolStripLabel3.Click += new System.EventHandler(this.toolStripLabel3_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(58, 35);
            this.toolStripLabel2.Text = "&Manual";
            this.toolStripLabel2.Click += new System.EventHandler(this.toolStripLabel2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(400, 35);
            // 
            // TaskLabel
            // 
            this.TaskLabel.Name = "TaskLabel";
            this.TaskLabel.Size = new System.Drawing.Size(0, 35);
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Size = new System.Drawing.Size(28, 35);
            this.toolStripButton11.Text = "toolStripButton11";
            this.toolStripButton11.Visible = false;
            this.toolStripButton11.Click += new System.EventHandler(this.toolStripButton11_Click);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(28, 35);
            this.toolStripButton12.Text = "Summary";
            this.toolStripButton12.Visible = false;
            this.toolStripButton12.Click += new System.EventHandler(this.toolStripButton12_Click);
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Size = new System.Drawing.Size(28, 35);
            this.toolStripButton13.Text = "toolStripButton13";
            this.toolStripButton13.Visible = false;
            this.toolStripButton13.Click += new System.EventHandler(this.toolStripButton13_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage21);
            this.tabControl1.Controls.Add(this.tabPage22);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage16);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage15);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.tabControl1.Location = new System.Drawing.Point(0, 38);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1884, 986);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer14);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1876, 953);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Input";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer14
            // 
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer14.Location = new System.Drawing.Point(4, 4);
            this.splitContainer14.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer14.Name = "splitContainer14";
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.splitContainer8);
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.groupBox14);
            this.splitContainer14.Size = new System.Drawing.Size(1868, 945);
            this.splitContainer14.SplitterDistance = 1674;
            this.splitContainer14.SplitterWidth = 5;
            this.splitContainer14.TabIndex = 3;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.groupBox8);
            this.splitContainer8.Panel1.Controls.Add(this.SimulationToolStrip);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer8.Size = new System.Drawing.Size(1674, 945);
            this.splitContainer8.SplitterDistance = 319;
            this.splitContainer8.SplitterWidth = 5;
            this.splitContainer8.TabIndex = 2;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.SimPop_AlleleFrequencyBox);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(0, 28);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(1674, 291);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Simulation: Population and allele frequencies";
            // 
            // SimPop_AlleleFrequencyBox
            // 
            this.SimPop_AlleleFrequencyBox.AcceptsReturn = true;
            this.SimPop_AlleleFrequencyBox.AcceptsTab = true;
            this.SimPop_AlleleFrequencyBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SimPop_AlleleFrequencyBox.HideSelection = false;
            this.SimPop_AlleleFrequencyBox.Location = new System.Drawing.Point(4, 24);
            this.SimPop_AlleleFrequencyBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_AlleleFrequencyBox.MaxLength = 32767000;
            this.SimPop_AlleleFrequencyBox.Multiline = true;
            this.SimPop_AlleleFrequencyBox.Name = "SimPop_AlleleFrequencyBox";
            this.SimPop_AlleleFrequencyBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SimPop_AlleleFrequencyBox.Size = new System.Drawing.Size(1666, 263);
            this.SimPop_AlleleFrequencyBox.TabIndex = 2;
            this.SimPop_AlleleFrequencyBox.Text = resources.GetString("SimPop_AlleleFrequencyBox.Text");
            this.SimPop_AlleleFrequencyBox.WordWrap = false;
            this.SimPop_AlleleFrequencyBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimulationToolStrip
            // 
            this.SimulationToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.SimulationToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripSeparator3,
            this.toolStripLabel4,
            this.toolStripButton18,
            this.toolStripButton20,
            this.toolStripButton19,
            this.toolStripButton22,
            this.untilFst,
            this.SimPop_FstTerminalBox,
            this.toolStripSeparator1,
            this.GenLabel,
            this.FstLabel,
            this.toolStripSeparator10,
            this.toolStripLabel5,
            this.toolStripButton2,
            this.toolStripButton5,
            this.toolStripButton9,
            this.toolStripButton10});
            this.SimulationToolStrip.Location = new System.Drawing.Point(0, 0);
            this.SimulationToolStrip.Name = "SimulationToolStrip";
            this.SimulationToolStrip.Size = new System.Drawing.Size(1674, 28);
            this.SimulationToolStrip.TabIndex = 0;
            this.SimulationToolStrip.Text = "toolStrip2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(67, 25);
            this.toolStripButton3.Text = "&Founder";
            this.toolStripButton3.Click += new System.EventHandler(this.GenerageFounderPopulation);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(88, 25);
            this.toolStripLabel4.Text = "Reproduce: ";
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton18.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton18.Image")));
            this.toolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.Size = new System.Drawing.Size(23, 25);
            this.toolStripButton18.Text = "1";
            this.toolStripButton18.Click += new System.EventHandler(this.Reproduce);
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.Size = new System.Drawing.Size(29, 25);
            this.toolStripButton20.Text = "10";
            this.toolStripButton20.Click += new System.EventHandler(this.Reproduce);
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton19.Image")));
            this.toolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.Size = new System.Drawing.Size(37, 25);
            this.toolStripButton19.Text = "100";
            this.toolStripButton19.Click += new System.EventHandler(this.Reproduce);
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.Size = new System.Drawing.Size(45, 25);
            this.toolStripButton22.Text = "1000";
            this.toolStripButton22.Click += new System.EventHandler(this.Reproduce);
            // 
            // untilFst
            // 
            this.untilFst.BackColor = System.Drawing.Color.Cornsilk;
            this.untilFst.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.untilFst.Image = ((System.Drawing.Image)(resources.GetObject("untilFst.Image")));
            this.untilFst.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.untilFst.Name = "untilFst";
            this.untilFst.Size = new System.Drawing.Size(82, 25);
            this.untilFst.Text = "until Fst = ";
            this.untilFst.Click += new System.EventHandler(this.untilFst_Click);
            // 
            // SimPop_FstTerminalBox
            // 
            this.SimPop_FstTerminalBox.Items.AddRange(new object[] {
            "0.01",
            "0.02",
            "0.05",
            "0.07",
            "0.10",
            "0.12",
            "0.15"});
            this.SimPop_FstTerminalBox.Name = "SimPop_FstTerminalBox";
            this.SimPop_FstTerminalBox.Size = new System.Drawing.Size(99, 28);
            this.SimPop_FstTerminalBox.Text = "0.05";
            this.SimPop_FstTerminalBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // GenLabel
            // 
            this.GenLabel.Name = "GenLabel";
            this.GenLabel.Size = new System.Drawing.Size(89, 25);
            this.GenLabel.Text = "Generation: ";
            this.GenLabel.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FstLabel
            // 
            this.FstLabel.Name = "FstLabel";
            this.FstLabel.Size = new System.Drawing.Size(34, 25);
            this.FstLabel.Text = "Fst: ";
            this.FstLabel.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(90, 25);
            this.toolStripLabel5.Text = "Import from";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(74, 25);
            this.toolStripButton2.Text = "Genepop";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(72, 25);
            this.toolStripButton5.Text = "Structure";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(119, 25);
            this.toolStripButton9.Text = "PolyRelatedness";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.BackColor = System.Drawing.Color.Cornsilk;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(68, 25);
            this.toolStripButton10.Text = "Spagedi";
            this.toolStripButton10.Click += new System.EventHandler(this.toolStripButton10_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PhenotypeBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1674, 621);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Phenotypes/Genotypes";
            // 
            // PhenotypeBox
            // 
            this.PhenotypeBox.AcceptsReturn = true;
            this.PhenotypeBox.AcceptsTab = true;
            this.PhenotypeBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PhenotypeBox.HideSelection = false;
            this.PhenotypeBox.Location = new System.Drawing.Point(4, 24);
            this.PhenotypeBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhenotypeBox.MaxLength = 134217728;
            this.PhenotypeBox.Multiline = true;
            this.PhenotypeBox.Name = "PhenotypeBox";
            this.PhenotypeBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PhenotypeBox.Size = new System.Drawing.Size(1666, 593);
            this.PhenotypeBox.TabIndex = 0;
            this.PhenotypeBox.WordWrap = false;
            this.PhenotypeBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button1);
            this.groupBox14.Controls.Add(this.SimPop_DistBox);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.label42);
            this.groupBox14.Controls.Add(this.SimPop_OutputGenotypeBox);
            this.groupBox14.Controls.Add(this.SimPop_DioeciousBox);
            this.groupBox14.Controls.Add(this.label1);
            this.groupBox14.Controls.Add(this.SimPop_NegPCRBox);
            this.groupBox14.Controls.Add(this.label37);
            this.groupBox14.Controls.Add(this.SimPop_SamplingRateBox);
            this.groupBox14.Controls.Add(this.SimPop_SelfingRateBox);
            this.groupBox14.Controls.Add(this.label36);
            this.groupBox14.Controls.Add(this.SimPop_FemaleRateBox);
            this.groupBox14.Controls.Add(this.label39);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(0, 0);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(189, 945);
            this.groupBox14.TabIndex = 2;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Simulation parameters";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 725);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 404;
            this.button1.Text = "Randomize";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SimPop_DistBox
            // 
            this.SimPop_DistBox.AcceptsReturn = true;
            this.SimPop_DistBox.HideSelection = false;
            this.SimPop_DistBox.Location = new System.Drawing.Point(27, 332);
            this.SimPop_DistBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_DistBox.Multiline = true;
            this.SimPop_DistBox.Name = "SimPop_DistBox";
            this.SimPop_DistBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SimPop_DistBox.Size = new System.Drawing.Size(143, 342);
            this.SimPop_DistBox.TabIndex = 403;
            this.SimPop_DistBox.Text = "25\r\n25\r\n25\r\n25\r\n25\r\n25";
            this.SimPop_DistBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(23, 679);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(163, 40);
            this.label46.TabIndex = 402;
            this.label46.Text = "Extra locus would be \r\nequal to the first";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 288);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(156, 40);
            this.label42.TabIndex = 402;
            this.label42.Text = "Distance from locus \r\nto centromere (cM)";
            // 
            // SimPop_OutputGenotypeBox
            // 
            this.SimPop_OutputGenotypeBox.AutoSize = true;
            this.SimPop_OutputGenotypeBox.Location = new System.Drawing.Point(15, 761);
            this.SimPop_OutputGenotypeBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_OutputGenotypeBox.Name = "SimPop_OutputGenotypeBox";
            this.SimPop_OutputGenotypeBox.Size = new System.Drawing.Size(158, 24);
            this.SimPop_OutputGenotypeBox.TabIndex = 203;
            this.SimPop_OutputGenotypeBox.Text = "Output genotype";
            this.SimPop_OutputGenotypeBox.UseVisualStyleBackColor = true;
            this.SimPop_OutputGenotypeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimPop_DioeciousBox
            // 
            this.SimPop_DioeciousBox.AutoSize = true;
            this.SimPop_DioeciousBox.Location = new System.Drawing.Point(16, 28);
            this.SimPop_DioeciousBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_DioeciousBox.Name = "SimPop_DioeciousBox";
            this.SimPop_DioeciousBox.Size = new System.Drawing.Size(103, 24);
            this.SimPop_DioeciousBox.TabIndex = 200;
            this.SimPop_DioeciousBox.Text = "Dioecious";
            this.SimPop_DioeciousBox.UseVisualStyleBackColor = true;
            this.SimPop_DioeciousBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 226);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Negative PCR rate";
            // 
            // SimPop_NegPCRBox
            // 
            this.SimPop_NegPCRBox.DecimalPlaces = 4;
            this.SimPop_NegPCRBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_NegPCRBox.Location = new System.Drawing.Point(40, 250);
            this.SimPop_NegPCRBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_NegPCRBox.Name = "SimPop_NegPCRBox";
            this.SimPop_NegPCRBox.Size = new System.Drawing.Size(129, 27);
            this.SimPop_NegPCRBox.TabIndex = 205;
            this.SimPop_NegPCRBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimPop_NegPCRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(11, 170);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(110, 20);
            this.label37.TabIndex = 0;
            this.label37.Text = "Sampling rate\r\n";
            // 
            // SimPop_SamplingRateBox
            // 
            this.SimPop_SamplingRateBox.DecimalPlaces = 4;
            this.SimPop_SamplingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SamplingRateBox.Location = new System.Drawing.Point(40, 194);
            this.SimPop_SamplingRateBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_SamplingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimPop_SamplingRateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SamplingRateBox.Name = "SimPop_SamplingRateBox";
            this.SimPop_SamplingRateBox.Size = new System.Drawing.Size(129, 27);
            this.SimPop_SamplingRateBox.TabIndex = 205;
            this.SimPop_SamplingRateBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.SimPop_SamplingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // SimPop_SelfingRateBox
            // 
            this.SimPop_SelfingRateBox.DecimalPlaces = 4;
            this.SimPop_SelfingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_SelfingRateBox.Location = new System.Drawing.Point(40, 138);
            this.SimPop_SelfingRateBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_SelfingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.SimPop_SelfingRateBox.Name = "SimPop_SelfingRateBox";
            this.SimPop_SelfingRateBox.Size = new System.Drawing.Size(129, 27);
            this.SimPop_SelfingRateBox.TabIndex = 202;
            this.SimPop_SelfingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(11, 114);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(92, 20);
            this.label36.TabIndex = 0;
            this.label36.Text = "Selfing rate";
            // 
            // SimPop_FemaleRateBox
            // 
            this.SimPop_FemaleRateBox.DecimalPlaces = 4;
            this.SimPop_FemaleRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Location = new System.Drawing.Point(40, 81);
            this.SimPop_FemaleRateBox.Margin = new System.Windows.Forms.Padding(4);
            this.SimPop_FemaleRateBox.Maximum = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.SimPop_FemaleRateBox.Name = "SimPop_FemaleRateBox";
            this.SimPop_FemaleRateBox.Size = new System.Drawing.Size(129, 27);
            this.SimPop_FemaleRateBox.TabIndex = 201;
            this.SimPop_FemaleRateBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.SimPop_FemaleRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(11, 58);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(94, 20);
            this.label39.TabIndex = 0;
            this.label39.Text = "Female rate";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1876, 953);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Parameters";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.panel1);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupBox9.Location = new System.Drawing.Point(4, 4);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(1868, 945);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Parameters";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.groupBox28);
            this.panel1.Controls.Add(this.groupBox33);
            this.panel1.Controls.Add(this.groupBox50);
            this.panel1.Controls.Add(this.groupBox48);
            this.panel1.Controls.Add(this.groupBox35);
            this.panel1.Controls.Add(this.groupBox34);
            this.panel1.Controls.Add(this.groupBox21);
            this.panel1.Controls.Add(this.groupBox18);
            this.panel1.Controls.Add(this.groupBox13);
            this.panel1.Controls.Add(this.groupBox20);
            this.panel1.Controls.Add(this.groupBox15);
            this.panel1.Controls.Add(this.groupBox24);
            this.panel1.Controls.Add(this.groupBox7);
            this.panel1.Controls.Add(this.groupBox16);
            this.panel1.Controls.Add(this.groupBox23);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 24);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1860, 917);
            this.panel1.TabIndex = 7;
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.BayesianADMBurninBox);
            this.groupBox28.Controls.Add(this.BayesianDiffAlphaBox);
            this.groupBox28.Controls.Add(this.BayesianDiffLambdaBox);
            this.groupBox28.Controls.Add(this.BayesianUniformAlphaBox);
            this.groupBox28.Controls.Add(this.BayesianInferAlphaBox);
            this.groupBox28.Controls.Add(this.BayesianInferLambdaBox);
            this.groupBox28.Controls.Add(this.BayesianIndividualOrderBox);
            this.groupBox28.Controls.Add(this.label17);
            this.groupBox28.Controls.Add(this.BayesianPicHeightBox);
            this.groupBox28.Controls.Add(this.BayesianKmaxBox);
            this.groupBox28.Controls.Add(this.BayesianNThinningBox);
            this.groupBox28.Controls.Add(this.BayesianBurninBox);
            this.groupBox28.Controls.Add(this.BayesianSeparatorWidthBox);
            this.groupBox28.Controls.Add(this.BayesianPicWidthBox);
            this.groupBox28.Controls.Add(this.BayesianNRepsBox);
            this.groupBox28.Controls.Add(this.label26);
            this.groupBox28.Controls.Add(this.label25);
            this.groupBox28.Controls.Add(this.label34);
            this.groupBox28.Controls.Add(this.label24);
            this.groupBox28.Controls.Add(this.label41);
            this.groupBox28.Controls.Add(this.label35);
            this.groupBox28.Controls.Add(this.label33);
            this.groupBox28.Controls.Add(this.label23);
            this.groupBox28.Controls.Add(this.label49);
            this.groupBox28.Controls.Add(this.label100);
            this.groupBox28.Controls.Add(this.label22);
            this.groupBox28.Controls.Add(this.BayesianEpsGammaBox);
            this.groupBox28.Controls.Add(this.BayesianEpsEtaBox);
            this.groupBox28.Controls.Add(this.BayesianFPriorStdBox);
            this.groupBox28.Controls.Add(this.BayesianEpsRBox);
            this.groupBox28.Controls.Add(this.label99);
            this.groupBox28.Controls.Add(this.label48);
            this.groupBox28.Controls.Add(this.label21);
            this.groupBox28.Controls.Add(this.BayesianFStdFBox);
            this.groupBox28.Controls.Add(this.BayesianFStdPABox);
            this.groupBox28.Controls.Add(this.BayesianFPriorMeanBox);
            this.groupBox28.Controls.Add(this.BayesianMaxRBox);
            this.groupBox28.Controls.Add(this.label47);
            this.groupBox28.Controls.Add(this.label97);
            this.groupBox28.Controls.Add(this.label96);
            this.groupBox28.Controls.Add(this.label19);
            this.groupBox28.Controls.Add(this.BayesianUpdateQBox);
            this.groupBox28.Controls.Add(this.BayesianAlphaPrioriABox);
            this.groupBox28.Controls.Add(this.BayesianAlphaPrioriBBox);
            this.groupBox28.Controls.Add(this.BayesianStdAlphaBox);
            this.groupBox28.Controls.Add(this.BayesianMaxAlphaBox);
            this.groupBox28.Controls.Add(this.BayesianAlpha0Box);
            this.groupBox28.Controls.Add(this.BayesianMaxLambdaBox);
            this.groupBox28.Controls.Add(this.BayesianStdLambdaBox);
            this.groupBox28.Controls.Add(this.BayesianLambdaBox);
            this.groupBox28.Controls.Add(this.label15);
            this.groupBox28.Controls.Add(this.BayesianNRunsBox);
            this.groupBox28.Controls.Add(this.label16);
            this.groupBox28.Controls.Add(this.label6);
            this.groupBox28.Controls.Add(this.BayesianKminBox);
            this.groupBox28.Controls.Add(this.label18);
            this.groupBox28.Controls.Add(this.label27);
            this.groupBox28.Controls.Add(this.label5);
            this.groupBox28.Controls.Add(this.label32);
            this.groupBox28.Controls.Add(this.label31);
            this.groupBox28.Controls.Add(this.label30);
            this.groupBox28.Controls.Add(this.label29);
            this.groupBox28.Controls.Add(this.label28);
            this.groupBox28.Controls.Add(this.label14);
            this.groupBox28.Controls.Add(this.label12);
            this.groupBox28.Controls.Add(this.label13);
            this.groupBox28.Controls.Add(this.label11);
            this.groupBox28.Controls.Add(this.BayesianRearrangeColorBox);
            this.groupBox28.Controls.Add(this.BayesianADMBox);
            this.groupBox28.Controls.Add(this.FSAMEBOX);
            this.groupBox28.Controls.Add(this.BayesianFmodelBox);
            this.groupBox28.Controls.Add(this.BayesianLOCPRIORIBox);
            this.groupBox28.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox28.Location = new System.Drawing.Point(1441, 4);
            this.groupBox28.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox28.Size = new System.Drawing.Size(408, 914);
            this.groupBox28.TabIndex = 6;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Bayesian clustering";
            // 
            // BayesianADMBurninBox
            // 
            this.BayesianADMBurninBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianADMBurninBox.Location = new System.Drawing.Point(301, 305);
            this.BayesianADMBurninBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianADMBurninBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianADMBurninBox.Name = "BayesianADMBurninBox";
            this.BayesianADMBurninBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianADMBurninBox.TabIndex = 508;
            this.BayesianADMBurninBox.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.BayesianADMBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianDiffAlphaBox
            // 
            this.BayesianDiffAlphaBox.AutoSize = true;
            this.BayesianDiffAlphaBox.Location = new System.Drawing.Point(155, 465);
            this.BayesianDiffAlphaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianDiffAlphaBox.Name = "BayesianDiffAlphaBox";
            this.BayesianDiffAlphaBox.Size = new System.Drawing.Size(70, 24);
            this.BayesianDiffAlphaBox.TabIndex = 511;
            this.BayesianDiffAlphaBox.Text = "Diff α";
            this.BayesianDiffAlphaBox.UseVisualStyleBackColor = true;
            // 
            // BayesianDiffLambdaBox
            // 
            this.BayesianDiffLambdaBox.AutoSize = true;
            this.BayesianDiffLambdaBox.Location = new System.Drawing.Point(153, 338);
            this.BayesianDiffLambdaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianDiffLambdaBox.Name = "BayesianDiffLambdaBox";
            this.BayesianDiffLambdaBox.Size = new System.Drawing.Size(68, 24);
            this.BayesianDiffLambdaBox.TabIndex = 511;
            this.BayesianDiffLambdaBox.Text = "Diff λ";
            this.BayesianDiffLambdaBox.UseVisualStyleBackColor = true;
            // 
            // BayesianUniformAlphaBox
            // 
            this.BayesianUniformAlphaBox.AutoSize = true;
            this.BayesianUniformAlphaBox.Location = new System.Drawing.Point(277, 465);
            this.BayesianUniformAlphaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianUniformAlphaBox.Name = "BayesianUniformAlphaBox";
            this.BayesianUniformAlphaBox.Size = new System.Drawing.Size(104, 24);
            this.BayesianUniformAlphaBox.TabIndex = 511;
            this.BayesianUniformAlphaBox.Text = "Uniform α";
            this.BayesianUniformAlphaBox.UseVisualStyleBackColor = true;
            // 
            // BayesianInferAlphaBox
            // 
            this.BayesianInferAlphaBox.AutoSize = true;
            this.BayesianInferAlphaBox.Location = new System.Drawing.Point(24, 465);
            this.BayesianInferAlphaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianInferAlphaBox.Name = "BayesianInferAlphaBox";
            this.BayesianInferAlphaBox.Size = new System.Drawing.Size(78, 24);
            this.BayesianInferAlphaBox.TabIndex = 511;
            this.BayesianInferAlphaBox.Text = "Infer α";
            this.BayesianInferAlphaBox.UseVisualStyleBackColor = true;
            // 
            // BayesianInferLambdaBox
            // 
            this.BayesianInferLambdaBox.AutoSize = true;
            this.BayesianInferLambdaBox.Location = new System.Drawing.Point(24, 339);
            this.BayesianInferLambdaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianInferLambdaBox.Name = "BayesianInferLambdaBox";
            this.BayesianInferLambdaBox.Size = new System.Drawing.Size(76, 24);
            this.BayesianInferLambdaBox.TabIndex = 511;
            this.BayesianInferLambdaBox.Text = "Infer λ";
            this.BayesianInferLambdaBox.UseVisualStyleBackColor = true;
            // 
            // BayesianIndividualOrderBox
            // 
            this.BayesianIndividualOrderBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BayesianIndividualOrderBox.FormattingEnabled = true;
            this.BayesianIndividualOrderBox.Items.AddRange(new object[] {
            "Original",
            "By populations",
            "By Z or Q"});
            this.BayesianIndividualOrderBox.Location = new System.Drawing.Point(179, 872);
            this.BayesianIndividualOrderBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianIndividualOrderBox.Name = "BayesianIndividualOrderBox";
            this.BayesianIndividualOrderBox.Size = new System.Drawing.Size(204, 28);
            this.BayesianIndividualOrderBox.TabIndex = 510;
            this.BayesianIndividualOrderBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 876);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 20);
            this.label17.TabIndex = 509;
            this.label17.Text = "Individual order";
            // 
            // BayesianPicHeightBox
            // 
            this.BayesianPicHeightBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.BayesianPicHeightBox.Location = new System.Drawing.Point(107, 780);
            this.BayesianPicHeightBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianPicHeightBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.BayesianPicHeightBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.BayesianPicHeightBox.Name = "BayesianPicHeightBox";
            this.BayesianPicHeightBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianPicHeightBox.TabIndex = 504;
            this.BayesianPicHeightBox.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianPicHeightBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianKmaxBox
            // 
            this.BayesianKmaxBox.Location = new System.Drawing.Point(301, 114);
            this.BayesianKmaxBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianKmaxBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianKmaxBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianKmaxBox.Name = "BayesianKmaxBox";
            this.BayesianKmaxBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianKmaxBox.TabIndex = 508;
            this.BayesianKmaxBox.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.BayesianKmaxBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianNThinningBox
            // 
            this.BayesianNThinningBox.Location = new System.Drawing.Point(109, 206);
            this.BayesianNThinningBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianNThinningBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianNThinningBox.Name = "BayesianNThinningBox";
            this.BayesianNThinningBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianNThinningBox.TabIndex = 508;
            this.BayesianNThinningBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianNThinningBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianBurninBox
            // 
            this.BayesianBurninBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianBurninBox.Location = new System.Drawing.Point(109, 172);
            this.BayesianBurninBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianBurninBox.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.BayesianBurninBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianBurninBox.Name = "BayesianBurninBox";
            this.BayesianBurninBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianBurninBox.TabIndex = 508;
            this.BayesianBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.BayesianBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianSeparatorWidthBox
            // 
            this.BayesianSeparatorWidthBox.Location = new System.Drawing.Point(299, 814);
            this.BayesianSeparatorWidthBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianSeparatorWidthBox.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.BayesianSeparatorWidthBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianSeparatorWidthBox.Name = "BayesianSeparatorWidthBox";
            this.BayesianSeparatorWidthBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianSeparatorWidthBox.TabIndex = 503;
            this.BayesianSeparatorWidthBox.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.BayesianSeparatorWidthBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianPicWidthBox
            // 
            this.BayesianPicWidthBox.Location = new System.Drawing.Point(299, 781);
            this.BayesianPicWidthBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianPicWidthBox.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.BayesianPicWidthBox.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.BayesianPicWidthBox.Name = "BayesianPicWidthBox";
            this.BayesianPicWidthBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianPicWidthBox.TabIndex = 503;
            this.BayesianPicWidthBox.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.BayesianPicWidthBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianNRepsBox
            // 
            this.BayesianNRepsBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianNRepsBox.Location = new System.Drawing.Point(301, 172);
            this.BayesianNRepsBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianNRepsBox.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.BayesianNRepsBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianNRepsBox.Name = "BayesianNRepsBox";
            this.BayesianNRepsBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianNRepsBox.TabIndex = 508;
            this.BayesianNRepsBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.BayesianNRepsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(223, 595);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(50, 20);
            this.label26.TabIndex = 507;
            this.label26.Text = "eps(γ)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(21, 595);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(54, 20);
            this.label25.TabIndex = 507;
            this.label25.Text = "eps(η)";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(213, 660);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(72, 20);
            this.label34.TabIndex = 507;
            this.label34.Text = "prior std";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(224, 561);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 20);
            this.label24.TabIndex = 507;
            this.label24.Text = "std(r)";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(32, 695);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(50, 20);
            this.label41.TabIndex = 507;
            this.label41.Text = "std(F)";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(216, 691);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(50, 20);
            this.label35.TabIndex = 507;
            this.label35.Text = "std(ϵ)";
            this.label35.Visible = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 659);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(89, 20);
            this.label33.TabIndex = 507;
            this.label33.Text = "prior mean";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(21, 561);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 20);
            this.label23.TabIndex = 507;
            this.label23.Text = "max(r)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(205, 435);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(88, 20);
            this.label49.TabIndex = 507;
            this.label49.Text = "MetroFreq";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label100.Location = new System.Drawing.Point(24, 499);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(68, 20);
            this.label100.TabIndex = 507;
            this.label100.Text = "α prior A";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label22.Location = new System.Drawing.Point(217, 399);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 20);
            this.label22.TabIndex = 507;
            this.label22.Text = "std(α)";
            // 
            // BayesianEpsGammaBox
            // 
            this.BayesianEpsGammaBox.DecimalPlaces = 4;
            this.BayesianEpsGammaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianEpsGammaBox.Location = new System.Drawing.Point(299, 592);
            this.BayesianEpsGammaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianEpsGammaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianEpsGammaBox.Name = "BayesianEpsGammaBox";
            this.BayesianEpsGammaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianEpsGammaBox.TabIndex = 508;
            this.BayesianEpsGammaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.BayesianEpsGammaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianEpsEtaBox
            // 
            this.BayesianEpsEtaBox.DecimalPlaces = 4;
            this.BayesianEpsEtaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianEpsEtaBox.Location = new System.Drawing.Point(107, 592);
            this.BayesianEpsEtaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianEpsEtaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianEpsEtaBox.Name = "BayesianEpsEtaBox";
            this.BayesianEpsEtaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianEpsEtaBox.TabIndex = 508;
            this.BayesianEpsEtaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.BayesianEpsEtaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianFPriorStdBox
            // 
            this.BayesianFPriorStdBox.DecimalPlaces = 4;
            this.BayesianFPriorStdBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianFPriorStdBox.Location = new System.Drawing.Point(299, 655);
            this.BayesianFPriorStdBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianFPriorStdBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianFPriorStdBox.Name = "BayesianFPriorStdBox";
            this.BayesianFPriorStdBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianFPriorStdBox.TabIndex = 508;
            this.BayesianFPriorStdBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesianFPriorStdBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianEpsRBox
            // 
            this.BayesianEpsRBox.DecimalPlaces = 4;
            this.BayesianEpsRBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianEpsRBox.Location = new System.Drawing.Point(299, 559);
            this.BayesianEpsRBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianEpsRBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianEpsRBox.Name = "BayesianEpsRBox";
            this.BayesianEpsRBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianEpsRBox.TabIndex = 508;
            this.BayesianEpsRBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianEpsRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(207, 500);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(72, 20);
            this.label99.TabIndex = 507;
            this.label99.Text = "α prior B";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(24, 435);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(59, 20);
            this.label48.TabIndex = 507;
            this.label48.Text = "max(α)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label21.Location = new System.Drawing.Point(24, 399);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 20);
            this.label21.TabIndex = 507;
            this.label21.Text = "α0";
            // 
            // BayesianFStdFBox
            // 
            this.BayesianFStdFBox.DecimalPlaces = 4;
            this.BayesianFStdFBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianFStdFBox.Location = new System.Drawing.Point(107, 691);
            this.BayesianFStdFBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianFStdFBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianFStdFBox.Name = "BayesianFStdFBox";
            this.BayesianFStdFBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianFStdFBox.TabIndex = 508;
            this.BayesianFStdFBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesianFStdFBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianFStdPABox
            // 
            this.BayesianFStdPABox.DecimalPlaces = 4;
            this.BayesianFStdPABox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianFStdPABox.Location = new System.Drawing.Point(301, 691);
            this.BayesianFStdPABox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianFStdPABox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianFStdPABox.Name = "BayesianFStdPABox";
            this.BayesianFStdPABox.Size = new System.Drawing.Size(91, 27);
            this.BayesianFStdPABox.TabIndex = 508;
            this.BayesianFStdPABox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.BayesianFStdPABox.Visible = false;
            this.BayesianFStdPABox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianFPriorMeanBox
            // 
            this.BayesianFPriorMeanBox.DecimalPlaces = 4;
            this.BayesianFPriorMeanBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianFPriorMeanBox.Location = new System.Drawing.Point(107, 655);
            this.BayesianFPriorMeanBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianFPriorMeanBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianFPriorMeanBox.Name = "BayesianFPriorMeanBox";
            this.BayesianFPriorMeanBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianFPriorMeanBox.TabIndex = 508;
            this.BayesianFPriorMeanBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.BayesianFPriorMeanBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianMaxRBox
            // 
            this.BayesianMaxRBox.DecimalPlaces = 4;
            this.BayesianMaxRBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianMaxRBox.Location = new System.Drawing.Point(107, 559);
            this.BayesianMaxRBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianMaxRBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianMaxRBox.Name = "BayesianMaxRBox";
            this.BayesianMaxRBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianMaxRBox.TabIndex = 508;
            this.BayesianMaxRBox.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.BayesianMaxRBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(208, 308);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(90, 20);
            this.label47.TabIndex = 507;
            this.label47.Text = "AdmBurnin";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(24, 308);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(57, 20);
            this.label97.TabIndex = 507;
            this.label97.Text = "max(λ)";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(216, 271);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(50, 20);
            this.label96.TabIndex = 507;
            this.label96.Text = "std(λ)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, 271);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 20);
            this.label19.TabIndex = 507;
            this.label19.Text = "λ";
            // 
            // BayesianUpdateQBox
            // 
            this.BayesianUpdateQBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianUpdateQBox.Location = new System.Drawing.Point(301, 432);
            this.BayesianUpdateQBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianUpdateQBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianUpdateQBox.Name = "BayesianUpdateQBox";
            this.BayesianUpdateQBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianUpdateQBox.TabIndex = 508;
            this.BayesianUpdateQBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.BayesianUpdateQBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianAlphaPrioriABox
            // 
            this.BayesianAlphaPrioriABox.DecimalPlaces = 4;
            this.BayesianAlphaPrioriABox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianAlphaPrioriABox.Location = new System.Drawing.Point(109, 495);
            this.BayesianAlphaPrioriABox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianAlphaPrioriABox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianAlphaPrioriABox.Name = "BayesianAlphaPrioriABox";
            this.BayesianAlphaPrioriABox.Size = new System.Drawing.Size(91, 27);
            this.BayesianAlphaPrioriABox.TabIndex = 508;
            this.BayesianAlphaPrioriABox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianAlphaPrioriABox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianAlphaPrioriBBox
            // 
            this.BayesianAlphaPrioriBBox.DecimalPlaces = 4;
            this.BayesianAlphaPrioriBBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianAlphaPrioriBBox.Location = new System.Drawing.Point(301, 498);
            this.BayesianAlphaPrioriBBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianAlphaPrioriBBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianAlphaPrioriBBox.Name = "BayesianAlphaPrioriBBox";
            this.BayesianAlphaPrioriBBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianAlphaPrioriBBox.TabIndex = 508;
            this.BayesianAlphaPrioriBBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.BayesianAlphaPrioriBBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianStdAlphaBox
            // 
            this.BayesianStdAlphaBox.DecimalPlaces = 4;
            this.BayesianStdAlphaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianStdAlphaBox.Location = new System.Drawing.Point(301, 396);
            this.BayesianStdAlphaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianStdAlphaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianStdAlphaBox.Name = "BayesianStdAlphaBox";
            this.BayesianStdAlphaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianStdAlphaBox.TabIndex = 508;
            this.BayesianStdAlphaBox.Value = new decimal(new int[] {
            25,
            0,
            0,
            196608});
            this.BayesianStdAlphaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianMaxAlphaBox
            // 
            this.BayesianMaxAlphaBox.DecimalPlaces = 4;
            this.BayesianMaxAlphaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianMaxAlphaBox.Location = new System.Drawing.Point(109, 432);
            this.BayesianMaxAlphaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianMaxAlphaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianMaxAlphaBox.Name = "BayesianMaxAlphaBox";
            this.BayesianMaxAlphaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianMaxAlphaBox.TabIndex = 508;
            this.BayesianMaxAlphaBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.BayesianMaxAlphaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianAlpha0Box
            // 
            this.BayesianAlpha0Box.DecimalPlaces = 4;
            this.BayesianAlpha0Box.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianAlpha0Box.Location = new System.Drawing.Point(109, 396);
            this.BayesianAlpha0Box.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianAlpha0Box.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianAlpha0Box.Name = "BayesianAlpha0Box";
            this.BayesianAlpha0Box.Size = new System.Drawing.Size(91, 27);
            this.BayesianAlpha0Box.TabIndex = 508;
            this.BayesianAlpha0Box.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianAlpha0Box.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianMaxLambdaBox
            // 
            this.BayesianMaxLambdaBox.DecimalPlaces = 4;
            this.BayesianMaxLambdaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianMaxLambdaBox.Location = new System.Drawing.Point(109, 305);
            this.BayesianMaxLambdaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianMaxLambdaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianMaxLambdaBox.Name = "BayesianMaxLambdaBox";
            this.BayesianMaxLambdaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianMaxLambdaBox.TabIndex = 508;
            this.BayesianMaxLambdaBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.BayesianMaxLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianStdLambdaBox
            // 
            this.BayesianStdLambdaBox.DecimalPlaces = 4;
            this.BayesianStdLambdaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianStdLambdaBox.Location = new System.Drawing.Point(301, 269);
            this.BayesianStdLambdaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianStdLambdaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianStdLambdaBox.Name = "BayesianStdLambdaBox";
            this.BayesianStdLambdaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianStdLambdaBox.TabIndex = 508;
            this.BayesianStdLambdaBox.Value = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            this.BayesianStdLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianLambdaBox
            // 
            this.BayesianLambdaBox.DecimalPlaces = 4;
            this.BayesianLambdaBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.BayesianLambdaBox.Location = new System.Drawing.Point(109, 269);
            this.BayesianLambdaBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianLambdaBox.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.BayesianLambdaBox.Name = "BayesianLambdaBox";
            this.BayesianLambdaBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianLambdaBox.TabIndex = 508;
            this.BayesianLambdaBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianLambdaBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(216, 209);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 20);
            this.label15.TabIndex = 507;
            this.label15.Text = "#Runs";
            // 
            // BayesianNRunsBox
            // 
            this.BayesianNRunsBox.Location = new System.Drawing.Point(301, 206);
            this.BayesianNRunsBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianNRunsBox.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.BayesianNRunsBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianNRunsBox.Name = "BayesianNRunsBox";
            this.BayesianNRunsBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianNRunsBox.TabIndex = 508;
            this.BayesianNRunsBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.BayesianNRunsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 754);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Barplot parameters";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 784);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Height";
            // 
            // BayesianKminBox
            // 
            this.BayesianKminBox.Location = new System.Drawing.Point(109, 114);
            this.BayesianKminBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianKminBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BayesianKminBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BayesianKminBox.Name = "BayesianKminBox";
            this.BayesianKminBox.Size = new System.Drawing.Size(91, 27);
            this.BayesianKminBox.TabIndex = 508;
            this.BayesianKminBox.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.BayesianKminBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(21, 816);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(236, 20);
            this.label18.TabIndex = 0;
            this.label18.Text = "Separator width of populations";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(216, 175);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 20);
            this.label27.TabIndex = 507;
            this.label27.Text = "#Reps";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(209, 784);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ind. width";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(11, 630);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(155, 20);
            this.label32.TabIndex = 507;
            this.label32.Text = "F model parameters";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(11, 532);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(226, 20);
            this.label31.TabIndex = 507;
            this.label31.Text = "LOCPRIORI model parameters";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(11, 370);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(236, 20);
            this.label30.TabIndex = 507;
            this.label30.Text = "ADMIXTURE model parameters";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(11, 242);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(273, 20);
            this.label29.TabIndex = 507;
            this.label29.Text = "Allele frequency && admixture burnin";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(11, 149);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(146, 20);
            this.label28.TabIndex = 507;
            this.label28.Text = "MCMC parameters";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(24, 175);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 20);
            this.label14.TabIndex = 507;
            this.label14.Text = "#Burnin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(216, 116);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 20);
            this.label12.TabIndex = 507;
            this.label12.Text = "to";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 209);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 20);
            this.label13.TabIndex = 507;
            this.label13.Text = "#Thinning";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 116);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 20);
            this.label11.TabIndex = 507;
            this.label11.Text = "K runs from";
            // 
            // BayesianRearrangeColorBox
            // 
            this.BayesianRearrangeColorBox.AutoSize = true;
            this.BayesianRearrangeColorBox.Location = new System.Drawing.Point(21, 845);
            this.BayesianRearrangeColorBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianRearrangeColorBox.Name = "BayesianRearrangeColorBox";
            this.BayesianRearrangeColorBox.Size = new System.Drawing.Size(345, 24);
            this.BayesianRearrangeColorBox.TabIndex = 0;
            this.BayesianRearrangeColorBox.Text = "Rearrange color by probabilities of clusters";
            this.BayesianRearrangeColorBox.UseVisualStyleBackColor = true;
            this.BayesianRearrangeColorBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianADMBox
            // 
            this.BayesianADMBox.AutoSize = true;
            this.BayesianADMBox.Location = new System.Drawing.Point(13, 29);
            this.BayesianADMBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianADMBox.Name = "BayesianADMBox";
            this.BayesianADMBox.Size = new System.Drawing.Size(262, 24);
            this.BayesianADMBox.TabIndex = 0;
            this.BayesianADMBox.Text = "Admixture model (ADMIXTURE)";
            this.BayesianADMBox.UseVisualStyleBackColor = true;
            this.BayesianADMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FSAMEBOX
            // 
            this.FSAMEBOX.AutoSize = true;
            this.FSAMEBOX.Location = new System.Drawing.Point(21, 721);
            this.FSAMEBOX.Margin = new System.Windows.Forms.Padding(4);
            this.FSAMEBOX.Name = "FSAMEBOX";
            this.FSAMEBOX.Size = new System.Drawing.Size(247, 24);
            this.FSAMEBOX.TabIndex = 0;
            this.FSAMEBOX.Text = "Assume same F for all clusters";
            this.FSAMEBOX.UseVisualStyleBackColor = true;
            this.FSAMEBOX.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianFmodelBox
            // 
            this.BayesianFmodelBox.AutoSize = true;
            this.BayesianFmodelBox.Location = new System.Drawing.Point(13, 86);
            this.BayesianFmodelBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianFmodelBox.Name = "BayesianFmodelBox";
            this.BayesianFmodelBox.Size = new System.Drawing.Size(302, 24);
            this.BayesianFmodelBox.TabIndex = 0;
            this.BayesianFmodelBox.Text = "Allele frequency correlated (F model)";
            this.BayesianFmodelBox.UseVisualStyleBackColor = true;
            this.BayesianFmodelBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // BayesianLOCPRIORIBox
            // 
            this.BayesianLOCPRIORIBox.AutoSize = true;
            this.BayesianLOCPRIORIBox.Location = new System.Drawing.Point(13, 58);
            this.BayesianLOCPRIORIBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianLOCPRIORIBox.Name = "BayesianLOCPRIORIBox";
            this.BayesianLOCPRIORIBox.Size = new System.Drawing.Size(270, 24);
            this.BayesianLOCPRIORIBox.TabIndex = 0;
            this.BayesianLOCPRIORIBox.Text = "Using pop as a priori (LOCPRIOR)";
            this.BayesianLOCPRIORIBox.UseVisualStyleBackColor = true;
            this.BayesianLOCPRIORIBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.label98);
            this.groupBox33.Controls.Add(this.PhenotypeTestTotBox);
            this.groupBox33.Controls.Add(this.PhenotypeTestRegBox);
            this.groupBox33.Controls.Add(this.PhenotypeTestPopBox);
            this.groupBox33.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox33.Location = new System.Drawing.Point(289, 4);
            this.groupBox33.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox33.Size = new System.Drawing.Size(277, 111);
            this.groupBox33.TabIndex = 10;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Pheno/geno distribution test";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label98.Location = new System.Drawing.Point(11, 22);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(55, 20);
            this.label98.TabIndex = 514;
            this.label98.Text = "Range";
            // 
            // PhenotypeTestTotBox
            // 
            this.PhenotypeTestTotBox.AutoSize = true;
            this.PhenotypeTestTotBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.PhenotypeTestTotBox.Location = new System.Drawing.Point(27, 79);
            this.PhenotypeTestTotBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhenotypeTestTotBox.Name = "PhenotypeTestTotBox";
            this.PhenotypeTestTotBox.Size = new System.Drawing.Size(152, 24);
            this.PhenotypeTestTotBox.TabIndex = 3;
            this.PhenotypeTestTotBox.Text = "Total population";
            this.PhenotypeTestTotBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // PhenotypeTestRegBox
            // 
            this.PhenotypeTestRegBox.AutoSize = true;
            this.PhenotypeTestRegBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.PhenotypeTestRegBox.Location = new System.Drawing.Point(149, 48);
            this.PhenotypeTestRegBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhenotypeTestRegBox.Name = "PhenotypeTestRegBox";
            this.PhenotypeTestRegBox.Size = new System.Drawing.Size(83, 24);
            this.PhenotypeTestRegBox.TabIndex = 2;
            this.PhenotypeTestRegBox.Text = "Region";
            this.PhenotypeTestRegBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // PhenotypeTestPopBox
            // 
            this.PhenotypeTestPopBox.AutoSize = true;
            this.PhenotypeTestPopBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.PhenotypeTestPopBox.Location = new System.Drawing.Point(27, 48);
            this.PhenotypeTestPopBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhenotypeTestPopBox.Name = "PhenotypeTestPopBox";
            this.PhenotypeTestPopBox.Size = new System.Drawing.Size(110, 24);
            this.PhenotypeTestPopBox.TabIndex = 1;
            this.PhenotypeTestPopBox.Text = "Population";
            this.PhenotypeTestPopBox.UseVisualStyleBackColor = true;
            this.PhenotypeTestPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.label95);
            this.groupBox50.Controls.Add(this.PCOAFontSizeBox);
            this.groupBox50.Controls.Add(this.label91);
            this.groupBox50.Controls.Add(this.PCOADimBox);
            this.groupBox50.Controls.Add(this.label90);
            this.groupBox50.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox50.Location = new System.Drawing.Point(575, 482);
            this.groupBox50.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox50.Size = new System.Drawing.Size(277, 140);
            this.groupBox50.TabIndex = 10;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "PCoA";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(11, 100);
            this.label95.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(73, 20);
            this.label95.TabIndex = 516;
            this.label95.Text = "Font size";
            // 
            // PCOAFontSizeBox
            // 
            this.PCOAFontSizeBox.Location = new System.Drawing.Point(127, 98);
            this.PCOAFontSizeBox.Margin = new System.Windows.Forms.Padding(4);
            this.PCOAFontSizeBox.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.PCOAFontSizeBox.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.PCOAFontSizeBox.Name = "PCOAFontSizeBox";
            this.PCOAFontSizeBox.Size = new System.Drawing.Size(112, 27);
            this.PCOAFontSizeBox.TabIndex = 517;
            this.PCOAFontSizeBox.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(11, 54);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(204, 40);
            this.label91.TabIndex = 515;
            this.label91.Text = "Select distance estimators \r\non the top";
            // 
            // PCOADimBox
            // 
            this.PCOADimBox.Location = new System.Drawing.Point(127, 21);
            this.PCOADimBox.Margin = new System.Windows.Forms.Padding(4);
            this.PCOADimBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.PCOADimBox.Name = "PCOADimBox";
            this.PCOADimBox.Size = new System.Drawing.Size(112, 27);
            this.PCOADimBox.TabIndex = 514;
            this.PCOADimBox.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.PCOADimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(11, 25);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(108, 20);
            this.label90.TabIndex = 513;
            this.label90.Text = "#Coordinates";
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.label92);
            this.groupBox48.Controls.Add(this.label3);
            this.groupBox48.Controls.Add(this.label93);
            this.groupBox48.Controls.Add(this.label94);
            this.groupBox48.Controls.Add(this.ClusteringWPGMABox);
            this.groupBox48.Controls.Add(this.ClusteringFontSizeBox);
            this.groupBox48.Controls.Add(this.ClusteringWARDBox);
            this.groupBox48.Controls.Add(this.ClusteringUPGMABox);
            this.groupBox48.Controls.Add(this.ClusteringLineSepBox);
            this.groupBox48.Controls.Add(this.ClusteringWPGMCBox);
            this.groupBox48.Controls.Add(this.ClusteringFurthestBox);
            this.groupBox48.Controls.Add(this.ClusteringUPGMCBox);
            this.groupBox48.Controls.Add(this.ClusteringNearestBox);
            this.groupBox48.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox48.Location = new System.Drawing.Point(575, 630);
            this.groupBox48.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox48.Size = new System.Drawing.Size(277, 279);
            this.groupBox48.TabIndex = 10;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "Hierarchical clustering";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(21, 158);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(204, 40);
            this.label92.TabIndex = 516;
            this.label92.Text = "Select distance estimators \r\non the top";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 22);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 20);
            this.label3.TabIndex = 402;
            this.label3.Text = "Clustering methods";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(11, 208);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(73, 20);
            this.label93.TabIndex = 3;
            this.label93.Text = "Font size";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(11, 241);
            this.label94.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(72, 20);
            this.label94.TabIndex = 3;
            this.label94.Text = "Line skip";
            // 
            // ClusteringWPGMABox
            // 
            this.ClusteringWPGMABox.AutoSize = true;
            this.ClusteringWPGMABox.Location = new System.Drawing.Point(27, 129);
            this.ClusteringWPGMABox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringWPGMABox.Name = "ClusteringWPGMABox";
            this.ClusteringWPGMABox.Size = new System.Drawing.Size(92, 24);
            this.ClusteringWPGMABox.TabIndex = 0;
            this.ClusteringWPGMABox.Text = "WPGMA";
            this.ClusteringWPGMABox.UseVisualStyleBackColor = true;
            this.ClusteringWPGMABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringFontSizeBox
            // 
            this.ClusteringFontSizeBox.Location = new System.Drawing.Point(127, 205);
            this.ClusteringFontSizeBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringFontSizeBox.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ClusteringFontSizeBox.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ClusteringFontSizeBox.Name = "ClusteringFontSizeBox";
            this.ClusteringFontSizeBox.Size = new System.Drawing.Size(112, 27);
            this.ClusteringFontSizeBox.TabIndex = 301;
            this.ClusteringFontSizeBox.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.ClusteringFontSizeBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringWARDBox
            // 
            this.ClusteringWARDBox.AutoSize = true;
            this.ClusteringWARDBox.Location = new System.Drawing.Point(148, 101);
            this.ClusteringWARDBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringWARDBox.Name = "ClusteringWARDBox";
            this.ClusteringWARDBox.Size = new System.Drawing.Size(78, 24);
            this.ClusteringWARDBox.TabIndex = 0;
            this.ClusteringWARDBox.Text = "WARD";
            this.ClusteringWARDBox.UseVisualStyleBackColor = true;
            this.ClusteringWARDBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringUPGMABox
            // 
            this.ClusteringUPGMABox.AutoSize = true;
            this.ClusteringUPGMABox.Location = new System.Drawing.Point(27, 101);
            this.ClusteringUPGMABox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringUPGMABox.Name = "ClusteringUPGMABox";
            this.ClusteringUPGMABox.Size = new System.Drawing.Size(88, 24);
            this.ClusteringUPGMABox.TabIndex = 0;
            this.ClusteringUPGMABox.Text = "UPGMA";
            this.ClusteringUPGMABox.UseVisualStyleBackColor = true;
            this.ClusteringUPGMABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringLineSepBox
            // 
            this.ClusteringLineSepBox.Location = new System.Drawing.Point(127, 239);
            this.ClusteringLineSepBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringLineSepBox.Name = "ClusteringLineSepBox";
            this.ClusteringLineSepBox.Size = new System.Drawing.Size(112, 27);
            this.ClusteringLineSepBox.TabIndex = 301;
            this.ClusteringLineSepBox.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.ClusteringLineSepBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringWPGMCBox
            // 
            this.ClusteringWPGMCBox.AutoSize = true;
            this.ClusteringWPGMCBox.Location = new System.Drawing.Point(148, 74);
            this.ClusteringWPGMCBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringWPGMCBox.Name = "ClusteringWPGMCBox";
            this.ClusteringWPGMCBox.Size = new System.Drawing.Size(91, 24);
            this.ClusteringWPGMCBox.TabIndex = 0;
            this.ClusteringWPGMCBox.Text = "WPGMC";
            this.ClusteringWPGMCBox.UseVisualStyleBackColor = true;
            this.ClusteringWPGMCBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringFurthestBox
            // 
            this.ClusteringFurthestBox.AutoSize = true;
            this.ClusteringFurthestBox.Location = new System.Drawing.Point(27, 74);
            this.ClusteringFurthestBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringFurthestBox.Name = "ClusteringFurthestBox";
            this.ClusteringFurthestBox.Size = new System.Drawing.Size(91, 24);
            this.ClusteringFurthestBox.TabIndex = 0;
            this.ClusteringFurthestBox.Text = "Furthest";
            this.ClusteringFurthestBox.UseVisualStyleBackColor = true;
            this.ClusteringFurthestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringUPGMCBox
            // 
            this.ClusteringUPGMCBox.AutoSize = true;
            this.ClusteringUPGMCBox.Location = new System.Drawing.Point(148, 46);
            this.ClusteringUPGMCBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringUPGMCBox.Name = "ClusteringUPGMCBox";
            this.ClusteringUPGMCBox.Size = new System.Drawing.Size(87, 24);
            this.ClusteringUPGMCBox.TabIndex = 0;
            this.ClusteringUPGMCBox.Text = "UPGMC";
            this.ClusteringUPGMCBox.UseVisualStyleBackColor = true;
            this.ClusteringUPGMCBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ClusteringNearestBox
            // 
            this.ClusteringNearestBox.AutoSize = true;
            this.ClusteringNearestBox.Location = new System.Drawing.Point(27, 46);
            this.ClusteringNearestBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringNearestBox.Name = "ClusteringNearestBox";
            this.ClusteringNearestBox.Size = new System.Drawing.Size(88, 24);
            this.ClusteringNearestBox.TabIndex = 0;
            this.ClusteringNearestBox.Text = "Nearest";
            this.ClusteringNearestBox.UseVisualStyleBackColor = true;
            this.ClusteringNearestBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.ParentageUnknownBox);
            this.groupBox35.Controls.Add(this.ParentageParentPairBox);
            this.groupBox35.Controls.Add(this.ParentageSkipSimBox);
            this.groupBox35.Controls.Add(this.ParentagePaternityBox);
            this.groupBox35.Controls.Add(this.label51);
            this.groupBox35.Controls.Add(this.ParentageOutputBox);
            this.groupBox35.Controls.Add(this.label69);
            this.groupBox35.Controls.Add(this.label70);
            this.groupBox35.Controls.Add(this.label71);
            this.groupBox35.Controls.Add(this.ParentageUnknownNSimBox);
            this.groupBox35.Controls.Add(this.label52);
            this.groupBox35.Controls.Add(this.label72);
            this.groupBox35.Controls.Add(this.ParentageParentPairNSimBox);
            this.groupBox35.Controls.Add(this.label73);
            this.groupBox35.Controls.Add(this.ParentagePaternityNSimBox);
            this.groupBox35.Controls.Add(this.label74);
            this.groupBox35.Controls.Add(this.ParentageUnknownNCandidateBox);
            this.groupBox35.Controls.Add(this.label75);
            this.groupBox35.Controls.Add(this.ParentageParentPairNMotherBox);
            this.groupBox35.Controls.Add(this.ParentageParentPairNFatherBox);
            this.groupBox35.Controls.Add(this.label76);
            this.groupBox35.Controls.Add(this.ParentagePaternityNFatherBox);
            this.groupBox35.Controls.Add(this.ParentageSamplingRateBox);
            this.groupBox35.Controls.Add(this.label77);
            this.groupBox35.Controls.Add(this.label78);
            this.groupBox35.Controls.Add(this.label79);
            this.groupBox35.Controls.Add(this.ParentageMistypeRateBox);
            this.groupBox35.Controls.Add(this.label80);
            this.groupBox35.Controls.Add(this.label82);
            this.groupBox35.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox35.Location = new System.Drawing.Point(1145, 4);
            this.groupBox35.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox35.Size = new System.Drawing.Size(288, 636);
            this.groupBox35.TabIndex = 9;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Parentage analysis";
            // 
            // ParentageUnknownBox
            // 
            this.ParentageUnknownBox.AutoSize = true;
            this.ParentageUnknownBox.Location = new System.Drawing.Point(24, 129);
            this.ParentageUnknownBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownBox.Name = "ParentageUnknownBox";
            this.ParentageUnknownBox.Size = new System.Drawing.Size(218, 24);
            this.ParentageUnknownBox.TabIndex = 65;
            this.ParentageUnknownBox.Text = "Parent pair (sex unknown)";
            this.ParentageUnknownBox.UseVisualStyleBackColor = true;
            this.ParentageUnknownBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageParentPairBox
            // 
            this.ParentageParentPairBox.AutoSize = true;
            this.ParentageParentPairBox.Location = new System.Drawing.Point(24, 101);
            this.ParentageParentPairBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairBox.Name = "ParentageParentPairBox";
            this.ParentageParentPairBox.Size = new System.Drawing.Size(110, 24);
            this.ParentageParentPairBox.TabIndex = 65;
            this.ParentageParentPairBox.Text = "Parent pair";
            this.ParentageParentPairBox.UseVisualStyleBackColor = true;
            this.ParentageParentPairBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageSkipSimBox
            // 
            this.ParentageSkipSimBox.AutoSize = true;
            this.ParentageSkipSimBox.Location = new System.Drawing.Point(24, 46);
            this.ParentageSkipSimBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageSkipSimBox.Name = "ParentageSkipSimBox";
            this.ParentageSkipSimBox.Size = new System.Drawing.Size(141, 24);
            this.ParentageSkipSimBox.TabIndex = 65;
            this.ParentageSkipSimBox.Text = "Skip simulation";
            this.ParentageSkipSimBox.UseVisualStyleBackColor = true;
            this.ParentageSkipSimBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentagePaternityBox
            // 
            this.ParentagePaternityBox.AutoSize = true;
            this.ParentagePaternityBox.Checked = true;
            this.ParentagePaternityBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ParentagePaternityBox.Location = new System.Drawing.Point(24, 74);
            this.ParentagePaternityBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentagePaternityBox.Name = "ParentagePaternityBox";
            this.ParentagePaternityBox.Size = new System.Drawing.Size(96, 24);
            this.ParentagePaternityBox.TabIndex = 65;
            this.ParentagePaternityBox.Text = "Paternity";
            this.ParentagePaternityBox.UseVisualStyleBackColor = true;
            this.ParentagePaternityBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(11, 568);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(99, 20);
            this.label51.TabIndex = 63;
            this.label51.Text = "Output style";
            // 
            // ParentageOutputBox
            // 
            this.ParentageOutputBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ParentageOutputBox.FormattingEnabled = true;
            this.ParentageOutputBox.Items.AddRange(new object[] {
            "Top 1 LOD parent",
            "Top 2 LOD parents",
            "Top 5 LOD parents",
            "All positive LOD parents",
            "All candidate parents"});
            this.ParentageOutputBox.Location = new System.Drawing.Point(36, 595);
            this.ParentageOutputBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageOutputBox.Name = "ParentageOutputBox";
            this.ParentageOutputBox.Size = new System.Drawing.Size(237, 28);
            this.ParentageOutputBox.TabIndex = 64;
            this.ParentageOutputBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(11, 475);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(196, 20);
            this.label69.TabIndex = 59;
            this.label69.Text = "Parent pair (sex unknown)";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(11, 347);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(88, 20);
            this.label70.TabIndex = 62;
            this.label70.Text = "Parent pair";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(11, 256);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(74, 20);
            this.label71.TabIndex = 61;
            this.label71.Text = "Paternity";
            // 
            // ParentageUnknownNSimBox
            // 
            this.ParentageUnknownNSimBox.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageUnknownNSimBox.Location = new System.Drawing.Point(192, 499);
            this.ParentageUnknownNSimBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownNSimBox.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.ParentageUnknownNSimBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageUnknownNSimBox.Name = "ParentageUnknownNSimBox";
            this.ParentageUnknownNSimBox.Size = new System.Drawing.Size(83, 27);
            this.ParentageUnknownNSimBox.TabIndex = 44;
            this.ParentageUnknownNSimBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageUnknownNSimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(11, 25);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(91, 20);
            this.label52.TabIndex = 60;
            this.label52.Text = "Parameters";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(11, 162);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(173, 20);
            this.label72.TabIndex = 60;
            this.label72.Text = "Simulation parameters";
            // 
            // ParentageParentPairNSimBox
            // 
            this.ParentageParentPairNSimBox.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageParentPairNSimBox.Location = new System.Drawing.Point(192, 372);
            this.ParentageParentPairNSimBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairNSimBox.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.ParentageParentPairNSimBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageParentPairNSimBox.Name = "ParentageParentPairNSimBox";
            this.ParentageParentPairNSimBox.Size = new System.Drawing.Size(83, 27);
            this.ParentageParentPairNSimBox.TabIndex = 43;
            this.ParentageParentPairNSimBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentageParentPairNSimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(24, 502);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(103, 20);
            this.label73.TabIndex = 51;
            this.label73.Text = "#Simulations";
            // 
            // ParentagePaternityNSimBox
            // 
            this.ParentagePaternityNSimBox.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentagePaternityNSimBox.Location = new System.Drawing.Point(192, 281);
            this.ParentagePaternityNSimBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentagePaternityNSimBox.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.ParentagePaternityNSimBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentagePaternityNSimBox.Name = "ParentagePaternityNSimBox";
            this.ParentagePaternityNSimBox.Size = new System.Drawing.Size(83, 27);
            this.ParentagePaternityNSimBox.TabIndex = 42;
            this.ParentagePaternityNSimBox.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ParentagePaternityNSimBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(24, 375);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(103, 20);
            this.label74.TabIndex = 53;
            this.label74.Text = "#Simulations";
            // 
            // ParentageUnknownNCandidateBox
            // 
            this.ParentageUnknownNCandidateBox.Location = new System.Drawing.Point(192, 533);
            this.ParentageUnknownNCandidateBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownNCandidateBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.Name = "ParentageUnknownNCandidateBox";
            this.ParentageUnknownNCandidateBox.Size = new System.Drawing.Size(83, 27);
            this.ParentageUnknownNCandidateBox.TabIndex = 45;
            this.ParentageUnknownNCandidateBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageUnknownNCandidateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(24, 226);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(115, 20);
            this.label75.TabIndex = 50;
            this.label75.Text = "Mistyping rate";
            // 
            // ParentageParentPairNMotherBox
            // 
            this.ParentageParentPairNMotherBox.Location = new System.Drawing.Point(192, 439);
            this.ParentageParentPairNMotherBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairNMotherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.Name = "ParentageParentPairNMotherBox";
            this.ParentageParentPairNMotherBox.Size = new System.Drawing.Size(83, 27);
            this.ParentageParentPairNMotherBox.TabIndex = 47;
            this.ParentageParentPairNMotherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageParentPairNMotherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageParentPairNFatherBox
            // 
            this.ParentageParentPairNFatherBox.Location = new System.Drawing.Point(192, 406);
            this.ParentageParentPairNFatherBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairNFatherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.Name = "ParentageParentPairNFatherBox";
            this.ParentageParentPairNFatherBox.Size = new System.Drawing.Size(83, 27);
            this.ParentageParentPairNFatherBox.TabIndex = 46;
            this.ParentageParentPairNFatherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentageParentPairNFatherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(24, 283);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(103, 20);
            this.label76.TabIndex = 52;
            this.label76.Text = "#Simulations";
            // 
            // ParentagePaternityNFatherBox
            // 
            this.ParentagePaternityNFatherBox.Location = new System.Drawing.Point(192, 315);
            this.ParentagePaternityNFatherBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentagePaternityNFatherBox.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.Name = "ParentagePaternityNFatherBox";
            this.ParentagePaternityNFatherBox.Size = new System.Drawing.Size(83, 27);
            this.ParentagePaternityNFatherBox.TabIndex = 48;
            this.ParentagePaternityNFatherBox.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.ParentagePaternityNFatherBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // ParentageSamplingRateBox
            // 
            this.ParentageSamplingRateBox.DecimalPlaces = 4;
            this.ParentageSamplingRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.Location = new System.Drawing.Point(192, 189);
            this.ParentageSamplingRateBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageSamplingRateBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ParentageSamplingRateBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.Name = "ParentageSamplingRateBox";
            this.ParentageSamplingRateBox.Size = new System.Drawing.Size(84, 27);
            this.ParentageSamplingRateBox.TabIndex = 39;
            this.ParentageSamplingRateBox.Value = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            this.ParentageSamplingRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(24, 536);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(152, 20);
            this.label77.TabIndex = 57;
            this.label77.Text = "#Candidate parents";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(24, 442);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(158, 20);
            this.label78.TabIndex = 58;
            this.label78.Text = "#Candidate mothers";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(24, 408);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(147, 20);
            this.label79.TabIndex = 55;
            this.label79.Text = "#Candidate fathers";
            // 
            // ParentageMistypeRateBox
            // 
            this.ParentageMistypeRateBox.DecimalPlaces = 4;
            this.ParentageMistypeRateBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageMistypeRateBox.Location = new System.Drawing.Point(192, 223);
            this.ParentageMistypeRateBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageMistypeRateBox.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.ParentageMistypeRateBox.Name = "ParentageMistypeRateBox";
            this.ParentageMistypeRateBox.Size = new System.Drawing.Size(84, 27);
            this.ParentageMistypeRateBox.TabIndex = 40;
            this.ParentageMistypeRateBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.ParentageMistypeRateBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(24, 317);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(147, 20);
            this.label80.TabIndex = 56;
            this.label80.Text = "#Candidate fathers";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(24, 191);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(110, 20);
            this.label82.TabIndex = 49;
            this.label82.Text = "Sampling rate";
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.label88);
            this.groupBox34.Controls.Add(this.InbreedingLoiselle1995Box);
            this.groupBox34.Controls.Add(this.InbreedingRitland1996Box);
            this.groupBox34.Controls.Add(this.InbreedingWeir1996Box);
            this.groupBox34.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox34.Location = new System.Drawing.Point(860, 4);
            this.groupBox34.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox34.Size = new System.Drawing.Size(277, 134);
            this.groupBox34.TabIndex = 8;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "Individual inbreeding coef.";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(11, 22);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(85, 20);
            this.label88.TabIndex = 402;
            this.label88.Text = "Estimators";
            // 
            // InbreedingLoiselle1995Box
            // 
            this.InbreedingLoiselle1995Box.AutoSize = true;
            this.InbreedingLoiselle1995Box.Location = new System.Drawing.Point(27, 75);
            this.InbreedingLoiselle1995Box.Margin = new System.Windows.Forms.Padding(4);
            this.InbreedingLoiselle1995Box.Name = "InbreedingLoiselle1995Box";
            this.InbreedingLoiselle1995Box.Size = new System.Drawing.Size(126, 24);
            this.InbreedingLoiselle1995Box.TabIndex = 405;
            this.InbreedingLoiselle1995Box.Text = "Loiselle 1995";
            this.InbreedingLoiselle1995Box.UseVisualStyleBackColor = true;
            this.InbreedingLoiselle1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingRitland1996Box
            // 
            this.InbreedingRitland1996Box.AutoSize = true;
            this.InbreedingRitland1996Box.Location = new System.Drawing.Point(27, 48);
            this.InbreedingRitland1996Box.Margin = new System.Windows.Forms.Padding(4);
            this.InbreedingRitland1996Box.Name = "InbreedingRitland1996Box";
            this.InbreedingRitland1996Box.Size = new System.Drawing.Size(122, 24);
            this.InbreedingRitland1996Box.TabIndex = 406;
            this.InbreedingRitland1996Box.Text = "Ritland 1996";
            this.InbreedingRitland1996Box.UseVisualStyleBackColor = true;
            this.InbreedingRitland1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // InbreedingWeir1996Box
            // 
            this.InbreedingWeir1996Box.AutoSize = true;
            this.InbreedingWeir1996Box.Location = new System.Drawing.Point(27, 102);
            this.InbreedingWeir1996Box.Margin = new System.Windows.Forms.Padding(4);
            this.InbreedingWeir1996Box.Name = "InbreedingWeir1996Box";
            this.InbreedingWeir1996Box.Size = new System.Drawing.Size(105, 24);
            this.InbreedingWeir1996Box.TabIndex = 402;
            this.InbreedingWeir1996Box.Text = "Weir 1996";
            this.InbreedingWeir1996Box.UseVisualStyleBackColor = true;
            this.InbreedingWeir1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.CalcParentageBox);
            this.groupBox21.Controls.Add(this.CalcAMOVABox);
            this.groupBox21.Controls.Add(this.CalcDistBox);
            this.groupBox21.Controls.Add(this.CalcClusteringBox);
            this.groupBox21.Controls.Add(this.CalcPCoABox);
            this.groupBox21.Controls.Add(this.CalcBayesianBox);
            this.groupBox21.Controls.Add(this.CalcRelatednessBox);
            this.groupBox21.Controls.Add(this.CalcAssignmentBox);
            this.groupBox21.Controls.Add(this.CalcHIndexBox);
            this.groupBox21.Controls.Add(this.CalcInbreedingBox);
            this.groupBox21.Controls.Add(this.CalcPhenotypeBox);
            this.groupBox21.Controls.Add(this.CalcDiffBox);
            this.groupBox21.Controls.Add(this.CalcLinkageBox);
            this.groupBox21.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox21.Location = new System.Drawing.Point(4, 4);
            this.groupBox21.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox21.Size = new System.Drawing.Size(277, 386);
            this.groupBox21.TabIndex = 6;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Methods";
            // 
            // CalcParentageBox
            // 
            this.CalcParentageBox.AutoSize = true;
            this.CalcParentageBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcParentageBox.Location = new System.Drawing.Point(16, 300);
            this.CalcParentageBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcParentageBox.Name = "CalcParentageBox";
            this.CalcParentageBox.Size = new System.Drawing.Size(152, 24);
            this.CalcParentageBox.TabIndex = 1;
            this.CalcParentageBox.Text = "Parentage analysis";
            this.CalcParentageBox.UseVisualStyleBackColor = true;
            this.CalcParentageBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcAMOVABox
            // 
            this.CalcAMOVABox.AutoSize = true;
            this.CalcAMOVABox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcAMOVABox.Location = new System.Drawing.Point(16, 328);
            this.CalcAMOVABox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcAMOVABox.Name = "CalcAMOVABox";
            this.CalcAMOVABox.Size = new System.Drawing.Size(83, 24);
            this.CalcAMOVABox.TabIndex = 0;
            this.CalcAMOVABox.Text = "AMOVA";
            this.CalcAMOVABox.UseVisualStyleBackColor = true;
            this.CalcAMOVABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcDistBox
            // 
            this.CalcDistBox.AutoSize = true;
            this.CalcDistBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcDistBox.Location = new System.Drawing.Point(16, 108);
            this.CalcDistBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcDistBox.Name = "CalcDistBox";
            this.CalcDistBox.Size = new System.Drawing.Size(140, 24);
            this.CalcDistBox.TabIndex = 0;
            this.CalcDistBox.Text = "Genetic distance";
            this.CalcDistBox.UseVisualStyleBackColor = true;
            this.CalcDistBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcClusteringBox
            // 
            this.CalcClusteringBox.AutoSize = true;
            this.CalcClusteringBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcClusteringBox.Location = new System.Drawing.Point(16, 162);
            this.CalcClusteringBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcClusteringBox.Name = "CalcClusteringBox";
            this.CalcClusteringBox.Size = new System.Drawing.Size(178, 24);
            this.CalcClusteringBox.TabIndex = 0;
            this.CalcClusteringBox.Text = "Hierarchical clustering";
            this.CalcClusteringBox.UseVisualStyleBackColor = true;
            this.CalcClusteringBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcPCoABox
            // 
            this.CalcPCoABox.AutoSize = true;
            this.CalcPCoABox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcPCoABox.Location = new System.Drawing.Point(16, 135);
            this.CalcPCoABox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcPCoABox.Name = "CalcPCoABox";
            this.CalcPCoABox.Size = new System.Drawing.Size(67, 24);
            this.CalcPCoABox.TabIndex = 0;
            this.CalcPCoABox.Text = "PCoA";
            this.CalcPCoABox.UseVisualStyleBackColor = true;
            this.CalcPCoABox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcBayesianBox
            // 
            this.CalcBayesianBox.AutoSize = true;
            this.CalcBayesianBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcBayesianBox.Location = new System.Drawing.Point(16, 355);
            this.CalcBayesianBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcBayesianBox.Name = "CalcBayesianBox";
            this.CalcBayesianBox.Size = new System.Drawing.Size(157, 24);
            this.CalcBayesianBox.TabIndex = 0;
            this.CalcBayesianBox.Text = "Bayesian clustering";
            this.CalcBayesianBox.UseVisualStyleBackColor = true;
            this.CalcBayesianBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcRelatednessBox
            // 
            this.CalcRelatednessBox.AutoSize = true;
            this.CalcRelatednessBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcRelatednessBox.Location = new System.Drawing.Point(16, 272);
            this.CalcRelatednessBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcRelatednessBox.Name = "CalcRelatednessBox";
            this.CalcRelatednessBox.Size = new System.Drawing.Size(163, 24);
            this.CalcRelatednessBox.TabIndex = 0;
            this.CalcRelatednessBox.Text = "Pairwise relatedness";
            this.CalcRelatednessBox.UseVisualStyleBackColor = true;
            this.CalcRelatednessBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcAssignmentBox
            // 
            this.CalcAssignmentBox.AutoSize = true;
            this.CalcAssignmentBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcAssignmentBox.Location = new System.Drawing.Point(16, 245);
            this.CalcAssignmentBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcAssignmentBox.Name = "CalcAssignmentBox";
            this.CalcAssignmentBox.Size = new System.Drawing.Size(181, 24);
            this.CalcAssignmentBox.TabIndex = 0;
            this.CalcAssignmentBox.Text = "Population assignment";
            this.CalcAssignmentBox.UseVisualStyleBackColor = true;
            this.CalcAssignmentBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcHIndexBox
            // 
            this.CalcHIndexBox.AutoSize = true;
            this.CalcHIndexBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcHIndexBox.Location = new System.Drawing.Point(16, 218);
            this.CalcHIndexBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcHIndexBox.Name = "CalcHIndexBox";
            this.CalcHIndexBox.Size = new System.Drawing.Size(153, 24);
            this.CalcHIndexBox.TabIndex = 0;
            this.CalcHIndexBox.Text = "Individual H-index";
            this.CalcHIndexBox.UseVisualStyleBackColor = true;
            this.CalcHIndexBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcInbreedingBox
            // 
            this.CalcInbreedingBox.AutoSize = true;
            this.CalcInbreedingBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcInbreedingBox.Location = new System.Drawing.Point(16, 190);
            this.CalcInbreedingBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcInbreedingBox.Name = "CalcInbreedingBox";
            this.CalcInbreedingBox.Size = new System.Drawing.Size(208, 24);
            this.CalcInbreedingBox.TabIndex = 0;
            this.CalcInbreedingBox.Text = "Individual inbreeding coef.";
            this.CalcInbreedingBox.UseVisualStyleBackColor = true;
            this.CalcInbreedingBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcPhenotypeBox
            // 
            this.CalcPhenotypeBox.AutoSize = true;
            this.CalcPhenotypeBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CalcPhenotypeBox.Location = new System.Drawing.Point(16, 25);
            this.CalcPhenotypeBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcPhenotypeBox.Name = "CalcPhenotypeBox";
            this.CalcPhenotypeBox.Size = new System.Drawing.Size(220, 24);
            this.CalcPhenotypeBox.TabIndex = 0;
            this.CalcPhenotypeBox.Text = "Pheno/geno distribution test";
            this.CalcPhenotypeBox.UseVisualStyleBackColor = true;
            this.CalcPhenotypeBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcDiffBox
            // 
            this.CalcDiffBox.AutoSize = true;
            this.CalcDiffBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcDiffBox.Location = new System.Drawing.Point(16, 80);
            this.CalcDiffBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcDiffBox.Name = "CalcDiffBox";
            this.CalcDiffBox.Size = new System.Drawing.Size(176, 24);
            this.CalcDiffBox.TabIndex = 0;
            this.CalcDiffBox.Text = "Genetic differentation";
            this.CalcDiffBox.UseVisualStyleBackColor = true;
            this.CalcDiffBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // CalcLinkageBox
            // 
            this.CalcLinkageBox.AutoSize = true;
            this.CalcLinkageBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CalcLinkageBox.Location = new System.Drawing.Point(16, 52);
            this.CalcLinkageBox.Margin = new System.Windows.Forms.Padding(4);
            this.CalcLinkageBox.Name = "CalcLinkageBox";
            this.CalcLinkageBox.Size = new System.Drawing.Size(209, 24);
            this.CalcLinkageBox.TabIndex = 0;
            this.CalcLinkageBox.Text = "Linkage disequilibrium test";
            this.CalcLinkageBox.UseVisualStyleBackColor = true;
            this.CalcLinkageBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.RelatednessRegBox);
            this.groupBox18.Controls.Add(this.RelatednessPopBox);
            this.groupBox18.Controls.Add(this.RelatednessLoiselle1995Box);
            this.groupBox18.Controls.Add(this.RelatednessRitland1996Box);
            this.groupBox18.Controls.Add(this.RelatednessHuang2015Box);
            this.groupBox18.Controls.Add(this.RelatednessLoiselle1995mBox);
            this.groupBox18.Controls.Add(this.label4);
            this.groupBox18.Controls.Add(this.label9);
            this.groupBox18.Controls.Add(this.RelatednessWeir1996Box);
            this.groupBox18.Controls.Add(this.RelatednessHuang2014Box);
            this.groupBox18.Controls.Add(this.RelatednessRitland1996mBox);
            this.groupBox18.Controls.Add(this.RelatednessTotBox);
            this.groupBox18.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox18.Location = new System.Drawing.Point(860, 145);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox18.Size = new System.Drawing.Size(277, 322);
            this.groupBox18.TabIndex = 6;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Pairwise relatedness";
            // 
            // RelatednessRegBox
            // 
            this.RelatednessRegBox.AutoSize = true;
            this.RelatednessRegBox.Location = new System.Drawing.Point(155, 45);
            this.RelatednessRegBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessRegBox.Name = "RelatednessRegBox";
            this.RelatednessRegBox.Size = new System.Drawing.Size(83, 24);
            this.RelatednessRegBox.TabIndex = 404;
            this.RelatednessRegBox.Text = "Region";
            this.RelatednessRegBox.UseVisualStyleBackColor = true;
            this.RelatednessRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessPopBox
            // 
            this.RelatednessPopBox.AutoSize = true;
            this.RelatednessPopBox.Location = new System.Drawing.Point(27, 45);
            this.RelatednessPopBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessPopBox.Name = "RelatednessPopBox";
            this.RelatednessPopBox.Size = new System.Drawing.Size(110, 24);
            this.RelatednessPopBox.TabIndex = 404;
            this.RelatednessPopBox.Text = "Population";
            this.RelatednessPopBox.UseVisualStyleBackColor = true;
            this.RelatednessPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessLoiselle1995Box
            // 
            this.RelatednessLoiselle1995Box.AutoSize = true;
            this.RelatednessLoiselle1995Box.Location = new System.Drawing.Point(27, 266);
            this.RelatednessLoiselle1995Box.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessLoiselle1995Box.Name = "RelatednessLoiselle1995Box";
            this.RelatednessLoiselle1995Box.Size = new System.Drawing.Size(126, 24);
            this.RelatednessLoiselle1995Box.TabIndex = 0;
            this.RelatednessLoiselle1995Box.Text = "Loiselle 1995";
            this.RelatednessLoiselle1995Box.UseVisualStyleBackColor = true;
            this.RelatednessLoiselle1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessRitland1996Box
            // 
            this.RelatednessRitland1996Box.AutoSize = true;
            this.RelatednessRitland1996Box.Location = new System.Drawing.Point(27, 239);
            this.RelatednessRitland1996Box.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessRitland1996Box.Name = "RelatednessRitland1996Box";
            this.RelatednessRitland1996Box.Size = new System.Drawing.Size(122, 24);
            this.RelatednessRitland1996Box.TabIndex = 0;
            this.RelatednessRitland1996Box.Text = "Ritland 1996";
            this.RelatednessRitland1996Box.UseVisualStyleBackColor = true;
            this.RelatednessRitland1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessHuang2015Box
            // 
            this.RelatednessHuang2015Box.AutoSize = true;
            this.RelatednessHuang2015Box.Location = new System.Drawing.Point(27, 155);
            this.RelatednessHuang2015Box.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessHuang2015Box.Name = "RelatednessHuang2015Box";
            this.RelatednessHuang2015Box.Size = new System.Drawing.Size(238, 24);
            this.RelatednessHuang2015Box.TabIndex = 0;
            this.RelatednessHuang2015Box.Text = "Huang et al. 2015 Likelihood";
            this.RelatednessHuang2015Box.UseVisualStyleBackColor = true;
            this.RelatednessHuang2015Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessLoiselle1995mBox
            // 
            this.RelatednessLoiselle1995mBox.AutoSize = true;
            this.RelatednessLoiselle1995mBox.Location = new System.Drawing.Point(27, 210);
            this.RelatednessLoiselle1995mBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessLoiselle1995mBox.Name = "RelatednessLoiselle1995mBox";
            this.RelatednessLoiselle1995mBox.Size = new System.Drawing.Size(196, 24);
            this.RelatednessLoiselle1995mBox.TabIndex = 0;
            this.RelatednessLoiselle1995mBox.Text = "modified Loiselle 1995";
            this.RelatednessLoiselle1995mBox.UseVisualStyleBackColor = true;
            this.RelatednessLoiselle1995mBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 20);
            this.label4.TabIndex = 401;
            this.label4.Text = "Range";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 102);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 20);
            this.label9.TabIndex = 401;
            this.label9.Text = "Estimators";
            // 
            // RelatednessWeir1996Box
            // 
            this.RelatednessWeir1996Box.AutoSize = true;
            this.RelatednessWeir1996Box.Location = new System.Drawing.Point(27, 294);
            this.RelatednessWeir1996Box.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessWeir1996Box.Name = "RelatednessWeir1996Box";
            this.RelatednessWeir1996Box.Size = new System.Drawing.Size(105, 24);
            this.RelatednessWeir1996Box.TabIndex = 0;
            this.RelatednessWeir1996Box.Text = "Weir 1996";
            this.RelatednessWeir1996Box.UseVisualStyleBackColor = true;
            this.RelatednessWeir1996Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessHuang2014Box
            // 
            this.RelatednessHuang2014Box.AutoSize = true;
            this.RelatednessHuang2014Box.Location = new System.Drawing.Point(27, 128);
            this.RelatednessHuang2014Box.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessHuang2014Box.Name = "RelatednessHuang2014Box";
            this.RelatednessHuang2014Box.Size = new System.Drawing.Size(225, 24);
            this.RelatednessHuang2014Box.TabIndex = 0;
            this.RelatednessHuang2014Box.Text = "Huang et al. 2014 Moment";
            this.RelatednessHuang2014Box.UseVisualStyleBackColor = true;
            this.RelatednessHuang2014Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessRitland1996mBox
            // 
            this.RelatednessRitland1996mBox.AutoSize = true;
            this.RelatednessRitland1996mBox.Location = new System.Drawing.Point(27, 182);
            this.RelatednessRitland1996mBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessRitland1996mBox.Name = "RelatednessRitland1996mBox";
            this.RelatednessRitland1996mBox.Size = new System.Drawing.Size(192, 24);
            this.RelatednessRitland1996mBox.TabIndex = 0;
            this.RelatednessRitland1996mBox.Text = "modified Ritland 1996";
            this.RelatednessRitland1996mBox.UseVisualStyleBackColor = true;
            this.RelatednessRitland1996mBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // RelatednessTotBox
            // 
            this.RelatednessTotBox.AutoSize = true;
            this.RelatednessTotBox.Location = new System.Drawing.Point(27, 72);
            this.RelatednessTotBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessTotBox.Name = "RelatednessTotBox";
            this.RelatednessTotBox.Size = new System.Drawing.Size(152, 24);
            this.RelatednessTotBox.TabIndex = 0;
            this.RelatednessTotBox.Text = "Total population";
            this.RelatednessTotBox.UseVisualStyleBackColor = true;
            this.RelatednessTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.GlobalNullAlleleBox);
            this.groupBox13.Controls.Add(this.button5);
            this.groupBox13.Controls.Add(this.button4);
            this.groupBox13.Controls.Add(this.label40);
            this.groupBox13.Controls.Add(this.GlobalSeedBox);
            this.groupBox13.Controls.Add(this.GlobalThreadBox);
            this.groupBox13.Controls.Add(this.GlobalRefreshSeedBox);
            this.groupBox13.Controls.Add(this.GlobalWarningBox);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.GlobalDecimalPlaceBox);
            this.groupBox13.Controls.Add(this.label10);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox13.Location = new System.Drawing.Point(4, 399);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(277, 279);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "General";
            // 
            // GlobalNullAlleleBox
            // 
            this.GlobalNullAlleleBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalNullAlleleBox.Location = new System.Drawing.Point(156, 90);
            this.GlobalNullAlleleBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalNullAlleleBox.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.GlobalNullAlleleBox.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.GlobalNullAlleleBox.Name = "GlobalNullAlleleBox";
            this.GlobalNullAlleleBox.Size = new System.Drawing.Size(99, 27);
            this.GlobalNullAlleleBox.TabIndex = 301;
            this.GlobalNullAlleleBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button5.Location = new System.Drawing.Point(20, 236);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(235, 29);
            this.button5.TabIndex = 507;
            this.button5.Text = "Default Settings";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button4.Location = new System.Drawing.Point(29, 145);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 29);
            this.button4.TabIndex = 507;
            this.button4.Text = "Randomize";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label40.Location = new System.Drawing.Point(13, 95);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(140, 20);
            this.label40.TabIndex = 3;
            this.label40.Text = "Null allele Identifier";
            // 
            // GlobalSeedBox
            // 
            this.GlobalSeedBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalSeedBox.Location = new System.Drawing.Point(156, 149);
            this.GlobalSeedBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalSeedBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.GlobalSeedBox.Name = "GlobalSeedBox";
            this.GlobalSeedBox.Size = new System.Drawing.Size(99, 27);
            this.GlobalSeedBox.TabIndex = 506;
            this.GlobalSeedBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalThreadBox
            // 
            this.GlobalThreadBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalThreadBox.Location = new System.Drawing.Point(156, 56);
            this.GlobalThreadBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalThreadBox.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.GlobalThreadBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.GlobalThreadBox.Name = "GlobalThreadBox";
            this.GlobalThreadBox.Size = new System.Drawing.Size(99, 27);
            this.GlobalThreadBox.TabIndex = 506;
            this.GlobalThreadBox.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.GlobalThreadBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalRefreshSeedBox
            // 
            this.GlobalRefreshSeedBox.AutoSize = true;
            this.GlobalRefreshSeedBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalRefreshSeedBox.Location = new System.Drawing.Point(16, 181);
            this.GlobalRefreshSeedBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalRefreshSeedBox.Name = "GlobalRefreshSeedBox";
            this.GlobalRefreshSeedBox.Size = new System.Drawing.Size(198, 24);
            this.GlobalRefreshSeedBox.TabIndex = 505;
            this.GlobalRefreshSeedBox.Text = "Automatelly update seed";
            this.GlobalRefreshSeedBox.UseVisualStyleBackColor = true;
            this.GlobalRefreshSeedBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // GlobalWarningBox
            // 
            this.GlobalWarningBox.AutoSize = true;
            this.GlobalWarningBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalWarningBox.Location = new System.Drawing.Point(16, 209);
            this.GlobalWarningBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalWarningBox.Name = "GlobalWarningBox";
            this.GlobalWarningBox.Size = new System.Drawing.Size(133, 24);
            this.GlobalWarningBox.TabIndex = 505;
            this.GlobalWarningBox.Text = "Enable warning";
            this.GlobalWarningBox.UseVisualStyleBackColor = true;
            this.GlobalWarningBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label45.Location = new System.Drawing.Point(13, 122);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(224, 20);
            this.label45.TabIndex = 5;
            this.label45.Text = "Random number generator seed";
            // 
            // GlobalDecimalPlaceBox
            // 
            this.GlobalDecimalPlaceBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GlobalDecimalPlaceBox.Location = new System.Drawing.Point(156, 21);
            this.GlobalDecimalPlaceBox.Margin = new System.Windows.Forms.Padding(4);
            this.GlobalDecimalPlaceBox.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.Name = "GlobalDecimalPlaceBox";
            this.GlobalDecimalPlaceBox.Size = new System.Drawing.Size(99, 27);
            this.GlobalDecimalPlaceBox.TabIndex = 500;
            this.GlobalDecimalPlaceBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.GlobalDecimalPlaceBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label10.Location = new System.Drawing.Point(13, 59);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 20);
            this.label10.TabIndex = 5;
            this.label10.Text = "#Threads";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label20.Location = new System.Drawing.Point(13, 24);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(110, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Decimal places";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label101);
            this.groupBox20.Controls.Add(this.LinkageIterationsBox);
            this.groupBox20.Controls.Add(this.LinkageBurninBox);
            this.groupBox20.Controls.Add(this.LinkageBatchesBox);
            this.groupBox20.Controls.Add(this.label84);
            this.groupBox20.Controls.Add(this.label85);
            this.groupBox20.Controls.Add(this.label86);
            this.groupBox20.Controls.Add(this.LinkageTestTotBox);
            this.groupBox20.Controls.Add(this.LinkageTestPermBox);
            this.groupBox20.Controls.Add(this.LinkageTestRegBox);
            this.groupBox20.Controls.Add(this.LinkageTestPopBox);
            this.groupBox20.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox20.Location = new System.Drawing.Point(289, 122);
            this.groupBox20.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox20.Size = new System.Drawing.Size(277, 242);
            this.groupBox20.TabIndex = 6;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Linkage disequilibrium test";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label101.Location = new System.Drawing.Point(11, 22);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(55, 20);
            this.label101.TabIndex = 519;
            this.label101.Text = "Range";
            // 
            // LinkageIterationsBox
            // 
            this.LinkageIterationsBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageIterationsBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageIterationsBox.Location = new System.Drawing.Point(133, 205);
            this.LinkageIterationsBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageIterationsBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.LinkageIterationsBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageIterationsBox.Name = "LinkageIterationsBox";
            this.LinkageIterationsBox.Size = new System.Drawing.Size(112, 27);
            this.LinkageIterationsBox.TabIndex = 516;
            this.LinkageIterationsBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.LinkageIterationsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageBurninBox
            // 
            this.LinkageBurninBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageBurninBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageBurninBox.Location = new System.Drawing.Point(133, 135);
            this.LinkageBurninBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageBurninBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.LinkageBurninBox.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.LinkageBurninBox.Name = "LinkageBurninBox";
            this.LinkageBurninBox.Size = new System.Drawing.Size(112, 27);
            this.LinkageBurninBox.TabIndex = 517;
            this.LinkageBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.LinkageBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageBatchesBox
            // 
            this.LinkageBatchesBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageBatchesBox.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LinkageBatchesBox.Location = new System.Drawing.Point(133, 170);
            this.LinkageBatchesBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageBatchesBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.LinkageBatchesBox.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.LinkageBatchesBox.Name = "LinkageBatchesBox";
            this.LinkageBatchesBox.Size = new System.Drawing.Size(112, 27);
            this.LinkageBatchesBox.TabIndex = 518;
            this.LinkageBatchesBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.LinkageBatchesBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label84.Location = new System.Drawing.Point(12, 209);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(88, 20);
            this.label84.TabIndex = 514;
            this.label84.Text = "#Iterations";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label85.Location = new System.Drawing.Point(12, 139);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(65, 20);
            this.label85.TabIndex = 513;
            this.label85.Text = "#Burnin";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label86.Location = new System.Drawing.Point(12, 174);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(75, 20);
            this.label86.TabIndex = 515;
            this.label86.Text = "#Batches";
            // 
            // LinkageTestTotBox
            // 
            this.LinkageTestTotBox.AutoSize = true;
            this.LinkageTestTotBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageTestTotBox.Location = new System.Drawing.Point(27, 76);
            this.LinkageTestTotBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageTestTotBox.Name = "LinkageTestTotBox";
            this.LinkageTestTotBox.Size = new System.Drawing.Size(152, 24);
            this.LinkageTestTotBox.TabIndex = 0;
            this.LinkageTestTotBox.Text = "Total population";
            this.LinkageTestTotBox.UseVisualStyleBackColor = true;
            this.LinkageTestTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageTestPermBox
            // 
            this.LinkageTestPermBox.AutoSize = true;
            this.LinkageTestPermBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageTestPermBox.Location = new System.Drawing.Point(16, 108);
            this.LinkageTestPermBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageTestPermBox.Name = "LinkageTestPermBox";
            this.LinkageTestPermBox.Size = new System.Drawing.Size(162, 24);
            this.LinkageTestPermBox.TabIndex = 0;
            this.LinkageTestPermBox.Text = "Markov Chain test";
            this.LinkageTestPermBox.UseVisualStyleBackColor = true;
            this.LinkageTestPermBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageTestRegBox
            // 
            this.LinkageTestRegBox.AutoSize = true;
            this.LinkageTestRegBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageTestRegBox.Location = new System.Drawing.Point(149, 45);
            this.LinkageTestRegBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageTestRegBox.Name = "LinkageTestRegBox";
            this.LinkageTestRegBox.Size = new System.Drawing.Size(83, 24);
            this.LinkageTestRegBox.TabIndex = 0;
            this.LinkageTestRegBox.Text = "Region";
            this.LinkageTestRegBox.UseVisualStyleBackColor = true;
            this.LinkageTestRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // LinkageTestPopBox
            // 
            this.LinkageTestPopBox.AutoSize = true;
            this.LinkageTestPopBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.LinkageTestPopBox.Location = new System.Drawing.Point(27, 45);
            this.LinkageTestPopBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageTestPopBox.Name = "LinkageTestPopBox";
            this.LinkageTestPopBox.Size = new System.Drawing.Size(110, 24);
            this.LinkageTestPopBox.TabIndex = 0;
            this.LinkageTestPopBox.Text = "Population";
            this.LinkageTestPopBox.UseVisualStyleBackColor = true;
            this.LinkageTestPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.FrequencyRemoveDupAlleleBox);
            this.groupBox15.Controls.Add(this.FrequencySelfingBox);
            this.groupBox15.Controls.Add(this.FrequencyNegPCRBox);
            this.groupBox15.Controls.Add(this.FrequencyNullAlleleBox);
            this.groupBox15.Controls.Add(this.FrequencyGenotypicModeBox);
            this.groupBox15.Controls.Add(this.label43);
            this.groupBox15.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox15.Location = new System.Drawing.Point(4, 684);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(277, 226);
            this.groupBox15.TabIndex = 3;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Allele frequency";
            // 
            // FrequencyRemoveDupAlleleBox
            // 
            this.FrequencyRemoveDupAlleleBox.AutoSize = true;
            this.FrequencyRemoveDupAlleleBox.Location = new System.Drawing.Point(16, 25);
            this.FrequencyRemoveDupAlleleBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencyRemoveDupAlleleBox.Name = "FrequencyRemoveDupAlleleBox";
            this.FrequencyRemoveDupAlleleBox.Size = new System.Drawing.Size(212, 44);
            this.FrequencyRemoveDupAlleleBox.TabIndex = 300;
            this.FrequencyRemoveDupAlleleBox.Text = "Remove duplicate alleles\r\n in phenotype";
            this.FrequencyRemoveDupAlleleBox.UseVisualStyleBackColor = true;
            this.FrequencyRemoveDupAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencySelfingBox
            // 
            this.FrequencySelfingBox.AutoSize = true;
            this.FrequencySelfingBox.Location = new System.Drawing.Point(16, 130);
            this.FrequencySelfingBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencySelfingBox.Name = "FrequencySelfingBox";
            this.FrequencySelfingBox.Size = new System.Drawing.Size(148, 24);
            this.FrequencySelfingBox.TabIndex = 300;
            this.FrequencySelfingBox.Text = "Consider selfing";
            this.FrequencySelfingBox.UseVisualStyleBackColor = true;
            this.FrequencySelfingBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyNegPCRBox
            // 
            this.FrequencyNegPCRBox.AutoSize = true;
            this.FrequencyNegPCRBox.Location = new System.Drawing.Point(16, 100);
            this.FrequencyNegPCRBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencyNegPCRBox.Name = "FrequencyNegPCRBox";
            this.FrequencyNegPCRBox.Size = new System.Drawing.Size(196, 24);
            this.FrequencyNegPCRBox.TabIndex = 300;
            this.FrequencyNegPCRBox.Text = "Consider negative PCR";
            this.FrequencyNegPCRBox.UseVisualStyleBackColor = true;
            this.FrequencyNegPCRBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyNullAlleleBox
            // 
            this.FrequencyNullAlleleBox.AutoSize = true;
            this.FrequencyNullAlleleBox.Location = new System.Drawing.Point(16, 70);
            this.FrequencyNullAlleleBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencyNullAlleleBox.Name = "FrequencyNullAlleleBox";
            this.FrequencyNullAlleleBox.Size = new System.Drawing.Size(175, 24);
            this.FrequencyNullAlleleBox.TabIndex = 300;
            this.FrequencyNullAlleleBox.Text = "Consider null alleles";
            this.FrequencyNullAlleleBox.UseVisualStyleBackColor = true;
            this.FrequencyNullAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // FrequencyGenotypicModeBox
            // 
            this.FrequencyGenotypicModeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FrequencyGenotypicModeBox.FormattingEnabled = true;
            this.FrequencyGenotypicModeBox.Items.AddRange(new object[] {
            "RCS",
            "PRCS",
            "CES",
            "PES rs = 0.25",
            "PES rs = 0.5",
            "PES estimate rs"});
            this.FrequencyGenotypicModeBox.Location = new System.Drawing.Point(37, 182);
            this.FrequencyGenotypicModeBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencyGenotypicModeBox.Name = "FrequencyGenotypicModeBox";
            this.FrequencyGenotypicModeBox.Size = new System.Drawing.Size(212, 28);
            this.FrequencyGenotypicModeBox.TabIndex = 400;
            this.FrequencyGenotypicModeBox.SelectedIndexChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(15, 159);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(190, 20);
            this.label43.TabIndex = 5;
            this.label43.Text = "Double-reduction model";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.DistRegBox);
            this.groupBox24.Controls.Add(this.DistPopBox);
            this.groupBox24.Controls.Add(this.DistIndBox);
            this.groupBox24.Controls.Add(this.label89);
            this.groupBox24.Controls.Add(this.label50);
            this.groupBox24.Controls.Add(this.label38);
            this.groupBox24.Controls.Add(this.DistSlatkinBox);
            this.groupBox24.Controls.Add(this.DistRoger1973Box);
            this.groupBox24.Controls.Add(this.DistNei1983Box);
            this.groupBox24.Controls.Add(this.DistReynolds1983Box);
            this.groupBox24.Controls.Add(this.DistNei1973Box);
            this.groupBox24.Controls.Add(this.DistReynold1993Box);
            this.groupBox24.Controls.Add(this.DistGoldstein1995Box);
            this.groupBox24.Controls.Add(this.DistCavalli1967Box);
            this.groupBox24.Controls.Add(this.DistEuclideanBox);
            this.groupBox24.Controls.Add(this.DistNei1972Box);
            this.groupBox24.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox24.Location = new System.Drawing.Point(575, 4);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox24.Size = new System.Drawing.Size(277, 471);
            this.groupBox24.TabIndex = 6;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Genetic distance";
            // 
            // DistRegBox
            // 
            this.DistRegBox.AutoSize = true;
            this.DistRegBox.Location = new System.Drawing.Point(27, 75);
            this.DistRegBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistRegBox.Name = "DistRegBox";
            this.DistRegBox.Size = new System.Drawing.Size(83, 24);
            this.DistRegBox.TabIndex = 406;
            this.DistRegBox.Text = "Region";
            this.DistRegBox.UseVisualStyleBackColor = true;
            this.DistRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistPopBox
            // 
            this.DistPopBox.AutoSize = true;
            this.DistPopBox.Location = new System.Drawing.Point(147, 48);
            this.DistPopBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistPopBox.Name = "DistPopBox";
            this.DistPopBox.Size = new System.Drawing.Size(110, 24);
            this.DistPopBox.TabIndex = 405;
            this.DistPopBox.Text = "Population";
            this.DistPopBox.UseVisualStyleBackColor = true;
            this.DistPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistIndBox
            // 
            this.DistIndBox.AutoSize = true;
            this.DistIndBox.Location = new System.Drawing.Point(27, 48);
            this.DistIndBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistIndBox.Name = "DistIndBox";
            this.DistIndBox.Size = new System.Drawing.Size(101, 24);
            this.DistIndBox.TabIndex = 404;
            this.DistIndBox.Text = "Individual";
            this.DistIndBox.UseVisualStyleBackColor = true;
            this.DistIndBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(20, 420);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(164, 40);
            this.label89.TabIndex = 403;
            this.label89.Text = "Select Fst estimators \r\non the left";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(11, 105);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(85, 20);
            this.label50.TabIndex = 403;
            this.label50.Text = "Estimators";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(11, 22);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 20);
            this.label38.TabIndex = 403;
            this.label38.Text = "Range";
            // 
            // DistSlatkinBox
            // 
            this.DistSlatkinBox.AutoSize = true;
            this.DistSlatkinBox.Location = new System.Drawing.Point(21, 395);
            this.DistSlatkinBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistSlatkinBox.Name = "DistSlatkinBox";
            this.DistSlatkinBox.Size = new System.Drawing.Size(189, 24);
            this.DistSlatkinBox.TabIndex = 0;
            this.DistSlatkinBox.Text = "Slatkin\'s linearized Fst";
            this.DistSlatkinBox.UseVisualStyleBackColor = true;
            this.DistSlatkinBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistRoger1973Box
            // 
            this.DistRoger1973Box.AutoSize = true;
            this.DistRoger1973Box.Location = new System.Drawing.Point(21, 321);
            this.DistRoger1973Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistRoger1973Box.Name = "DistRoger1973Box";
            this.DistRoger1973Box.Size = new System.Drawing.Size(145, 24);
            this.DistRoger1973Box.TabIndex = 0;
            this.DistRoger1973Box.Text = "Roger 1972 DR ";
            this.DistRoger1973Box.UseVisualStyleBackColor = true;
            this.DistRoger1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistNei1983Box
            // 
            this.DistNei1983Box.AutoSize = true;
            this.DistNei1983Box.Location = new System.Drawing.Point(21, 211);
            this.DistNei1983Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistNei1983Box.Name = "DistNei1983Box";
            this.DistNei1983Box.Size = new System.Drawing.Size(122, 24);
            this.DistNei1983Box.TabIndex = 0;
            this.DistNei1983Box.Text = "Nei 1983 DA";
            this.DistNei1983Box.UseVisualStyleBackColor = true;
            this.DistNei1983Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistReynolds1983Box
            // 
            this.DistReynolds1983Box.AutoSize = true;
            this.DistReynolds1983Box.Location = new System.Drawing.Point(21, 349);
            this.DistReynolds1983Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistReynolds1983Box.Name = "DistReynolds1983Box";
            this.DistReynolds1983Box.Size = new System.Drawing.Size(196, 44);
            this.DistReynolds1983Box.TabIndex = 0;
            this.DistReynolds1983Box.Text = "Reynolds et al. 1983 D \r\n   (transform Fst)";
            this.DistReynolds1983Box.UseVisualStyleBackColor = true;
            this.DistReynolds1983Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistNei1973Box
            // 
            this.DistNei1973Box.AutoSize = true;
            this.DistNei1973Box.Location = new System.Drawing.Point(21, 294);
            this.DistNei1973Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistNei1973Box.Name = "DistNei1973Box";
            this.DistNei1973Box.Size = new System.Drawing.Size(125, 24);
            this.DistNei1973Box.TabIndex = 0;
            this.DistNei1973Box.Text = "Nei 1973 Dm";
            this.DistNei1973Box.UseVisualStyleBackColor = true;
            this.DistNei1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistReynold1993Box
            // 
            this.DistReynold1993Box.AutoSize = true;
            this.DistReynold1993Box.Location = new System.Drawing.Point(21, 184);
            this.DistReynold1993Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistReynold1993Box.Name = "DistReynold1993Box";
            this.DistReynold1993Box.Size = new System.Drawing.Size(206, 24);
            this.DistReynold1993Box.TabIndex = 0;
            this.DistReynold1993Box.Text = "Reynolds et al 1983  θW";
            this.DistReynold1993Box.UseVisualStyleBackColor = true;
            this.DistReynold1993Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistGoldstein1995Box
            // 
            this.DistGoldstein1995Box.AutoSize = true;
            this.DistGoldstein1995Box.Location = new System.Drawing.Point(21, 266);
            this.DistGoldstein1995Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistGoldstein1995Box.Name = "DistGoldstein1995Box";
            this.DistGoldstein1995Box.Size = new System.Drawing.Size(173, 24);
            this.DistGoldstein1995Box.TabIndex = 0;
            this.DistGoldstein1995Box.Text = "Goldstein 1995 dμ2";
            this.DistGoldstein1995Box.UseVisualStyleBackColor = true;
            this.DistGoldstein1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistCavalli1967Box
            // 
            this.DistCavalli1967Box.AutoSize = true;
            this.DistCavalli1967Box.Location = new System.Drawing.Point(21, 156);
            this.DistCavalli1967Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistCavalli1967Box.Name = "DistCavalli1967Box";
            this.DistCavalli1967Box.Size = new System.Drawing.Size(205, 24);
            this.DistCavalli1967Box.TabIndex = 0;
            this.DistCavalli1967Box.Text = "Cavalli-Sforza 1967 DCH";
            this.DistCavalli1967Box.UseVisualStyleBackColor = true;
            this.DistCavalli1967Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistEuclideanBox
            // 
            this.DistEuclideanBox.AutoSize = true;
            this.DistEuclideanBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DistEuclideanBox.Location = new System.Drawing.Point(21, 239);
            this.DistEuclideanBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistEuclideanBox.Name = "DistEuclideanBox";
            this.DistEuclideanBox.Size = new System.Drawing.Size(95, 24);
            this.DistEuclideanBox.TabIndex = 0;
            this.DistEuclideanBox.Text = "Euclidean";
            this.DistEuclideanBox.UseVisualStyleBackColor = true;
            this.DistEuclideanBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DistNei1972Box
            // 
            this.DistNei1972Box.AutoSize = true;
            this.DistNei1972Box.Location = new System.Drawing.Point(21, 129);
            this.DistNei1972Box.Margin = new System.Windows.Forms.Padding(4);
            this.DistNei1972Box.Name = "DistNei1972Box";
            this.DistNei1972Box.Size = new System.Drawing.Size(188, 24);
            this.DistNei1972Box.TabIndex = 0;
            this.DistNei1972Box.Text = "Nei 1972 standard DS";
            this.DistNei1972Box.UseVisualStyleBackColor = true;
            this.DistNei1972Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.AMOVAMLBox);
            this.groupBox7.Controls.Add(this.AMOVAGenotypeBox);
            this.groupBox7.Controls.Add(this.AMOVAAnisoBox);
            this.groupBox7.Controls.Add(this.AMOVAHomoBox);
            this.groupBox7.Controls.Add(this.AMOVASMMBox);
            this.groupBox7.Controls.Add(this.AMOVAIAMBox);
            this.groupBox7.Controls.Add(this.AMOVAIgnoreIndBox);
            this.groupBox7.Controls.Add(this.AMOVARegionBox);
            this.groupBox7.Controls.Add(this.AMOVANPermBox);
            this.groupBox7.Controls.Add(this.label102);
            this.groupBox7.Controls.Add(this.label58);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox7.Location = new System.Drawing.Point(860, 475);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(277, 434);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "AMOVA";
            // 
            // AMOVAMLBox
            // 
            this.AMOVAMLBox.AutoSize = true;
            this.AMOVAMLBox.Location = new System.Drawing.Point(27, 154);
            this.AMOVAMLBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAMLBox.Name = "AMOVAMLBox";
            this.AMOVAMLBox.Size = new System.Drawing.Size(225, 24);
            this.AMOVAMLBox.TabIndex = 509;
            this.AMOVAMLBox.Text = "Maximum-likelihood (IAM)";
            this.AMOVAMLBox.UseVisualStyleBackColor = true;
            // 
            // AMOVAGenotypeBox
            // 
            this.AMOVAGenotypeBox.AutoSize = true;
            this.AMOVAGenotypeBox.Location = new System.Drawing.Point(27, 128);
            this.AMOVAGenotypeBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAGenotypeBox.Name = "AMOVAGenotypeBox";
            this.AMOVAGenotypeBox.Size = new System.Drawing.Size(159, 24);
            this.AMOVAGenotypeBox.TabIndex = 509;
            this.AMOVAGenotypeBox.Text = "Weight genotype";
            this.AMOVAGenotypeBox.UseVisualStyleBackColor = true;
            // 
            // AMOVAAnisoBox
            // 
            this.AMOVAAnisoBox.AutoSize = true;
            this.AMOVAAnisoBox.Location = new System.Drawing.Point(27, 101);
            this.AMOVAAnisoBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAAnisoBox.Name = "AMOVAAnisoBox";
            this.AMOVAAnisoBox.Size = new System.Drawing.Size(110, 24);
            this.AMOVAAnisoBox.TabIndex = 509;
            this.AMOVAAnisoBox.Text = "Anisoploid";
            this.AMOVAAnisoBox.UseVisualStyleBackColor = true;
            // 
            // AMOVAHomoBox
            // 
            this.AMOVAHomoBox.AutoSize = true;
            this.AMOVAHomoBox.Location = new System.Drawing.Point(27, 75);
            this.AMOVAHomoBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAHomoBox.Name = "AMOVAHomoBox";
            this.AMOVAHomoBox.Size = new System.Drawing.Size(115, 24);
            this.AMOVAHomoBox.TabIndex = 509;
            this.AMOVAHomoBox.Text = "Homoploid";
            this.AMOVAHomoBox.UseVisualStyleBackColor = true;
            // 
            // AMOVASMMBox
            // 
            this.AMOVASMMBox.AutoSize = true;
            this.AMOVASMMBox.Location = new System.Drawing.Point(180, 22);
            this.AMOVASMMBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVASMMBox.Name = "AMOVASMMBox";
            this.AMOVASMMBox.Size = new System.Drawing.Size(70, 24);
            this.AMOVASMMBox.TabIndex = 508;
            this.AMOVASMMBox.Text = "SMM";
            this.AMOVASMMBox.UseVisualStyleBackColor = true;
            this.AMOVASMMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAIAMBox
            // 
            this.AMOVAIAMBox.AutoSize = true;
            this.AMOVAIAMBox.Location = new System.Drawing.Point(96, 22);
            this.AMOVAIAMBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAIAMBox.Name = "AMOVAIAMBox";
            this.AMOVAIAMBox.Size = new System.Drawing.Size(61, 24);
            this.AMOVAIAMBox.TabIndex = 508;
            this.AMOVAIAMBox.Text = "IAM";
            this.AMOVAIAMBox.UseVisualStyleBackColor = true;
            this.AMOVAIAMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVAIgnoreIndBox
            // 
            this.AMOVAIgnoreIndBox.AutoSize = true;
            this.AMOVAIgnoreIndBox.Location = new System.Drawing.Point(15, 181);
            this.AMOVAIgnoreIndBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAIgnoreIndBox.Name = "AMOVAIgnoreIndBox";
            this.AMOVAIgnoreIndBox.Size = new System.Drawing.Size(191, 24);
            this.AMOVAIgnoreIndBox.TabIndex = 507;
            this.AMOVAIgnoreIndBox.Text = "Ignore individual level";
            this.AMOVAIgnoreIndBox.UseVisualStyleBackColor = true;
            this.AMOVAIgnoreIndBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVARegionBox
            // 
            this.AMOVARegionBox.AcceptsReturn = true;
            this.AMOVARegionBox.AcceptsTab = true;
            this.AMOVARegionBox.HideSelection = false;
            this.AMOVARegionBox.Location = new System.Drawing.Point(19, 236);
            this.AMOVARegionBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVARegionBox.Multiline = true;
            this.AMOVARegionBox.Name = "AMOVARegionBox";
            this.AMOVARegionBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.AMOVARegionBox.Size = new System.Drawing.Size(236, 150);
            this.AMOVARegionBox.TabIndex = 403;
            this.AMOVARegionBox.Text = "A1:pop1,pop2\r\nA2:pop3\r\nNEXTLEVEL\r\nB1:A1,A2";
            this.AMOVARegionBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AMOVANPermBox
            // 
            this.AMOVANPermBox.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.AMOVANPermBox.Location = new System.Drawing.Point(135, 395);
            this.AMOVANPermBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVANPermBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.AMOVANPermBox.Name = "AMOVANPermBox";
            this.AMOVANPermBox.Size = new System.Drawing.Size(112, 27);
            this.AMOVANPermBox.TabIndex = 506;
            this.AMOVANPermBox.Value = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.AMOVANPermBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(12, 50);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(57, 20);
            this.label102.TabIndex = 402;
            this.label102.Text = "Model";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(12, 25);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(71, 20);
            this.label58.TabIndex = 402;
            this.label58.Text = "Distance";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 211);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 20);
            this.label7.TabIndex = 402;
            this.label7.Text = "Region definition";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 399);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "#Permutation";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.AssignmentErrorBox);
            this.groupBox16.Controls.Add(this.AssignmentPloidyBox);
            this.groupBox16.Controls.Add(this.label8);
            this.groupBox16.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox16.Location = new System.Drawing.Point(1145, 648);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox16.Size = new System.Drawing.Size(277, 98);
            this.groupBox16.TabIndex = 6;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Population assignment";
            // 
            // AssignmentErrorBox
            // 
            this.AssignmentErrorBox.DecimalPlaces = 4;
            this.AssignmentErrorBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.AssignmentErrorBox.Location = new System.Drawing.Point(139, 55);
            this.AssignmentErrorBox.Margin = new System.Windows.Forms.Padding(4);
            this.AssignmentErrorBox.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.AssignmentErrorBox.Name = "AssignmentErrorBox";
            this.AssignmentErrorBox.Size = new System.Drawing.Size(112, 27);
            this.AssignmentErrorBox.TabIndex = 202;
            this.AssignmentErrorBox.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.AssignmentErrorBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // AssignmentPloidyBox
            // 
            this.AssignmentPloidyBox.AutoSize = true;
            this.AssignmentPloidyBox.Location = new System.Drawing.Point(13, 25);
            this.AssignmentPloidyBox.Margin = new System.Windows.Forms.Padding(4);
            this.AssignmentPloidyBox.Name = "AssignmentPloidyBox";
            this.AssignmentPloidyBox.Size = new System.Drawing.Size(216, 24);
            this.AssignmentPloidyBox.TabIndex = 0;
            this.AssignmentPloidyBox.Text = "Skip pops with diff ploidy\r\n";
            this.AssignmentPloidyBox.UseVisualStyleBackColor = true;
            this.AssignmentPloidyBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 59);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Mistyping rate";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label87);
            this.groupBox23.Controls.Add(this.DiffRegBox);
            this.groupBox23.Controls.Add(this.DiffTotBox);
            this.groupBox23.Controls.Add(this.DiffPopBox);
            this.groupBox23.Controls.Add(this.label66);
            this.groupBox23.Controls.Add(this.label65);
            this.groupBox23.Controls.Add(this.DiffIterationsBox);
            this.groupBox23.Controls.Add(this.DiffBurninBox);
            this.groupBox23.Controls.Add(this.DiffBatchesBox);
            this.groupBox23.Controls.Add(this.label83);
            this.groupBox23.Controls.Add(this.label68);
            this.groupBox23.Controls.Add(this.label67);
            this.groupBox23.Controls.Add(this.DiffJost2008Box);
            this.groupBox23.Controls.Add(this.DiffHedrick2005Box);
            this.groupBox23.Controls.Add(this.DiffHudson1992Box);
            this.groupBox23.Controls.Add(this.DiffTestPermBox);
            this.groupBox23.Controls.Add(this.DiffTestAlleleBox);
            this.groupBox23.Controls.Add(this.DiffNei1973Box);
            this.groupBox23.Controls.Add(this.DiffTestPhenoBox);
            this.groupBox23.Controls.Add(this.DiffHuang2018SMMBox);
            this.groupBox23.Controls.Add(this.DiffSlatkin1995Box);
            this.groupBox23.Controls.Add(this.DiffHuang2018IAMBox);
            this.groupBox23.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.groupBox23.Location = new System.Drawing.Point(289, 372);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox23.Size = new System.Drawing.Size(277, 536);
            this.groupBox23.TabIndex = 6;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Genetic differentiation";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label87.Location = new System.Drawing.Point(11, 322);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(127, 20);
            this.label87.TabIndex = 517;
            this.label87.Text = "Test parameters";
            // 
            // DiffRegBox
            // 
            this.DiffRegBox.AutoSize = true;
            this.DiffRegBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffRegBox.Location = new System.Drawing.Point(149, 48);
            this.DiffRegBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffRegBox.Name = "DiffRegBox";
            this.DiffRegBox.Size = new System.Drawing.Size(83, 24);
            this.DiffRegBox.TabIndex = 516;
            this.DiffRegBox.Text = "Region";
            this.DiffRegBox.UseVisualStyleBackColor = true;
            this.DiffRegBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTotBox
            // 
            this.DiffTotBox.AutoSize = true;
            this.DiffTotBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffTotBox.Location = new System.Drawing.Point(27, 75);
            this.DiffTotBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffTotBox.Name = "DiffTotBox";
            this.DiffTotBox.Size = new System.Drawing.Size(152, 24);
            this.DiffTotBox.TabIndex = 515;
            this.DiffTotBox.Text = "Total population";
            this.DiffTotBox.UseVisualStyleBackColor = true;
            this.DiffTotBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffPopBox
            // 
            this.DiffPopBox.AutoSize = true;
            this.DiffPopBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffPopBox.Location = new System.Drawing.Point(27, 48);
            this.DiffPopBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffPopBox.Name = "DiffPopBox";
            this.DiffPopBox.Size = new System.Drawing.Size(110, 24);
            this.DiffPopBox.TabIndex = 515;
            this.DiffPopBox.Text = "Population";
            this.DiffPopBox.UseVisualStyleBackColor = true;
            this.DiffPopBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label66.Location = new System.Drawing.Point(11, 104);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(85, 20);
            this.label66.TabIndex = 513;
            this.label66.Text = "Estimators";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label65.Location = new System.Drawing.Point(11, 22);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(55, 20);
            this.label65.TabIndex = 513;
            this.label65.Text = "Range";
            // 
            // DiffIterationsBox
            // 
            this.DiffIterationsBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffIterationsBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffIterationsBox.Location = new System.Drawing.Point(140, 498);
            this.DiffIterationsBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffIterationsBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.DiffIterationsBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffIterationsBox.Name = "DiffIterationsBox";
            this.DiffIterationsBox.Size = new System.Drawing.Size(112, 27);
            this.DiffIterationsBox.TabIndex = 512;
            this.DiffIterationsBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.DiffIterationsBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffBurninBox
            // 
            this.DiffBurninBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffBurninBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBurninBox.Location = new System.Drawing.Point(140, 428);
            this.DiffBurninBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffBurninBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.DiffBurninBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBurninBox.Name = "DiffBurninBox";
            this.DiffBurninBox.Size = new System.Drawing.Size(112, 27);
            this.DiffBurninBox.TabIndex = 512;
            this.DiffBurninBox.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.DiffBurninBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffBatchesBox
            // 
            this.DiffBatchesBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffBatchesBox.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBatchesBox.Location = new System.Drawing.Point(140, 462);
            this.DiffBatchesBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffBatchesBox.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.DiffBatchesBox.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.DiffBatchesBox.Name = "DiffBatchesBox";
            this.DiffBatchesBox.Size = new System.Drawing.Size(112, 27);
            this.DiffBatchesBox.TabIndex = 512;
            this.DiffBatchesBox.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.DiffBatchesBox.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label83.Location = new System.Drawing.Point(19, 501);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(88, 20);
            this.label83.TabIndex = 511;
            this.label83.Text = "#Iterations";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label68.Location = new System.Drawing.Point(19, 431);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(65, 20);
            this.label68.TabIndex = 511;
            this.label68.Text = "#Burnin";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.label67.Location = new System.Drawing.Point(19, 466);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(75, 20);
            this.label67.TabIndex = 511;
            this.label67.Text = "#Batches";
            // 
            // DiffJost2008Box
            // 
            this.DiffJost2008Box.AutoSize = true;
            this.DiffJost2008Box.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffJost2008Box.Location = new System.Drawing.Point(27, 291);
            this.DiffJost2008Box.Margin = new System.Windows.Forms.Padding(4);
            this.DiffJost2008Box.Name = "DiffJost2008Box";
            this.DiffJost2008Box.Size = new System.Drawing.Size(125, 24);
            this.DiffJost2008Box.TabIndex = 0;
            this.DiffJost2008Box.Text = "Jost 2008 (D)";
            this.DiffJost2008Box.UseVisualStyleBackColor = true;
            this.DiffJost2008Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHedrick2005Box
            // 
            this.DiffHedrick2005Box.AutoSize = true;
            this.DiffHedrick2005Box.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffHedrick2005Box.Location = new System.Drawing.Point(27, 264);
            this.DiffHedrick2005Box.Margin = new System.Windows.Forms.Padding(4);
            this.DiffHedrick2005Box.Name = "DiffHedrick2005Box";
            this.DiffHedrick2005Box.Size = new System.Drawing.Size(170, 24);
            this.DiffHedrick2005Box.TabIndex = 0;
            this.DiffHedrick2005Box.Text = "Hedrick 2005 (G\'st)";
            this.DiffHedrick2005Box.UseVisualStyleBackColor = true;
            this.DiffHedrick2005Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHudson1992Box
            // 
            this.DiffHudson1992Box.AutoSize = true;
            this.DiffHudson1992Box.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffHudson1992Box.Location = new System.Drawing.Point(27, 236);
            this.DiffHudson1992Box.Margin = new System.Windows.Forms.Padding(4);
            this.DiffHudson1992Box.Name = "DiffHudson1992Box";
            this.DiffHudson1992Box.Size = new System.Drawing.Size(167, 24);
            this.DiffHudson1992Box.TabIndex = 0;
            this.DiffHudson1992Box.Text = "Hudson et al. 1992";
            this.DiffHudson1992Box.UseVisualStyleBackColor = true;
            this.DiffHudson1992Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTestPermBox
            // 
            this.DiffTestPermBox.AutoSize = true;
            this.DiffTestPermBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffTestPermBox.Location = new System.Drawing.Point(27, 401);
            this.DiffTestPermBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffTestPermBox.Name = "DiffTestPermBox";
            this.DiffTestPermBox.Size = new System.Drawing.Size(162, 24);
            this.DiffTestPermBox.TabIndex = 0;
            this.DiffTestPermBox.Text = "Markov Chain test";
            this.DiffTestPermBox.UseVisualStyleBackColor = true;
            this.DiffTestPermBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTestAlleleBox
            // 
            this.DiffTestAlleleBox.AutoSize = true;
            this.DiffTestAlleleBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffTestAlleleBox.Location = new System.Drawing.Point(27, 374);
            this.DiffTestAlleleBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffTestAlleleBox.Name = "DiffTestAlleleBox";
            this.DiffTestAlleleBox.Size = new System.Drawing.Size(179, 24);
            this.DiffTestAlleleBox.TabIndex = 0;
            this.DiffTestAlleleBox.Text = "By allele distribution";
            this.DiffTestAlleleBox.UseVisualStyleBackColor = true;
            this.DiffTestAlleleBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffNei1973Box
            // 
            this.DiffNei1973Box.AutoSize = true;
            this.DiffNei1973Box.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffNei1973Box.Location = new System.Drawing.Point(27, 209);
            this.DiffNei1973Box.Margin = new System.Windows.Forms.Padding(4);
            this.DiffNei1973Box.Name = "DiffNei1973Box";
            this.DiffNei1973Box.Size = new System.Drawing.Size(134, 24);
            this.DiffNei1973Box.TabIndex = 0;
            this.DiffNei1973Box.Text = "Nei 1973 (Gst)";
            this.DiffNei1973Box.UseVisualStyleBackColor = true;
            this.DiffNei1973Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffTestPhenoBox
            // 
            this.DiffTestPhenoBox.AutoSize = true;
            this.DiffTestPhenoBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffTestPhenoBox.Location = new System.Drawing.Point(27, 346);
            this.DiffTestPhenoBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffTestPhenoBox.Name = "DiffTestPhenoBox";
            this.DiffTestPhenoBox.Size = new System.Drawing.Size(232, 24);
            this.DiffTestPhenoBox.TabIndex = 0;
            this.DiffTestPhenoBox.Text = "By pheno/geno distribution";
            this.DiffTestPhenoBox.UseVisualStyleBackColor = true;
            this.DiffTestPhenoBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHuang2018SMMBox
            // 
            this.DiffHuang2018SMMBox.AutoSize = true;
            this.DiffHuang2018SMMBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffHuang2018SMMBox.Location = new System.Drawing.Point(27, 155);
            this.DiffHuang2018SMMBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffHuang2018SMMBox.Name = "DiffHuang2018SMMBox";
            this.DiffHuang2018SMMBox.Size = new System.Drawing.Size(212, 24);
            this.DiffHuang2018SMMBox.TabIndex = 0;
            this.DiffHuang2018SMMBox.Text = "Weight genotype (SMM)";
            this.DiffHuang2018SMMBox.UseVisualStyleBackColor = true;
            this.DiffHuang2018SMMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffSlatkin1995Box
            // 
            this.DiffSlatkin1995Box.AutoSize = true;
            this.DiffSlatkin1995Box.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffSlatkin1995Box.Location = new System.Drawing.Point(27, 181);
            this.DiffSlatkin1995Box.Margin = new System.Windows.Forms.Padding(4);
            this.DiffSlatkin1995Box.Name = "DiffSlatkin1995Box";
            this.DiffSlatkin1995Box.Size = new System.Drawing.Size(156, 24);
            this.DiffSlatkin1995Box.TabIndex = 0;
            this.DiffSlatkin1995Box.Text = "Slatkin 1995 (Rst)";
            this.DiffSlatkin1995Box.UseVisualStyleBackColor = true;
            this.DiffSlatkin1995Box.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DiffHuang2018IAMBox
            // 
            this.DiffHuang2018IAMBox.AutoSize = true;
            this.DiffHuang2018IAMBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.DiffHuang2018IAMBox.Location = new System.Drawing.Point(27, 128);
            this.DiffHuang2018IAMBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffHuang2018IAMBox.Name = "DiffHuang2018IAMBox";
            this.DiffHuang2018IAMBox.Size = new System.Drawing.Size(203, 24);
            this.DiffHuang2018IAMBox.TabIndex = 0;
            this.DiffHuang2018IAMBox.Text = "Weight genotype (IAM)";
            this.DiffHuang2018IAMBox.UseVisualStyleBackColor = true;
            this.DiffHuang2018IAMBox.CheckedChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.groupBox6);
            this.tabPage9.Location = new System.Drawing.Point(4, 29);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(1876, 953);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Diversity";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.DiversityResBox);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(4, 4);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(1868, 945);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Genetic Diversity";
            // 
            // DiversityResBox
            // 
            this.DiversityResBox.AcceptsReturn = true;
            this.DiversityResBox.AcceptsTab = true;
            this.DiversityResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DiversityResBox.HideSelection = false;
            this.DiversityResBox.Location = new System.Drawing.Point(4, 24);
            this.DiversityResBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiversityResBox.MaxLength = 32767000;
            this.DiversityResBox.Multiline = true;
            this.DiversityResBox.Name = "DiversityResBox";
            this.DiversityResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DiversityResBox.Size = new System.Drawing.Size(1860, 917);
            this.DiversityResBox.TabIndex = 1;
            this.DiversityResBox.WordWrap = false;
            this.DiversityResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1876, 953);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Frequency";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.FrequencyResBox);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(4, 4);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(1868, 945);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Allele frequencies";
            // 
            // FrequencyResBox
            // 
            this.FrequencyResBox.AcceptsReturn = true;
            this.FrequencyResBox.AcceptsTab = true;
            this.FrequencyResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FrequencyResBox.HideSelection = false;
            this.FrequencyResBox.Location = new System.Drawing.Point(4, 24);
            this.FrequencyResBox.Margin = new System.Windows.Forms.Padding(4);
            this.FrequencyResBox.MaxLength = 32767000;
            this.FrequencyResBox.Multiline = true;
            this.FrequencyResBox.Name = "FrequencyResBox";
            this.FrequencyResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.FrequencyResBox.Size = new System.Drawing.Size(1860, 917);
            this.FrequencyResBox.TabIndex = 1;
            this.FrequencyResBox.WordWrap = false;
            this.FrequencyResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(1876, 953);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Distribution";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.PhenotypeResBox);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(4, 4);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1868, 945);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Double-reduction equilibrium test for phenotypic frequency";
            // 
            // PhenotypeResBox
            // 
            this.PhenotypeResBox.AcceptsReturn = true;
            this.PhenotypeResBox.AcceptsTab = true;
            this.PhenotypeResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PhenotypeResBox.HideSelection = false;
            this.PhenotypeResBox.Location = new System.Drawing.Point(4, 24);
            this.PhenotypeResBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhenotypeResBox.MaxLength = 32767000;
            this.PhenotypeResBox.Multiline = true;
            this.PhenotypeResBox.Name = "PhenotypeResBox";
            this.PhenotypeResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PhenotypeResBox.Size = new System.Drawing.Size(1860, 917);
            this.PhenotypeResBox.TabIndex = 1;
            this.PhenotypeResBox.WordWrap = false;
            this.PhenotypeResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.groupBox19);
            this.tabPage12.Location = new System.Drawing.Point(4, 29);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage12.Size = new System.Drawing.Size(1876, 953);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Linkage";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.LinkageResBox);
            this.groupBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox19.Location = new System.Drawing.Point(4, 4);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox19.Size = new System.Drawing.Size(1868, 945);
            this.groupBox19.TabIndex = 2;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Linkage disequilibrium test";
            // 
            // LinkageResBox
            // 
            this.LinkageResBox.AcceptsReturn = true;
            this.LinkageResBox.AcceptsTab = true;
            this.LinkageResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LinkageResBox.HideSelection = false;
            this.LinkageResBox.Location = new System.Drawing.Point(4, 24);
            this.LinkageResBox.Margin = new System.Windows.Forms.Padding(4);
            this.LinkageResBox.MaxLength = 32767000;
            this.LinkageResBox.Multiline = true;
            this.LinkageResBox.Name = "LinkageResBox";
            this.LinkageResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LinkageResBox.Size = new System.Drawing.Size(1860, 917);
            this.LinkageResBox.TabIndex = 1;
            this.LinkageResBox.WordWrap = false;
            this.LinkageResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1876, 953);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Differentiation";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.DiffResBox);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(4, 4);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(1868, 945);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Genetic Differantation";
            // 
            // DiffResBox
            // 
            this.DiffResBox.AcceptsReturn = true;
            this.DiffResBox.AcceptsTab = true;
            this.DiffResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DiffResBox.HideSelection = false;
            this.DiffResBox.Location = new System.Drawing.Point(4, 24);
            this.DiffResBox.Margin = new System.Windows.Forms.Padding(4);
            this.DiffResBox.MaxLength = 32767000;
            this.DiffResBox.Multiline = true;
            this.DiffResBox.Name = "DiffResBox";
            this.DiffResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DiffResBox.Size = new System.Drawing.Size(1860, 917);
            this.DiffResBox.TabIndex = 1;
            this.DiffResBox.WordWrap = false;
            this.DiffResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.groupBox22);
            this.tabPage13.Location = new System.Drawing.Point(4, 29);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage13.Size = new System.Drawing.Size(1876, 953);
            this.tabPage13.TabIndex = 12;
            this.tabPage13.Text = "Distance";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.DistResBox);
            this.groupBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox22.Location = new System.Drawing.Point(4, 4);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox22.Size = new System.Drawing.Size(1868, 945);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Genetic Distance";
            // 
            // DistResBox
            // 
            this.DistResBox.AcceptsReturn = true;
            this.DistResBox.AcceptsTab = true;
            this.DistResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DistResBox.HideSelection = false;
            this.DistResBox.Location = new System.Drawing.Point(4, 24);
            this.DistResBox.Margin = new System.Windows.Forms.Padding(4);
            this.DistResBox.MaxLength = 32767000;
            this.DistResBox.Multiline = true;
            this.DistResBox.Name = "DistResBox";
            this.DistResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DistResBox.Size = new System.Drawing.Size(1860, 917);
            this.DistResBox.TabIndex = 1;
            this.DistResBox.WordWrap = false;
            this.DistResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.splitContainer15);
            this.tabPage21.Location = new System.Drawing.Point(4, 29);
            this.tabPage21.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Size = new System.Drawing.Size(1876, 953);
            this.tabPage21.TabIndex = 16;
            this.tabPage21.Text = "PCoA";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // splitContainer15
            // 
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.Location = new System.Drawing.Point(0, 0);
            this.splitContainer15.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer15.Name = "splitContainer15";
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.groupBox52);
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.groupBox47);
            this.splitContainer15.Size = new System.Drawing.Size(1876, 953);
            this.splitContainer15.SplitterDistance = 1455;
            this.splitContainer15.SplitterWidth = 5;
            this.splitContainer15.TabIndex = 5;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.panel3);
            this.groupBox52.Controls.Add(this.toolStrip3);
            this.groupBox52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox52.Location = new System.Drawing.Point(0, 0);
            this.groupBox52.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox52.Size = new System.Drawing.Size(1455, 953);
            this.groupBox52.TabIndex = 7;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Scatter plot preview";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.PCoAPicBox);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 52);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1447, 897);
            this.panel3.TabIndex = 1;
            // 
            // PCoAPicBox
            // 
            this.PCoAPicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PCoAPicBox.Location = new System.Drawing.Point(0, 0);
            this.PCoAPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.PCoAPicBox.Name = "PCoAPicBox";
            this.PCoAPicBox.Size = new System.Drawing.Size(1447, 897);
            this.PCoAPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PCoAPicBox.TabIndex = 2;
            this.PCoAPicBox.TabStop = false;
            this.PCoAPicBox.SizeChanged += new System.EventHandler(this.PCoAPicBox_SizeChanged);
            // 
            // toolStrip3
            // 
            this.toolStrip3.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel7,
            this.PCoAComboBox,
            this.toolStripSeparator6,
            this.toolStripButton7,
            this.toolStripButton8});
            this.toolStrip3.Location = new System.Drawing.Point(4, 24);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(1447, 28);
            this.toolStrip3.TabIndex = 0;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(91, 25);
            this.toolStripLabel7.Text = "PCoA results";
            // 
            // PCoAComboBox
            // 
            this.PCoAComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PCoAComboBox.DropDownWidth = 500;
            this.PCoAComboBox.Name = "PCoAComboBox";
            this.PCoAComboBox.Size = new System.Drawing.Size(665, 28);
            this.PCoAComboBox.SelectedIndexChanged += new System.EventHandler(this.PCoAComboBox_SelectedIndexChanged);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(68, 25);
            this.toolStripButton7.Text = "&Previous";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(44, 25);
            this.toolStripButton8.Text = "&Next";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.PCoAResBox);
            this.groupBox47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox47.Location = new System.Drawing.Point(0, 0);
            this.groupBox47.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox47.Size = new System.Drawing.Size(416, 953);
            this.groupBox47.TabIndex = 4;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "Principal Coordinates Analysis";
            // 
            // PCoAResBox
            // 
            this.PCoAResBox.AcceptsReturn = true;
            this.PCoAResBox.AcceptsTab = true;
            this.PCoAResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PCoAResBox.HideSelection = false;
            this.PCoAResBox.Location = new System.Drawing.Point(4, 24);
            this.PCoAResBox.Margin = new System.Windows.Forms.Padding(4);
            this.PCoAResBox.MaxLength = 32767000;
            this.PCoAResBox.Multiline = true;
            this.PCoAResBox.Name = "PCoAResBox";
            this.PCoAResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.PCoAResBox.Size = new System.Drawing.Size(408, 925);
            this.PCoAResBox.TabIndex = 1;
            this.PCoAResBox.WordWrap = false;
            this.PCoAResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.splitContainer16);
            this.tabPage22.Location = new System.Drawing.Point(4, 29);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage22.Size = new System.Drawing.Size(1876, 953);
            this.tabPage22.TabIndex = 17;
            this.tabPage22.Text = "Hierarchical";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // splitContainer16
            // 
            this.splitContainer16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer16.Location = new System.Drawing.Point(4, 4);
            this.splitContainer16.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer16.Name = "splitContainer16";
            // 
            // splitContainer16.Panel1
            // 
            this.splitContainer16.Panel1.Controls.Add(this.groupBox51);
            // 
            // splitContainer16.Panel2
            // 
            this.splitContainer16.Panel2.Controls.Add(this.groupBox49);
            this.splitContainer16.Size = new System.Drawing.Size(1868, 945);
            this.splitContainer16.SplitterDistance = 1332;
            this.splitContainer16.SplitterWidth = 5;
            this.splitContainer16.TabIndex = 6;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.panel2);
            this.groupBox51.Controls.Add(this.toolStrip2);
            this.groupBox51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox51.Location = new System.Drawing.Point(0, 0);
            this.groupBox51.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox51.Size = new System.Drawing.Size(1332, 945);
            this.groupBox51.TabIndex = 6;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Tree preview";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.AutoSize = true;
            this.panel2.Controls.Add(this.ClusteringPicBox);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 52);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1324, 889);
            this.panel2.TabIndex = 1;
            // 
            // ClusteringPicBox
            // 
            this.ClusteringPicBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.ClusteringPicBox.Location = new System.Drawing.Point(0, 0);
            this.ClusteringPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringPicBox.Name = "ClusteringPicBox";
            this.ClusteringPicBox.Size = new System.Drawing.Size(1324, 616);
            this.ClusteringPicBox.TabIndex = 3;
            this.ClusteringPicBox.TabStop = false;
            this.ClusteringPicBox.SizeChanged += new System.EventHandler(this.ClusteringPicBox_SizeChanged);
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel6,
            this.ClusteringComboBox,
            this.toolStripSeparator5,
            this.toolStripButton4,
            this.toolStripButton6});
            this.toolStrip2.Location = new System.Drawing.Point(4, 24);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1324, 28);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(43, 25);
            this.toolStripLabel6.Text = "Trees";
            // 
            // ClusteringComboBox
            // 
            this.ClusteringComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ClusteringComboBox.Name = "ClusteringComboBox";
            this.ClusteringComboBox.Size = new System.Drawing.Size(665, 28);
            this.ClusteringComboBox.SelectedIndexChanged += new System.EventHandler(this.ClusteringComboBox_SelectedIndexChanged);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(68, 25);
            this.toolStripButton4.Text = "&Previous";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(44, 25);
            this.toolStripButton6.Text = "&Next";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.ClusteringResBox);
            this.groupBox49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox49.Location = new System.Drawing.Point(0, 0);
            this.groupBox49.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox49.Size = new System.Drawing.Size(531, 945);
            this.groupBox49.TabIndex = 5;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Hierarchical clustering";
            // 
            // ClusteringResBox
            // 
            this.ClusteringResBox.AcceptsReturn = true;
            this.ClusteringResBox.AcceptsTab = true;
            this.ClusteringResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ClusteringResBox.HideSelection = false;
            this.ClusteringResBox.Location = new System.Drawing.Point(4, 24);
            this.ClusteringResBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClusteringResBox.MaxLength = 32767000;
            this.ClusteringResBox.Multiline = true;
            this.ClusteringResBox.Name = "ClusteringResBox";
            this.ClusteringResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ClusteringResBox.Size = new System.Drawing.Size(523, 917);
            this.ClusteringResBox.TabIndex = 1;
            this.ClusteringResBox.WordWrap = false;
            this.ClusteringResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox2);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(1876, 953);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Inbreeding";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.InbreedingResBox);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(4, 4);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1868, 945);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Individual inbreeding coefficient";
            // 
            // InbreedingResBox
            // 
            this.InbreedingResBox.AcceptsReturn = true;
            this.InbreedingResBox.AcceptsTab = true;
            this.InbreedingResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InbreedingResBox.HideSelection = false;
            this.InbreedingResBox.Location = new System.Drawing.Point(4, 24);
            this.InbreedingResBox.Margin = new System.Windows.Forms.Padding(4);
            this.InbreedingResBox.MaxLength = 32767000;
            this.InbreedingResBox.Multiline = true;
            this.InbreedingResBox.Name = "InbreedingResBox";
            this.InbreedingResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InbreedingResBox.Size = new System.Drawing.Size(1860, 917);
            this.InbreedingResBox.TabIndex = 1;
            this.InbreedingResBox.WordWrap = false;
            this.InbreedingResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.groupBox11);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(1876, 953);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "H-Index";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.HIndexResBox);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(4, 4);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(1868, 945);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Individual Hetrozygosity";
            // 
            // HIndexResBox
            // 
            this.HIndexResBox.AcceptsReturn = true;
            this.HIndexResBox.AcceptsTab = true;
            this.HIndexResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HIndexResBox.HideSelection = false;
            this.HIndexResBox.Location = new System.Drawing.Point(4, 24);
            this.HIndexResBox.Margin = new System.Windows.Forms.Padding(4);
            this.HIndexResBox.MaxLength = 32767000;
            this.HIndexResBox.Multiline = true;
            this.HIndexResBox.Name = "HIndexResBox";
            this.HIndexResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.HIndexResBox.Size = new System.Drawing.Size(1860, 917);
            this.HIndexResBox.TabIndex = 1;
            this.HIndexResBox.WordWrap = false;
            this.HIndexResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox12);
            this.tabPage10.Location = new System.Drawing.Point(4, 29);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage10.Size = new System.Drawing.Size(1876, 953);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Assignment";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.AssignmentResBox);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(4, 4);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(1868, 945);
            this.groupBox12.TabIndex = 6;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Population assignment";
            // 
            // AssignmentResBox
            // 
            this.AssignmentResBox.AcceptsReturn = true;
            this.AssignmentResBox.AcceptsTab = true;
            this.AssignmentResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AssignmentResBox.HideSelection = false;
            this.AssignmentResBox.Location = new System.Drawing.Point(4, 24);
            this.AssignmentResBox.Margin = new System.Windows.Forms.Padding(4);
            this.AssignmentResBox.MaxLength = 32767000;
            this.AssignmentResBox.Multiline = true;
            this.AssignmentResBox.Name = "AssignmentResBox";
            this.AssignmentResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AssignmentResBox.Size = new System.Drawing.Size(1860, 917);
            this.AssignmentResBox.TabIndex = 1;
            this.AssignmentResBox.WordWrap = false;
            this.AssignmentResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox17);
            this.tabPage11.Location = new System.Drawing.Point(4, 29);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(1876, 953);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Relatedness";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.RelatednessResBox);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox17.Location = new System.Drawing.Point(0, 0);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox17.Size = new System.Drawing.Size(1876, 953);
            this.groupBox17.TabIndex = 7;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Pairwise relatedness";
            // 
            // RelatednessResBox
            // 
            this.RelatednessResBox.AcceptsReturn = true;
            this.RelatednessResBox.AcceptsTab = true;
            this.RelatednessResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RelatednessResBox.HideSelection = false;
            this.RelatednessResBox.Location = new System.Drawing.Point(4, 24);
            this.RelatednessResBox.Margin = new System.Windows.Forms.Padding(4);
            this.RelatednessResBox.MaxLength = 32767000;
            this.RelatednessResBox.Multiline = true;
            this.RelatednessResBox.Name = "RelatednessResBox";
            this.RelatednessResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.RelatednessResBox.Size = new System.Drawing.Size(1868, 925);
            this.RelatednessResBox.TabIndex = 1;
            this.RelatednessResBox.WordWrap = false;
            this.RelatednessResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.tabControl2);
            this.tabPage16.Location = new System.Drawing.Point(4, 29);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage16.Size = new System.Drawing.Size(1876, 953);
            this.tabPage16.TabIndex = 15;
            this.tabPage16.Text = "Parentage";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage20);
            this.tabControl2.Controls.Add(this.tabPage17);
            this.tabControl2.Controls.Add(this.tabPage18);
            this.tabControl2.Controls.Add(this.tabPage19);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(4, 4);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1868, 945);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.splitContainer12);
            this.tabPage20.Location = new System.Drawing.Point(4, 29);
            this.tabPage20.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage20.Size = new System.Drawing.Size(1860, 912);
            this.tabPage20.TabIndex = 3;
            this.tabPage20.Text = "Simulation";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // splitContainer12
            // 
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer12.Location = new System.Drawing.Point(4, 4);
            this.splitContainer12.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.groupBox45);
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.groupBox46);
            this.splitContainer12.Size = new System.Drawing.Size(1852, 904);
            this.splitContainer12.SplitterDistance = 336;
            this.splitContainer12.SplitterWidth = 5;
            this.splitContainer12.TabIndex = 1;
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.label53);
            this.groupBox45.Controls.Add(this.D2_95);
            this.groupBox45.Controls.Add(this.label54);
            this.groupBox45.Controls.Add(this.D2_99);
            this.groupBox45.Controls.Add(this.label55);
            this.groupBox45.Controls.Add(this.D2_999);
            this.groupBox45.Controls.Add(this.D2_80);
            this.groupBox45.Controls.Add(this.label56);
            this.groupBox45.Controls.Add(this.D1_95);
            this.groupBox45.Controls.Add(this.label57);
            this.groupBox45.Controls.Add(this.D1_99);
            this.groupBox45.Controls.Add(this.DPM_95);
            this.groupBox45.Controls.Add(this.label59);
            this.groupBox45.Controls.Add(this.D1_999);
            this.groupBox45.Controls.Add(this.label60);
            this.groupBox45.Controls.Add(this.DPF_95);
            this.groupBox45.Controls.Add(this.label61);
            this.groupBox45.Controls.Add(this.DPM_99);
            this.groupBox45.Controls.Add(this.label62);
            this.groupBox45.Controls.Add(this.DPF_99);
            this.groupBox45.Controls.Add(this.label63);
            this.groupBox45.Controls.Add(this.DPM_999);
            this.groupBox45.Controls.Add(this.label64);
            this.groupBox45.Controls.Add(this.DPF_999);
            this.groupBox45.Controls.Add(this.DPS_80);
            this.groupBox45.Controls.Add(this.DP_95);
            this.groupBox45.Controls.Add(this.DP_80);
            this.groupBox45.Controls.Add(this.DP_99);
            this.groupBox45.Controls.Add(this.DPS_999);
            this.groupBox45.Controls.Add(this.DPS_95);
            this.groupBox45.Controls.Add(this.DPF_80);
            this.groupBox45.Controls.Add(this.DP_999);
            this.groupBox45.Controls.Add(this.DPM_80);
            this.groupBox45.Controls.Add(this.DPS_99);
            this.groupBox45.Controls.Add(this.D1_80);
            this.groupBox45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox45.Location = new System.Drawing.Point(0, 0);
            this.groupBox45.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox45.Size = new System.Drawing.Size(336, 904);
            this.groupBox45.TabIndex = 1;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Critical values of Delta";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(23, 192);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(196, 20);
            this.label53.TabIndex = 26;
            this.label53.Text = "Parent-pair: mother alone";
            // 
            // D2_95
            // 
            this.D2_95.DecimalPlaces = 5;
            this.D2_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_95.Location = new System.Drawing.Point(231, 80);
            this.D2_95.Margin = new System.Windows.Forms.Padding(4);
            this.D2_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_95.Name = "D2_95";
            this.D2_95.Size = new System.Drawing.Size(89, 27);
            this.D2_95.TabIndex = 19;
            this.D2_95.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(23, 328);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(185, 20);
            this.label54.TabIndex = 30;
            this.label54.Text = "Parent-pair: two parents";
            // 
            // D2_99
            // 
            this.D2_99.DecimalPlaces = 5;
            this.D2_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_99.Location = new System.Drawing.Point(128, 80);
            this.D2_99.Margin = new System.Windows.Forms.Padding(4);
            this.D2_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_99.Name = "D2_99";
            this.D2_99.Size = new System.Drawing.Size(89, 27);
            this.D2_99.TabIndex = 17;
            this.D2_99.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(23, 260);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(185, 20);
            this.label55.TabIndex = 31;
            this.label55.Text = "Parent-pair: father alone";
            // 
            // D2_999
            // 
            this.D2_999.DecimalPlaces = 5;
            this.D2_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_999.Location = new System.Drawing.Point(25, 80);
            this.D2_999.Margin = new System.Windows.Forms.Padding(4);
            this.D2_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_999.Name = "D2_999";
            this.D2_999.Size = new System.Drawing.Size(89, 27);
            this.D2_999.TabIndex = 16;
            this.D2_999.Value = new decimal(new int[] {
            17823,
            0,
            0,
            262144});
            this.D2_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D2_80
            // 
            this.D2_80.DecimalPlaces = 5;
            this.D2_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D2_80.Location = new System.Drawing.Point(333, 80);
            this.D2_80.Margin = new System.Windows.Forms.Padding(4);
            this.D2_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D2_80.Name = "D2_80";
            this.D2_80.Size = new System.Drawing.Size(89, 27);
            this.D2_80.TabIndex = 20;
            this.D2_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(23, 395);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(208, 20);
            this.label56.TabIndex = 29;
            this.label56.Text = "Parent-pair: sexes unknown";
            // 
            // D1_95
            // 
            this.D1_95.DecimalPlaces = 5;
            this.D1_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_95.Location = new System.Drawing.Point(231, 148);
            this.D1_95.Margin = new System.Windows.Forms.Padding(4);
            this.D1_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_95.Name = "D1_95";
            this.D1_95.Size = new System.Drawing.Size(89, 27);
            this.D1_95.TabIndex = 25;
            this.D1_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(23, 125);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(206, 20);
            this.label57.TabIndex = 27;
            this.label57.Text = "Paternity: mother unknown";
            // 
            // D1_99
            // 
            this.D1_99.DecimalPlaces = 5;
            this.D1_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_99.Location = new System.Drawing.Point(128, 148);
            this.D1_99.Margin = new System.Windows.Forms.Padding(4);
            this.D1_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_99.Name = "D1_99";
            this.D1_99.Size = new System.Drawing.Size(89, 27);
            this.D1_99.TabIndex = 21;
            this.D1_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_95
            // 
            this.DPM_95.DecimalPlaces = 5;
            this.DPM_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_95.Location = new System.Drawing.Point(231, 215);
            this.DPM_95.Margin = new System.Windows.Forms.Padding(4);
            this.DPM_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_95.Name = "DPM_95";
            this.DPM_95.Size = new System.Drawing.Size(89, 27);
            this.DPM_95.TabIndex = 14;
            this.DPM_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(23, 58);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(188, 20);
            this.label59.TabIndex = 32;
            this.label59.Text = "Paternity: mother known";
            // 
            // D1_999
            // 
            this.D1_999.DecimalPlaces = 5;
            this.D1_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_999.Location = new System.Drawing.Point(25, 148);
            this.D1_999.Margin = new System.Windows.Forms.Padding(4);
            this.D1_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_999.Name = "D1_999";
            this.D1_999.Size = new System.Drawing.Size(89, 27);
            this.D1_999.TabIndex = 6;
            this.D1_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.D1_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(344, 30);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(66, 20);
            this.label60.TabIndex = 36;
            this.label60.Text = "Δ0.80 +";
            // 
            // DPF_95
            // 
            this.DPF_95.DecimalPlaces = 5;
            this.DPF_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_95.Location = new System.Drawing.Point(231, 282);
            this.DPF_95.Margin = new System.Windows.Forms.Padding(4);
            this.DPF_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_95.Name = "DPF_95";
            this.DPF_95.Size = new System.Drawing.Size(89, 27);
            this.DPF_95.TabIndex = 2;
            this.DPF_95.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(136, 30);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(69, 20);
            this.label61.TabIndex = 37;
            this.label61.Text = "Δ0.99 **";
            // 
            // DPM_99
            // 
            this.DPM_99.DecimalPlaces = 5;
            this.DPM_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_99.Location = new System.Drawing.Point(128, 215);
            this.DPM_99.Margin = new System.Windows.Forms.Padding(4);
            this.DPM_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_99.Name = "DPM_99";
            this.DPM_99.Size = new System.Drawing.Size(89, 27);
            this.DPM_99.TabIndex = 4;
            this.DPM_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(243, 30);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(62, 20);
            this.label62.TabIndex = 35;
            this.label62.Text = "Δ0.95 *";
            // 
            // DPF_99
            // 
            this.DPF_99.DecimalPlaces = 5;
            this.DPF_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_99.Location = new System.Drawing.Point(128, 282);
            this.DPF_99.Margin = new System.Windows.Forms.Padding(4);
            this.DPF_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_99.Name = "DPF_99";
            this.DPF_99.Size = new System.Drawing.Size(89, 27);
            this.DPF_99.TabIndex = 12;
            this.DPF_99.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(23, 30);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(85, 20);
            this.label63.TabIndex = 33;
            this.label63.Text = "Δ0.999 ***";
            // 
            // DPM_999
            // 
            this.DPM_999.DecimalPlaces = 5;
            this.DPM_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_999.Location = new System.Drawing.Point(25, 215);
            this.DPM_999.Margin = new System.Windows.Forms.Padding(4);
            this.DPM_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_999.Name = "DPM_999";
            this.DPM_999.Size = new System.Drawing.Size(89, 27);
            this.DPM_999.TabIndex = 8;
            this.DPM_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPM_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(131, 98);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(0, 20);
            this.label64.TabIndex = 34;
            // 
            // DPF_999
            // 
            this.DPF_999.DecimalPlaces = 5;
            this.DPF_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_999.Location = new System.Drawing.Point(25, 282);
            this.DPF_999.Margin = new System.Windows.Forms.Padding(4);
            this.DPF_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_999.Name = "DPF_999";
            this.DPF_999.Size = new System.Drawing.Size(89, 27);
            this.DPF_999.TabIndex = 10;
            this.DPF_999.Value = new decimal(new int[] {
            27433,
            0,
            0,
            262144});
            this.DPF_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPS_80
            // 
            this.DPS_80.DecimalPlaces = 5;
            this.DPS_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPS_80.Location = new System.Drawing.Point(333, 418);
            this.DPS_80.Margin = new System.Windows.Forms.Padding(4);
            this.DPS_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPS_80.Name = "DPS_80";
            this.DPS_80.Size = new System.Drawing.Size(89, 27);
            this.DPS_80.TabIndex = 9;
            this.DPS_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_95
            // 
            this.DP_95.DecimalPlaces = 5;
            this.DP_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_95.Location = new System.Drawing.Point(231, 350);
            this.DP_95.Margin = new System.Windows.Forms.Padding(4);
            this.DP_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_95.Name = "DP_95";
            this.DP_95.Size = new System.Drawing.Size(89, 27);
            this.DP_95.TabIndex = 13;
            this.DP_95.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_80
            // 
            this.DP_80.DecimalPlaces = 5;
            this.DP_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_80.Location = new System.Drawing.Point(333, 350);
            this.DP_80.Margin = new System.Windows.Forms.Padding(4);
            this.DP_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_80.Name = "DP_80";
            this.DP_80.Size = new System.Drawing.Size(89, 27);
            this.DP_80.TabIndex = 11;
            this.DP_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_99
            // 
            this.DP_99.DecimalPlaces = 5;
            this.DP_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_99.Location = new System.Drawing.Point(128, 350);
            this.DP_99.Margin = new System.Windows.Forms.Padding(4);
            this.DP_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_99.Name = "DP_99";
            this.DP_99.Size = new System.Drawing.Size(89, 27);
            this.DP_99.TabIndex = 3;
            this.DP_99.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPS_999
            // 
            this.DPS_999.DecimalPlaces = 5;
            this.DPS_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPS_999.Location = new System.Drawing.Point(25, 418);
            this.DPS_999.Margin = new System.Windows.Forms.Padding(4);
            this.DPS_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPS_999.Name = "DPS_999";
            this.DPS_999.Size = new System.Drawing.Size(89, 27);
            this.DPS_999.TabIndex = 7;
            this.DPS_999.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPS_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPS_95
            // 
            this.DPS_95.DecimalPlaces = 5;
            this.DPS_95.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPS_95.Location = new System.Drawing.Point(231, 418);
            this.DPS_95.Margin = new System.Windows.Forms.Padding(4);
            this.DPS_95.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPS_95.Name = "DPS_95";
            this.DPS_95.Size = new System.Drawing.Size(89, 27);
            this.DPS_95.TabIndex = 5;
            this.DPS_95.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPS_95.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPF_80
            // 
            this.DPF_80.DecimalPlaces = 5;
            this.DPF_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPF_80.Location = new System.Drawing.Point(333, 282);
            this.DPF_80.Margin = new System.Windows.Forms.Padding(4);
            this.DPF_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPF_80.Name = "DPF_80";
            this.DPF_80.Size = new System.Drawing.Size(89, 27);
            this.DPF_80.TabIndex = 22;
            this.DPF_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DP_999
            // 
            this.DP_999.DecimalPlaces = 5;
            this.DP_999.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DP_999.Location = new System.Drawing.Point(25, 350);
            this.DP_999.Margin = new System.Windows.Forms.Padding(4);
            this.DP_999.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DP_999.Name = "DP_999";
            this.DP_999.Size = new System.Drawing.Size(89, 27);
            this.DP_999.TabIndex = 23;
            this.DP_999.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DP_999.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPM_80
            // 
            this.DPM_80.DecimalPlaces = 5;
            this.DPM_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPM_80.Location = new System.Drawing.Point(333, 215);
            this.DPM_80.Margin = new System.Windows.Forms.Padding(4);
            this.DPM_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPM_80.Name = "DPM_80";
            this.DPM_80.Size = new System.Drawing.Size(89, 27);
            this.DPM_80.TabIndex = 24;
            this.DPM_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // DPS_99
            // 
            this.DPS_99.DecimalPlaces = 5;
            this.DPS_99.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.DPS_99.Location = new System.Drawing.Point(128, 418);
            this.DPS_99.Margin = new System.Windows.Forms.Padding(4);
            this.DPS_99.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.DPS_99.Name = "DPS_99";
            this.DPS_99.Size = new System.Drawing.Size(89, 27);
            this.DPS_99.TabIndex = 15;
            this.DPS_99.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.DPS_99.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // D1_80
            // 
            this.D1_80.DecimalPlaces = 5;
            this.D1_80.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.D1_80.Location = new System.Drawing.Point(333, 148);
            this.D1_80.Margin = new System.Windows.Forms.Padding(4);
            this.D1_80.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.D1_80.Name = "D1_80";
            this.D1_80.Size = new System.Drawing.Size(89, 27);
            this.D1_80.TabIndex = 18;
            this.D1_80.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.ParentageSimResBox);
            this.groupBox46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox46.Location = new System.Drawing.Point(0, 0);
            this.groupBox46.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox46.Size = new System.Drawing.Size(1511, 904);
            this.groupBox46.TabIndex = 1;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Summary";
            // 
            // ParentageSimResBox
            // 
            this.ParentageSimResBox.AcceptsReturn = true;
            this.ParentageSimResBox.AcceptsTab = true;
            this.ParentageSimResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageSimResBox.HideSelection = false;
            this.ParentageSimResBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageSimResBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageSimResBox.MaxLength = 32767000;
            this.ParentageSimResBox.Multiline = true;
            this.ParentageSimResBox.Name = "ParentageSimResBox";
            this.ParentageSimResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageSimResBox.Size = new System.Drawing.Size(1503, 876);
            this.ParentageSimResBox.TabIndex = 2;
            this.ParentageSimResBox.WordWrap = false;
            this.ParentageSimResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.splitContainer6);
            this.tabPage17.Location = new System.Drawing.Point(4, 29);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage17.Size = new System.Drawing.Size(1860, 912);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "Paternity";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(4, 4);
            this.splitContainer6.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.groupBox37);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.groupBox36);
            this.splitContainer6.Size = new System.Drawing.Size(1852, 904);
            this.splitContainer6.SplitterDistance = 611;
            this.splitContainer6.SplitterWidth = 5;
            this.splitContainer6.TabIndex = 0;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.ParentagePaternityOffspringBox);
            this.groupBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox37.Location = new System.Drawing.Point(0, 0);
            this.groupBox37.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox37.Size = new System.Drawing.Size(611, 904);
            this.groupBox37.TabIndex = 1;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Offspring, known mother and candidate fathers";
            // 
            // ParentagePaternityOffspringBox
            // 
            this.ParentagePaternityOffspringBox.AcceptsReturn = true;
            this.ParentagePaternityOffspringBox.AcceptsTab = true;
            this.ParentagePaternityOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentagePaternityOffspringBox.HideSelection = false;
            this.ParentagePaternityOffspringBox.Location = new System.Drawing.Point(4, 24);
            this.ParentagePaternityOffspringBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentagePaternityOffspringBox.MaxLength = 32767000;
            this.ParentagePaternityOffspringBox.Multiline = true;
            this.ParentagePaternityOffspringBox.Name = "ParentagePaternityOffspringBox";
            this.ParentagePaternityOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentagePaternityOffspringBox.Size = new System.Drawing.Size(603, 876);
            this.ParentagePaternityOffspringBox.TabIndex = 2;
            this.ParentagePaternityOffspringBox.WordWrap = false;
            this.ParentagePaternityOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.ParentagePaternityResBox);
            this.groupBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox36.Location = new System.Drawing.Point(0, 0);
            this.groupBox36.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox36.Size = new System.Drawing.Size(1236, 904);
            this.groupBox36.TabIndex = 1;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Results";
            // 
            // ParentagePaternityResBox
            // 
            this.ParentagePaternityResBox.AcceptsReturn = true;
            this.ParentagePaternityResBox.AcceptsTab = true;
            this.ParentagePaternityResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentagePaternityResBox.HideSelection = false;
            this.ParentagePaternityResBox.Location = new System.Drawing.Point(4, 24);
            this.ParentagePaternityResBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentagePaternityResBox.MaxLength = 32767000;
            this.ParentagePaternityResBox.Multiline = true;
            this.ParentagePaternityResBox.Name = "ParentagePaternityResBox";
            this.ParentagePaternityResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentagePaternityResBox.Size = new System.Drawing.Size(1228, 876);
            this.ParentagePaternityResBox.TabIndex = 2;
            this.ParentagePaternityResBox.WordWrap = false;
            this.ParentagePaternityResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.splitContainer7);
            this.tabPage18.Location = new System.Drawing.Point(4, 29);
            this.tabPage18.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage18.Size = new System.Drawing.Size(1860, 912);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Parent pair";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(4, 4);
            this.splitContainer7.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.splitContainer9);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.groupBox39);
            this.splitContainer7.Size = new System.Drawing.Size(1852, 904);
            this.splitContainer7.SplitterDistance = 610;
            this.splitContainer7.SplitterWidth = 5;
            this.splitContainer7.TabIndex = 1;
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.groupBox40);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.splitContainer10);
            this.splitContainer9.Size = new System.Drawing.Size(610, 904);
            this.splitContainer9.SplitterDistance = 273;
            this.splitContainer9.SplitterWidth = 5;
            this.splitContainer9.TabIndex = 0;
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.ParentageParentPairOffspringBox);
            this.groupBox40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox40.Location = new System.Drawing.Point(0, 0);
            this.groupBox40.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox40.Size = new System.Drawing.Size(610, 273);
            this.groupBox40.TabIndex = 2;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Offspring";
            // 
            // ParentageParentPairOffspringBox
            // 
            this.ParentageParentPairOffspringBox.AcceptsReturn = true;
            this.ParentageParentPairOffspringBox.AcceptsTab = true;
            this.ParentageParentPairOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairOffspringBox.HideSelection = false;
            this.ParentageParentPairOffspringBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageParentPairOffspringBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairOffspringBox.MaxLength = 32767000;
            this.ParentageParentPairOffspringBox.Multiline = true;
            this.ParentageParentPairOffspringBox.Name = "ParentageParentPairOffspringBox";
            this.ParentageParentPairOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairOffspringBox.Size = new System.Drawing.Size(602, 245);
            this.ParentageParentPairOffspringBox.TabIndex = 2;
            this.ParentageParentPairOffspringBox.WordWrap = false;
            this.ParentageParentPairOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // splitContainer10
            // 
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.Location = new System.Drawing.Point(0, 0);
            this.splitContainer10.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer10.Name = "splitContainer10";
            this.splitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.groupBox41);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.groupBox42);
            this.splitContainer10.Size = new System.Drawing.Size(610, 626);
            this.splitContainer10.SplitterDistance = 298;
            this.splitContainer10.SplitterWidth = 5;
            this.splitContainer10.TabIndex = 1;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.ParentageParentPairMotherBox);
            this.groupBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox41.Location = new System.Drawing.Point(0, 0);
            this.groupBox41.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox41.Size = new System.Drawing.Size(610, 298);
            this.groupBox41.TabIndex = 2;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "Candidate mothers";
            // 
            // ParentageParentPairMotherBox
            // 
            this.ParentageParentPairMotherBox.AcceptsReturn = true;
            this.ParentageParentPairMotherBox.AcceptsTab = true;
            this.ParentageParentPairMotherBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairMotherBox.HideSelection = false;
            this.ParentageParentPairMotherBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageParentPairMotherBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairMotherBox.MaxLength = 32767000;
            this.ParentageParentPairMotherBox.Multiline = true;
            this.ParentageParentPairMotherBox.Name = "ParentageParentPairMotherBox";
            this.ParentageParentPairMotherBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairMotherBox.Size = new System.Drawing.Size(602, 270);
            this.ParentageParentPairMotherBox.TabIndex = 2;
            this.ParentageParentPairMotherBox.WordWrap = false;
            this.ParentageParentPairMotherBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.ParentageParentPairFatherBox);
            this.groupBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox42.Location = new System.Drawing.Point(0, 0);
            this.groupBox42.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox42.Size = new System.Drawing.Size(610, 323);
            this.groupBox42.TabIndex = 2;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Candidate fathers";
            // 
            // ParentageParentPairFatherBox
            // 
            this.ParentageParentPairFatherBox.AcceptsReturn = true;
            this.ParentageParentPairFatherBox.AcceptsTab = true;
            this.ParentageParentPairFatherBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairFatherBox.HideSelection = false;
            this.ParentageParentPairFatherBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageParentPairFatherBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairFatherBox.MaxLength = 32767000;
            this.ParentageParentPairFatherBox.Multiline = true;
            this.ParentageParentPairFatherBox.Name = "ParentageParentPairFatherBox";
            this.ParentageParentPairFatherBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairFatherBox.Size = new System.Drawing.Size(602, 295);
            this.ParentageParentPairFatherBox.TabIndex = 2;
            this.ParentageParentPairFatherBox.WordWrap = false;
            this.ParentageParentPairFatherBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.ParentageParentPairResBox);
            this.groupBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox39.Location = new System.Drawing.Point(0, 0);
            this.groupBox39.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox39.Size = new System.Drawing.Size(1237, 904);
            this.groupBox39.TabIndex = 1;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "Results";
            // 
            // ParentageParentPairResBox
            // 
            this.ParentageParentPairResBox.AcceptsReturn = true;
            this.ParentageParentPairResBox.AcceptsTab = true;
            this.ParentageParentPairResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageParentPairResBox.HideSelection = false;
            this.ParentageParentPairResBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageParentPairResBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageParentPairResBox.MaxLength = 32767000;
            this.ParentageParentPairResBox.Multiline = true;
            this.ParentageParentPairResBox.Name = "ParentageParentPairResBox";
            this.ParentageParentPairResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageParentPairResBox.Size = new System.Drawing.Size(1229, 876);
            this.ParentageParentPairResBox.TabIndex = 2;
            this.ParentageParentPairResBox.WordWrap = false;
            this.ParentageParentPairResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.splitContainer11);
            this.tabPage19.Location = new System.Drawing.Point(4, 29);
            this.tabPage19.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage19.Size = new System.Drawing.Size(1860, 912);
            this.tabPage19.TabIndex = 2;
            this.tabPage19.Text = "Parent pair (sexes unknown)";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(4, 4);
            this.splitContainer11.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer11.Name = "splitContainer11";
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.splitContainer13);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.groupBox38);
            this.splitContainer11.Size = new System.Drawing.Size(1852, 904);
            this.splitContainer11.SplitterDistance = 610;
            this.splitContainer11.SplitterWidth = 5;
            this.splitContainer11.TabIndex = 2;
            // 
            // splitContainer13
            // 
            this.splitContainer13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer13.Location = new System.Drawing.Point(0, 0);
            this.splitContainer13.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer13.Name = "splitContainer13";
            this.splitContainer13.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.groupBox43);
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.groupBox44);
            this.splitContainer13.Size = new System.Drawing.Size(610, 904);
            this.splitContainer13.SplitterDistance = 433;
            this.splitContainer13.SplitterWidth = 5;
            this.splitContainer13.TabIndex = 2;
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.ParentageUnknownOffspringBox);
            this.groupBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox43.Location = new System.Drawing.Point(0, 0);
            this.groupBox43.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox43.Size = new System.Drawing.Size(610, 433);
            this.groupBox43.TabIndex = 3;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Offspring";
            // 
            // ParentageUnknownOffspringBox
            // 
            this.ParentageUnknownOffspringBox.AcceptsReturn = true;
            this.ParentageUnknownOffspringBox.AcceptsTab = true;
            this.ParentageUnknownOffspringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownOffspringBox.HideSelection = false;
            this.ParentageUnknownOffspringBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageUnknownOffspringBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownOffspringBox.MaxLength = 32767000;
            this.ParentageUnknownOffspringBox.Multiline = true;
            this.ParentageUnknownOffspringBox.Name = "ParentageUnknownOffspringBox";
            this.ParentageUnknownOffspringBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownOffspringBox.Size = new System.Drawing.Size(602, 405);
            this.ParentageUnknownOffspringBox.TabIndex = 2;
            this.ParentageUnknownOffspringBox.WordWrap = false;
            this.ParentageUnknownOffspringBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.ParentageUnknownParentBox);
            this.groupBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox44.Location = new System.Drawing.Point(0, 0);
            this.groupBox44.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox44.Size = new System.Drawing.Size(610, 466);
            this.groupBox44.TabIndex = 3;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "Candidate parents";
            // 
            // ParentageUnknownParentBox
            // 
            this.ParentageUnknownParentBox.AcceptsReturn = true;
            this.ParentageUnknownParentBox.AcceptsTab = true;
            this.ParentageUnknownParentBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownParentBox.HideSelection = false;
            this.ParentageUnknownParentBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageUnknownParentBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownParentBox.MaxLength = 32767000;
            this.ParentageUnknownParentBox.Multiline = true;
            this.ParentageUnknownParentBox.Name = "ParentageUnknownParentBox";
            this.ParentageUnknownParentBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownParentBox.Size = new System.Drawing.Size(602, 438);
            this.ParentageUnknownParentBox.TabIndex = 2;
            this.ParentageUnknownParentBox.WordWrap = false;
            this.ParentageUnknownParentBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.ParentageUnknownResBox);
            this.groupBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox38.Location = new System.Drawing.Point(0, 0);
            this.groupBox38.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox38.Size = new System.Drawing.Size(1237, 904);
            this.groupBox38.TabIndex = 1;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "Results";
            // 
            // ParentageUnknownResBox
            // 
            this.ParentageUnknownResBox.AcceptsReturn = true;
            this.ParentageUnknownResBox.AcceptsTab = true;
            this.ParentageUnknownResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentageUnknownResBox.HideSelection = false;
            this.ParentageUnknownResBox.Location = new System.Drawing.Point(4, 24);
            this.ParentageUnknownResBox.Margin = new System.Windows.Forms.Padding(4);
            this.ParentageUnknownResBox.MaxLength = 32767000;
            this.ParentageUnknownResBox.Multiline = true;
            this.ParentageUnknownResBox.Name = "ParentageUnknownResBox";
            this.ParentageUnknownResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ParentageUnknownResBox.Size = new System.Drawing.Size(1229, 876);
            this.ParentageUnknownResBox.TabIndex = 2;
            this.ParentageUnknownResBox.WordWrap = false;
            this.ParentageUnknownResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox10);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage7.Size = new System.Drawing.Size(1876, 953);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "AMOVA";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.AMOVAResBox);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(4, 4);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(1868, 945);
            this.groupBox10.TabIndex = 4;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Analysis of Molecular Variance";
            // 
            // AMOVAResBox
            // 
            this.AMOVAResBox.AcceptsReturn = true;
            this.AMOVAResBox.AcceptsTab = true;
            this.AMOVAResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AMOVAResBox.HideSelection = false;
            this.AMOVAResBox.Location = new System.Drawing.Point(4, 24);
            this.AMOVAResBox.Margin = new System.Windows.Forms.Padding(4);
            this.AMOVAResBox.MaxLength = 32767000;
            this.AMOVAResBox.Multiline = true;
            this.AMOVAResBox.Name = "AMOVAResBox";
            this.AMOVAResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AMOVAResBox.Size = new System.Drawing.Size(1860, 917);
            this.AMOVAResBox.TabIndex = 1;
            this.AMOVAResBox.WordWrap = false;
            this.AMOVAResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.splitContainer1);
            this.tabPage14.Location = new System.Drawing.Point(4, 29);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage14.Size = new System.Drawing.Size(1876, 953);
            this.tabPage14.TabIndex = 13;
            this.tabPage14.Text = "Bayesian";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(4, 4);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1868, 945);
            this.splitContainer1.SplitterDistance = 368;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox29);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox25);
            this.splitContainer3.Size = new System.Drawing.Size(368, 945);
            this.splitContainer3.SplitterDistance = 285;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 1;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.BayesianResultBox);
            this.groupBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox29.Location = new System.Drawing.Point(0, 0);
            this.groupBox29.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox29.Size = new System.Drawing.Size(368, 285);
            this.groupBox29.TabIndex = 1;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Clusting result explorer (right click to delete)";
            // 
            // BayesianResultBox
            // 
            this.BayesianResultBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.BayesianResultBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesianResultBox.FullRowSelect = true;
            this.BayesianResultBox.HideSelection = false;
            this.BayesianResultBox.Location = new System.Drawing.Point(4, 24);
            this.BayesianResultBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianResultBox.Name = "BayesianResultBox";
            this.BayesianResultBox.Size = new System.Drawing.Size(360, 257);
            this.BayesianResultBox.TabIndex = 0;
            this.BayesianResultBox.UseCompatibleStateImageBehavior = false;
            this.BayesianResultBox.View = System.Windows.Forms.View.Details;
            this.BayesianResultBox.SelectedIndexChanged += new System.EventHandler(this.listView2_SelectedIndexChanged);
            this.BayesianResultBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView2_MouseClick);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "id";
            this.columnHeader4.Width = 40;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Time";
            this.columnHeader8.Width = 110;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Krange";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Model";
            this.columnHeader10.Width = 130;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.BayesianResultExplorerBox);
            this.groupBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox25.Location = new System.Drawing.Point(0, 0);
            this.groupBox25.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox25.Size = new System.Drawing.Size(368, 655);
            this.groupBox25.TabIndex = 0;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Summary";
            // 
            // BayesianResultExplorerBox
            // 
            this.BayesianResultExplorerBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader3});
            this.BayesianResultExplorerBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesianResultExplorerBox.FullRowSelect = true;
            this.BayesianResultExplorerBox.HideSelection = false;
            this.BayesianResultExplorerBox.Location = new System.Drawing.Point(4, 24);
            this.BayesianResultExplorerBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianResultExplorerBox.MultiSelect = false;
            this.BayesianResultExplorerBox.Name = "BayesianResultExplorerBox";
            this.BayesianResultExplorerBox.Size = new System.Drawing.Size(360, 627);
            this.BayesianResultExplorerBox.TabIndex = 0;
            this.BayesianResultExplorerBox.UseCompatibleStateImageBehavior = false;
            this.BayesianResultExplorerBox.View = System.Windows.Forms.View.Details;
            this.BayesianResultExplorerBox.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "id";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "K";
            this.columnHeader2.Width = 40;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Mean lnL";
            this.columnHeader6.Width = 90;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Var lnL";
            this.columnHeader7.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "ln PD";
            this.columnHeader3.Width = 90;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox26);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox27);
            this.splitContainer2.Size = new System.Drawing.Size(1495, 945);
            this.splitContainer2.SplitterDistance = 202;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.BayesianPicBox);
            this.groupBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox26.Location = new System.Drawing.Point(0, 0);
            this.groupBox26.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox26.Size = new System.Drawing.Size(1495, 202);
            this.groupBox26.TabIndex = 1;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Barplot (right click to save picture)";
            // 
            // BayesianPicBox
            // 
            this.BayesianPicBox.BackColor = System.Drawing.Color.LightGray;
            this.BayesianPicBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesianPicBox.Location = new System.Drawing.Point(4, 24);
            this.BayesianPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianPicBox.Name = "BayesianPicBox";
            this.BayesianPicBox.Size = new System.Drawing.Size(1487, 174);
            this.BayesianPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BayesianPicBox.TabIndex = 0;
            this.BayesianPicBox.TabStop = false;
            this.BayesianPicBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.BayesianSummaryBox);
            this.groupBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox27.Location = new System.Drawing.Point(0, 0);
            this.groupBox27.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox27.Size = new System.Drawing.Size(1495, 738);
            this.groupBox27.TabIndex = 1;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Details";
            // 
            // BayesianSummaryBox
            // 
            this.BayesianSummaryBox.AcceptsReturn = true;
            this.BayesianSummaryBox.AcceptsTab = true;
            this.BayesianSummaryBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BayesianSummaryBox.HideSelection = false;
            this.BayesianSummaryBox.Location = new System.Drawing.Point(4, 24);
            this.BayesianSummaryBox.Margin = new System.Windows.Forms.Padding(4);
            this.BayesianSummaryBox.MaxLength = 32767000;
            this.BayesianSummaryBox.Multiline = true;
            this.BayesianSummaryBox.Name = "BayesianSummaryBox";
            this.BayesianSummaryBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.BayesianSummaryBox.Size = new System.Drawing.Size(1487, 710);
            this.BayesianSummaryBox.TabIndex = 0;
            this.BayesianSummaryBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.splitContainer4);
            this.tabPage15.Location = new System.Drawing.Point(4, 29);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage15.Size = new System.Drawing.Size(1876, 953);
            this.tabPage15.TabIndex = 14;
            this.tabPage15.Text = "Mantel";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer4.Location = new System.Drawing.Point(4, 4);
            this.splitContainer4.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer5);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.groupBox32);
            this.splitContainer4.Size = new System.Drawing.Size(1868, 945);
            this.splitContainer4.SplitterDistance = 391;
            this.splitContainer4.SplitterWidth = 5;
            this.splitContainer4.TabIndex = 0;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.groupBox31);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.groupBox30);
            this.splitContainer5.Size = new System.Drawing.Size(391, 945);
            this.splitContainer5.SplitterDistance = 101;
            this.splitContainer5.SplitterWidth = 5;
            this.splitContainer5.TabIndex = 1;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.linkLabel2);
            this.groupBox31.Controls.Add(this.button3);
            this.groupBox31.Controls.Add(this.button2);
            this.groupBox31.Controls.Add(this.MantelNPermBOx);
            this.groupBox31.Controls.Add(this.label44);
            this.groupBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox31.Location = new System.Drawing.Point(0, 0);
            this.groupBox31.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox31.Size = new System.Drawing.Size(391, 101);
            this.groupBox31.TabIndex = 1;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Parameters";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(21, 66);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(353, 60);
            this.linkLabel2.TabIndex = 512;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Faster and powerful Mantel tests in ISOLATION.\r\nControl up to 10 partial matrices" +
    "; 100X speed;\r\npartition; filter; FDR correction...";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(285, 21);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 29);
            this.button3.TabIndex = 511;
            this.button3.Text = "&Permute";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(403, 21);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 29);
            this.button2.TabIndex = 511;
            this.button2.Text = "&Example";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MantelNPermBOx
            // 
            this.MantelNPermBOx.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.MantelNPermBOx.Location = new System.Drawing.Point(143, 25);
            this.MantelNPermBOx.Margin = new System.Windows.Forms.Padding(4);
            this.MantelNPermBOx.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.MantelNPermBOx.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.MantelNPermBOx.Name = "MantelNPermBOx";
            this.MantelNPermBOx.Size = new System.Drawing.Size(135, 27);
            this.MantelNPermBOx.TabIndex = 510;
            this.MantelNPermBOx.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.MantelNPermBOx.ValueChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(24, 28);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(116, 20);
            this.label44.TabIndex = 509;
            this.label44.Text = "#Permutations";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.MantelResBox);
            this.groupBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox30.Location = new System.Drawing.Point(0, 0);
            this.groupBox30.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox30.Size = new System.Drawing.Size(391, 839);
            this.groupBox30.TabIndex = 0;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Results";
            // 
            // MantelResBox
            // 
            this.MantelResBox.AcceptsReturn = true;
            this.MantelResBox.AcceptsTab = true;
            this.MantelResBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MantelResBox.HideSelection = false;
            this.MantelResBox.Location = new System.Drawing.Point(4, 24);
            this.MantelResBox.Margin = new System.Windows.Forms.Padding(4);
            this.MantelResBox.MaxLength = 32767000;
            this.MantelResBox.Multiline = true;
            this.MantelResBox.Name = "MantelResBox";
            this.MantelResBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.MantelResBox.Size = new System.Drawing.Size(383, 811);
            this.MantelResBox.TabIndex = 2;
            this.MantelResBox.WordWrap = false;
            this.MantelResBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.MantelMatBox);
            this.groupBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox32.Location = new System.Drawing.Point(0, 0);
            this.groupBox32.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox32.Size = new System.Drawing.Size(1472, 945);
            this.groupBox32.TabIndex = 1;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Matrices (2 or up to 7 matrices, for simple or partial Mantel test, in order Y,X," +
    "Z1,Z2,Z3,Z4,Z5)";
            // 
            // MantelMatBox
            // 
            this.MantelMatBox.AcceptsReturn = true;
            this.MantelMatBox.AcceptsTab = true;
            this.MantelMatBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MantelMatBox.HideSelection = false;
            this.MantelMatBox.Location = new System.Drawing.Point(4, 24);
            this.MantelMatBox.Margin = new System.Windows.Forms.Padding(4);
            this.MantelMatBox.MaxLength = 32767000;
            this.MantelMatBox.Multiline = true;
            this.MantelMatBox.Name = "MantelMatBox";
            this.MantelMatBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.MantelMatBox.Size = new System.Drawing.Size(1464, 917);
            this.MantelMatBox.TabIndex = 2;
            this.MantelMatBox.WordWrap = false;
            this.MantelMatBox.TextChanged += new System.EventHandler(this.PreSaveSettings);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.savePictureToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(159, 28);
            // 
            // savePictureToolStripMenuItem
            // 
            this.savePictureToolStripMenuItem.Name = "savePictureToolStripMenuItem";
            this.savePictureToolStripMenuItem.Size = new System.Drawing.Size(158, 24);
            this.savePictureToolStripMenuItem.Text = "&Save Picture";
            this.savePictureToolStripMenuItem.Click += new System.EventHandler(this.savePictureToolStripMenuItem_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "*.png";
            this.saveFileDialog1.Filter = "*.png|*.png|*.jpg|*.jpg|*.gif|*.gif|*.tif|*.tif|*.bmp|*.bmp|*.emf|*.emf|*.wmf|*.w" +
    "mf";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.deleteAllToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(145, 52);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(144, 24);
            this.toolStripMenuItem1.Text = "&Delete";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // deleteAllToolStripMenuItem
            // 
            this.deleteAllToolStripMenuItem.Name = "deleteAllToolStripMenuItem";
            this.deleteAllToolStripMenuItem.Size = new System.Drawing.Size(144, 24);
            this.deleteAllToolStripMenuItem.Text = "Delete &All";
            this.deleteAllToolStripMenuItem.Click += new System.EventHandler(this.deleteAllToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "*.txt|*.txt|*.*|*.*";
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 10000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(28, 35);
            this.toolStripButton14.Text = "toolStripButton14";
            this.toolStripButton14.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 1024);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "PolyGene V1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).EndInit();
            this.splitContainer14.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.SimulationToolStrip.ResumeLayout(false);
            this.SimulationToolStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_NegPCRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SamplingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_SelfingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimPop_FemaleRateBox)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianADMBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicHeightBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianKmaxBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNThinningBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianSeparatorWidthBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicWidthBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNRepsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsGammaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsEtaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFPriorStdBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianEpsRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFStdFBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFStdPABox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianFPriorMeanBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxRBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianUpdateQBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlphaPrioriABox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlphaPrioriBBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianStdAlphaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxAlphaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianAlpha0Box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianMaxLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianStdLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianLambdaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianNRunsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BayesianKminBox)).EndInit();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox50.ResumeLayout(false);
            this.groupBox50.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PCOAFontSizeBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PCOADimBox)).EndInit();
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringFontSizeBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringLineSepBox)).EndInit();
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNSimBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNSimBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNSimBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageUnknownNCandidateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNMotherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageParentPairNFatherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentagePaternityNFatherBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageSamplingRateBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ParentageMistypeRateBox)).EndInit();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalNullAlleleBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalSeedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalThreadBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GlobalDecimalPlaceBox)).EndInit();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageIterationsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinkageBatchesBox)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AMOVANPermBox)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentErrorBox)).EndInit();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiffIterationsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBurninBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiffBatchesBox)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).EndInit();
            this.splitContainer15.ResumeLayout(false);
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PCoAPicBox)).EndInit();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.splitContainer16.Panel1.ResumeLayout(false);
            this.splitContainer16.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).EndInit();
            this.splitContainer16.ResumeLayout(false);
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ClusteringPicBox)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.groupBox49.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.D2_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPF_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DP_999)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPM_80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DPS_99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1_80)).EndInit();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox39.ResumeLayout(false);
            this.groupBox39.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).EndInit();
            this.splitContainer13.ResumeLayout(false);
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox38.ResumeLayout(false);
            this.groupBox38.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BayesianPicBox)).EndInit();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MantelNPermBOx)).EndInit();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox SimPop_AlleleFrequencyBox;
        private System.Windows.Forms.ToolStrip SimulationToolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox PhenotypeBox;
        private System.Windows.Forms.ToolStripButton untilFst;
        private System.Windows.Forms.ToolStripComboBox SimPop_FstTerminalBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel GenLabel;
        private System.Windows.Forms.ToolStripLabel FstLabel;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.CheckBox GlobalWarningBox;
        private System.Windows.Forms.CheckBox FrequencyNullAlleleBox;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.NumericUpDown GlobalNullAlleleBox;
        private System.Windows.Forms.ComboBox FrequencyGenotypicModeBox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox SimPop_DioeciousBox;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown SimPop_SamplingRateBox;
        private System.Windows.Forms.NumericUpDown SimPop_SelfingRateBox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown SimPop_FemaleRateBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.NumericUpDown GlobalDecimalPlaceBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox FrequencyResBox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox DiffResBox;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox PhenotypeResBox;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox SimPop_DistBox;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown AMOVANPermBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.NumericUpDown BayesianPicHeightBox;
        private System.Windows.Forms.NumericUpDown BayesianPicWidthBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox InbreedingResBox;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox DiversityResBox;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox AMOVARegionBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox AMOVAResBox;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox HIndexResBox;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox AssignmentResBox;
        private System.Windows.Forms.ToolStripLabel TaskLabel;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.NumericUpDown AssignmentErrorBox;
        private System.Windows.Forms.CheckBox AssignmentPloidyBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox RelatednessResBox;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox LinkageResBox;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox LinkageTestPopBox;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.CheckBox CalcAMOVABox;
        private System.Windows.Forms.CheckBox CalcRelatednessBox;
        private System.Windows.Forms.CheckBox CalcAssignmentBox;
        private System.Windows.Forms.CheckBox CalcHIndexBox;
        private System.Windows.Forms.CheckBox CalcInbreedingBox;
        private System.Windows.Forms.CheckBox CalcPhenotypeBox;
        private System.Windows.Forms.CheckBox CalcDiffBox;
        private System.Windows.Forms.CheckBox CalcLinkageBox;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox DistResBox;
        private System.Windows.Forms.CheckBox CalcDistBox;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.CheckBox DistCavalli1967Box;
        private System.Windows.Forms.CheckBox DistNei1972Box;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.CheckBox DiffSlatkin1995Box;
        private System.Windows.Forms.CheckBox DistSlatkinBox;
        private System.Windows.Forms.CheckBox DistRoger1973Box;
        private System.Windows.Forms.CheckBox DistNei1983Box;
        private System.Windows.Forms.CheckBox DistReynolds1983Box;
        private System.Windows.Forms.CheckBox DistNei1973Box;
        private System.Windows.Forms.CheckBox DistReynold1993Box;
        private System.Windows.Forms.CheckBox DistGoldstein1995Box;
        private System.Windows.Forms.CheckBox DistEuclideanBox;
        private System.Windows.Forms.CheckBox DiffTestAlleleBox;
        private System.Windows.Forms.CheckBox DiffTestPhenoBox;
        private System.Windows.Forms.CheckBox RelatednessLoiselle1995Box;
        private System.Windows.Forms.CheckBox RelatednessRitland1996Box;
        private System.Windows.Forms.CheckBox RelatednessLoiselle1995mBox;
        private System.Windows.Forms.CheckBox RelatednessWeir1996Box;
        private System.Windows.Forms.CheckBox RelatednessRitland1996mBox;
        private System.Windows.Forms.CheckBox RelatednessPopBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox RelatednessTotBox;
        private System.Windows.Forms.NumericUpDown GlobalThreadBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.CheckBox BayesianADMBox;
        private System.Windows.Forms.CheckBox BayesianLOCPRIORIBox;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ListView BayesianResultExplorerBox;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.PictureBox BayesianPicBox;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TextBox BayesianSummaryBox;
        private System.Windows.Forms.CheckBox CalcBayesianBox;
        private System.Windows.Forms.NumericUpDown BayesianKmaxBox;
        private System.Windows.Forms.NumericUpDown BayesianBurninBox;
        private System.Windows.Forms.NumericUpDown BayesianNRepsBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown BayesianNRunsBox;
        private System.Windows.Forms.NumericUpDown BayesianKminBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox LinkageTestTotBox;
        private System.Windows.Forms.ComboBox BayesianIndividualOrderBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown BayesianSeparatorWidthBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox BayesianRearrangeColorBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem savePictureToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown BayesianStdAlphaBox;
        private System.Windows.Forms.NumericUpDown BayesianAlpha0Box;
        private System.Windows.Forms.NumericUpDown BayesianLambdaBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown BayesianMaxRBox;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown BayesianEpsGammaBox;
        private System.Windows.Forms.NumericUpDown BayesianEpsEtaBox;
        private System.Windows.Forms.NumericUpDown BayesianEpsRBox;
        private System.Windows.Forms.NumericUpDown BayesianNThinningBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.ListView BayesianResultBox;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ToolStripMenuItem deleteAllToolStripMenuItem;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown BayesianFPriorStdBox;
        private System.Windows.Forms.NumericUpDown BayesianFPriorMeanBox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox FSAMEBOX;
        private System.Windows.Forms.CheckBox BayesianFmodelBox;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown BayesianFStdPABox;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.NumericUpDown BayesianFStdFBox;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown MantelNPermBOx;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.TextBox MantelResBox;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.TextBox MantelMatBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.NumericUpDown GlobalSeedBox;
        private System.Windows.Forms.CheckBox GlobalRefreshSeedBox;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.NumericUpDown BayesianADMBurninBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.NumericUpDown BayesianUpdateQBox;
        private System.Windows.Forms.NumericUpDown BayesianMaxAlphaBox;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.CheckBox AMOVAIgnoreIndBox;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.CheckBox InbreedingLoiselle1995Box;
        private System.Windows.Forms.CheckBox InbreedingRitland1996Box;
        private System.Windows.Forms.CheckBox InbreedingWeir1996Box;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.CheckBox CalcParentageBox;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.NumericUpDown ParentageUnknownNSimBox;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown ParentageParentPairNSimBox;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.NumericUpDown ParentagePaternityNSimBox;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown ParentageUnknownNCandidateBox;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.NumericUpDown ParentageParentPairNMotherBox;
        private System.Windows.Forms.NumericUpDown ParentageParentPairNFatherBox;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.NumericUpDown ParentagePaternityNFatherBox;
        private System.Windows.Forms.NumericUpDown ParentageSamplingRateBox;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.NumericUpDown ParentageMistypeRateBox;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.SplitContainer splitContainer13;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.CheckBox ParentageUnknownBox;
        private System.Windows.Forms.CheckBox ParentageParentPairBox;
        private System.Windows.Forms.CheckBox ParentageSkipSimBox;
        private System.Windows.Forms.CheckBox ParentagePaternityBox;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TextBox ParentageSimResBox;
        private System.Windows.Forms.TextBox ParentagePaternityOffspringBox;
        private System.Windows.Forms.TextBox ParentageParentPairOffspringBox;
        private System.Windows.Forms.TextBox ParentageParentPairMotherBox;
        private System.Windows.Forms.TextBox ParentageParentPairFatherBox;
        private System.Windows.Forms.TextBox ParentageUnknownOffspringBox;
        private System.Windows.Forms.TextBox ParentageUnknownParentBox;
        private System.Windows.Forms.ComboBox ParentageOutputBox;
        private System.Windows.Forms.TextBox ParentagePaternityResBox;
        private System.Windows.Forms.TextBox ParentageParentPairResBox;
        private System.Windows.Forms.TextBox ParentageUnknownResBox;
        private System.Windows.Forms.NumericUpDown D2_95;
        private System.Windows.Forms.NumericUpDown D2_99;
        private System.Windows.Forms.NumericUpDown D2_999;
        private System.Windows.Forms.NumericUpDown D2_80;
        private System.Windows.Forms.NumericUpDown D1_95;
        private System.Windows.Forms.NumericUpDown D1_99;
        private System.Windows.Forms.NumericUpDown DPM_95;
        private System.Windows.Forms.NumericUpDown D1_999;
        private System.Windows.Forms.NumericUpDown DPF_95;
        private System.Windows.Forms.NumericUpDown DPM_99;
        private System.Windows.Forms.NumericUpDown DPF_99;
        private System.Windows.Forms.NumericUpDown DPM_999;
        private System.Windows.Forms.NumericUpDown DPF_999;
        private System.Windows.Forms.NumericUpDown DPS_80;
        private System.Windows.Forms.NumericUpDown DP_95;
        private System.Windows.Forms.NumericUpDown DP_80;
        private System.Windows.Forms.NumericUpDown DP_99;
        private System.Windows.Forms.NumericUpDown DPS_999;
        private System.Windows.Forms.NumericUpDown DPS_95;
        private System.Windows.Forms.NumericUpDown DPF_80;
        private System.Windows.Forms.NumericUpDown DP_999;
        private System.Windows.Forms.NumericUpDown DPM_80;
        private System.Windows.Forms.NumericUpDown DPS_99;
        private System.Windows.Forms.NumericUpDown D1_80;
        private System.Windows.Forms.CheckBox DiffHedrick2005Box;
        private System.Windows.Forms.CheckBox DiffHudson1992Box;
        private System.Windows.Forms.CheckBox DiffNei1973Box;
        private System.Windows.Forms.CheckBox DiffJost2008Box;
        private System.Windows.Forms.CheckBox AMOVASMMBox;
        private System.Windows.Forms.CheckBox AMOVAIAMBox;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.CheckBox DiffHuang2018SMMBox;
        private System.Windows.Forms.CheckBox DiffHuang2018IAMBox;
        private System.Windows.Forms.NumericUpDown DiffBatchesBox;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.CheckBox DiffTestPermBox;
        private System.Windows.Forms.NumericUpDown DiffIterationsBox;
        private System.Windows.Forms.NumericUpDown DiffBurninBox;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown LinkageIterationsBox;
        private System.Windows.Forms.NumericUpDown LinkageBurninBox;
        private System.Windows.Forms.NumericUpDown LinkageBatchesBox;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.SplitContainer splitContainer14;
        private System.Windows.Forms.CheckBox LinkageTestPermBox;
        private System.Windows.Forms.CheckBox CalcPCoABox;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TextBox PCoAResBox;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.CheckBox ClusteringWPGMABox;
        private System.Windows.Forms.CheckBox ClusteringWARDBox;
        private System.Windows.Forms.CheckBox ClusteringUPGMABox;
        private System.Windows.Forms.CheckBox ClusteringWPGMCBox;
        private System.Windows.Forms.CheckBox ClusteringFurthestBox;
        private System.Windows.Forms.CheckBox ClusteringUPGMCBox;
        private System.Windows.Forms.CheckBox ClusteringNearestBox;
        private System.Windows.Forms.CheckBox CalcClusteringBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TextBox ClusteringResBox;
        private System.Windows.Forms.CheckBox DistRegBox;
        private System.Windows.Forms.CheckBox DistPopBox;
        private System.Windows.Forms.CheckBox DistIndBox;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.CheckBox DiffRegBox;
        private System.Windows.Forms.CheckBox DiffPopBox;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.CheckBox PhenotypeTestTotBox;
        private System.Windows.Forms.CheckBox PhenotypeTestRegBox;
        private System.Windows.Forms.CheckBox PhenotypeTestPopBox;
        private System.Windows.Forms.CheckBox LinkageTestRegBox;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.NumericUpDown PCOADimBox;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.SplitContainer splitContainer15;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripComboBox PCoAComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.SplitContainer splitContainer16;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel6;
        private System.Windows.Forms.ToolStripComboBox ClusteringComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox ClusteringPicBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox PCoAPicBox;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.NumericUpDown ClusteringLineSepBox;
        private System.Windows.Forms.NumericUpDown ClusteringFontSizeBox;
        private System.Windows.Forms.CheckBox DiffTotBox;
        private System.Windows.Forms.CheckBox RelatednessRegBox;
        private System.Windows.Forms.CheckBox SimPop_OutputGenotypeBox;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.NumericUpDown PCOAFontSizeBox;
        private System.Windows.Forms.CheckBox FrequencyRemoveDupAlleleBox;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.NumericUpDown BayesianStdLambdaBox;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.NumericUpDown BayesianMaxLambdaBox;
        private System.Windows.Forms.CheckBox BayesianDiffLambdaBox;
        private System.Windows.Forms.CheckBox BayesianInferLambdaBox;
        private System.Windows.Forms.CheckBox BayesianDiffAlphaBox;
        private System.Windows.Forms.CheckBox BayesianInferAlphaBox;
        private System.Windows.Forms.CheckBox BayesianUniformAlphaBox;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.NumericUpDown BayesianAlphaPrioriABox;
        private System.Windows.Forms.NumericUpDown BayesianAlphaPrioriBBox;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.CheckBox RelatednessHuang2015Box;
        private System.Windows.Forms.CheckBox RelatednessHuang2014Box;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.CheckBox AMOVAGenotypeBox;
        private System.Windows.Forms.CheckBox AMOVAAnisoBox;
        private System.Windows.Forms.CheckBox AMOVAHomoBox;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.CheckBox AMOVAMLBox;
        private System.Windows.Forms.CheckBox FrequencySelfingBox;
        private System.Windows.Forms.CheckBox FrequencyNegPCRBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown SimPop_NegPCRBox;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
    }
}


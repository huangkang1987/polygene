// ���� ifdef ���Ǵ���ʹ�� DLL �������򵥵�
// ��ı�׼�������� DLL �е������ļ��������������϶���� WIN32DLL_EXPORTS
// ���ű���ġ���ʹ�ô� DLL ��
// �κ�������Ŀ�ϲ�Ӧ����˷��š�������Դ�ļ��а������ļ����κ�������Ŀ���Ὣ
// WIN32DLL_API ������Ϊ�Ǵ� DLL ����ģ����� DLL ���ô˺궨���
// ������Ϊ�Ǳ������ġ�
#pragma pack(1)

#ifdef WIN32DLL_EXPORTS
#define WIN32DLL_API extern "C" __declspec(dllexport)
#else
#define WIN32DLL_API extern "C" __declspec(dllimport)
#endif

// �����Ǵ� Win32DLL.dll ������


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
using namespace std;


extern "C" __declspec(dllexport) double GFZ10_iiiiiiiiii(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiiiij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiiijj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiiijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiijjj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiijjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiiiijjjj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ10_iiiiiijjjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiiijjkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjjjj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjjjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjjkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiiiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ10_iiiijjjjkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiijjjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiijjjkkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ10_iiiijjjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiijjjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiiijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiiijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiiijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ10_iiiijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double GFZ10_iiijjjkkkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiijjjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ10_iiijjjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiijjjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ10_iiijjkkllm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iiijjkklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ10_iiijjklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double GFZ10_iiijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double GFZ10_iijjkkllmm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ10_iijjkkllmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ10_iijjkklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double GFZ10_iijjklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double GFZ10_iijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
extern "C" __declspec(dllexport) double GFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);
extern "C" __declspec(dllexport) double PFZ10_i(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double PFZ10_ij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double PFZ10_ijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ10_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double PFZ10_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double PFZ10_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double PFZ10_ijklmnopq(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
extern "C" __declspec(dllexport) double PFZ10_ijklmnopqr(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq, double pr);
extern "C" __declspec(dllexport) double GFG10_iiiii(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double GFG10_iiiij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFG10_iiijj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFG10_iiijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFG10_iijjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFG10_iijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFG10_i(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double PFG10_ij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double PFG10_ijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFG10_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFG10_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ8_iiiiiiii(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double GFZ8_iiiiiiij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ8_iiiiiijj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ8_iiiiiijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ8_iiiiijjj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ8_iiiiijjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ8_iiiiijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ8_iiiijjjj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ8_iiiijjjk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ8_iiiijjkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ8_iiiijjkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ8_iiiijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ8_iiijjjkk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ8_iiijjjkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ8_iiijjkkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ8_iiijjklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ8_iiijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ8_iijjkkll(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ8_iijjkklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ8_iijjklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFZ8_iijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double GFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double PFZ8_i(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double PFZ8_ij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double PFZ8_ijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ8_ijklm(double a1, double a2, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ8_ijklmn(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double PFZ8_ijklmno(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double PFZ8_ijklmnop(double a1, double a2, double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double GFG8_iiii(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double GFG8_iiij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFG8_iijj(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double GFG8_iijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFG8_i(double a1, double a2, double pi);
extern "C" __declspec(dllexport) double PFG8_ij(double a1, double a2, double pi, double pj);
extern "C" __declspec(dllexport) double PFG8_ijk(double a1, double a2, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFG8_ijkl(double a1, double a2, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ6_iiiiii(double a1, double pi);
extern "C" __declspec(dllexport) double GFZ6_iiiiij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ6_iiiijj(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ6_iiiijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ6_iiijjj(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ6_iiijjk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ6_iiijkl(double a1, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ6_iijjkk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ6_iijjkl(double a1, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFZ6_iijklm(double a1, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double GFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double PFZ6_i(double a1, double pi);
extern "C" __declspec(dllexport) double PFZ6_ij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double PFZ6_ijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ6_ijkl(double a1, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ6_ijklm(double a1, double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ6_ijklmn(double a1, double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double GFG6_iii(double a1, double pi);
extern "C" __declspec(dllexport) double GFG6_iij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFG6_ijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFG6_i(double a1, double pi);
extern "C" __declspec(dllexport) double PFG6_ij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double PFG6_ijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ4_iiii(double a1, double pi);
extern "C" __declspec(dllexport) double GFZ4_iiij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ4_iijj(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double GFZ4_iijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double GFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ4_i(double a1, double pi);
extern "C" __declspec(dllexport) double PFZ4_ij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double PFZ4_ijk(double a1, double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ4_ijkl(double a1, double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double GFG4_ii(double a1, double pi);
extern "C" __declspec(dllexport) double GFG4_ij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double PFG4_i(double a1, double pi);
extern "C" __declspec(dllexport) double PFG4_ij(double a1, double pi, double pj);
extern "C" __declspec(dllexport) double PFZ3_i(double pi);
extern "C" __declspec(dllexport) double PFZ3_ij(double pi, double pj);
extern "C" __declspec(dllexport) double PFZ3_ijk(double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ5_i(double pi);
extern "C" __declspec(dllexport) double PFZ5_ij(double pi, double pj);
extern "C" __declspec(dllexport) double PFZ5_ijk(double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ5_ijkl(double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ5_ijklm(double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ7_i(double pi);
extern "C" __declspec(dllexport) double PFZ7_ij(double pi, double pj);
extern "C" __declspec(dllexport) double PFZ7_ijk(double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ7_ijkl(double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ7_ijklm(double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ7_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double PFZ7_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double PFZ9_i(double pi);
extern "C" __declspec(dllexport) double PFZ9_ij(double pi, double pj);
extern "C" __declspec(dllexport) double PFZ9_ijk(double pi, double pj, double pk);
extern "C" __declspec(dllexport) double PFZ9_ijkl(double pi, double pj, double pk, double pl);
extern "C" __declspec(dllexport) double PFZ9_ijklm(double pi, double pj, double pk, double pl, double pm);
extern "C" __declspec(dllexport) double PFZ9_ijklmn(double pi, double pj, double pk, double pl, double pm, double pn);
extern "C" __declspec(dllexport) double PFZ9_ijklmno(double pi, double pj, double pk, double pl, double pm, double pn, double po);
extern "C" __declspec(dllexport) double PFZ9_ijklmnop(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp);
extern "C" __declspec(dllexport) double PFZ9_ijklmnopq(double pi, double pj, double pk, double pl, double pm, double pn, double po, double pp, double pq);
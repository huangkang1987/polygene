rm bin/PolyGene.linux
rm bin/dre.so

cd dre
g++ -fPIC -shared dre.cpp -o dre.so -O3 -march=x86-64 -msse2
cd ..
mv dre/dre.so bin/dre.so

xbuild /p:Configuration=Release_x64 /p:Platform=x64  PolyGene.sln
mv PolyGene/bin/Release_x64/PolyGene.exe bin/PolyGene.exe

cd bin

mkbundle --deps --static -z -o PolyGene.linux PolyGene.exe MathNet.Numerics.dll --simple --machine-config /etc/mono/4.5/machine.config --no-config
rm PolyGene.exe
cd ..



genodive_geno.gdv: genotypic dataset in genodive format
genodive_pheno.gdv: allelic phenotypic dataset in genodive format
genodive_gout.gdv: genodive results file of genotypic dataset
genodive_pout.gdv: genodive results file of allelic phenotypic dataset

polygene_geno.txt: genotypic dataset in polygene format
polygene_pheno.txt: allelic phenotypic dataset in polygene format
polygene_gout.gdv: polygene results file of genotypic dataset
polygene_pout.gdv: polygene results file of allelic phenotypic dataset

spagedi_geno.txt: genotypic dataset in spagedi format
spagedi_pheno.txt: allelic phenotypic dataset in spagedi format
spagedi_gout.gdv: spagedi results file of genotypic dataset
spagedi_pout.gdv: spagedi results file of allelic phenotypic dataset

results.xlsx: calculating the RMSE from each results. 
The 'polygene model' sheet shows the BIC for different inheritance models. 
a.gdv - h.gdv or a.txt - h.txt: the input allelic phenotypic dataset 
ao.txt - ho.txt: the results file
BIC.xlsx: the BIC of different inheritance models
Summary.xlsx: calculating the RMSE of various statistics
rm bin/PolyGene.exe
rm bin/PolyGene
rm bin/dre.so

cd dre
g++ -fPIC -shared dre.cpp -o dre.so -O3 -march=x86-64 -msse2
cd ..
mv dre/dre.so bin/dre.so

xbuild /p:Configuration=Release_x64 PolyGene.sln
mv PolyGene/bin/Release_x64/PolyGene.exe bin/PolyGene.exe

cd bin

mkbundle --deps --static -z -o PolyGene PolyGene.exe MathNet.Numerics.dll --cross mono-6.6.0-ubuntu-18.04-x64
cd ..
